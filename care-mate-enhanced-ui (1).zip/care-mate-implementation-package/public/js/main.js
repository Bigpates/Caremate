/**
 * Care Mate - Main JavaScript
 * 
 * This is the main JavaScript file for the Care Mate application.
 * It handles core functionality including accessibility features,
 * UI interactions, and application state management.
 */

// Configuration
const config = {
  accessibilitySettings: {
    textSizeIncrement: 2, // px
    maxTextSizeIncrease: 8, // px
    minTextSizeDecrease: -4 // px
  },
  networkCheck: {
    interval: 10000, // ms
    timeout: 5000 // ms
  }
};

// DOM Elements
let accessibilityToggle;
let accessibilityPanel;
let increaseTextButton;
let decreaseTextButton;
let highContrastButton;
let dyslexiaFontButton;
let screenReaderButton;
let voiceInputButton;
let networkStatus;
let srAnnouncer;

// State
let currentTextSize = 0; // Current text size adjustment in px
let isHighContrast = false;
let isDyslexiaFont = false;
let isScreenReaderMode = false;
let isVoiceInputEnabled = false;
let isOnline = navigator.onLine;

// Initialize
function init() {
  // Get DOM elements
  accessibilityToggle = document.getElementById('accessibility-toggle');
  accessibilityPanel = document.getElementById('accessibility-panel');
  increaseTextButton = document.getElementById('increase-text');
  decreaseTextButton = document.getElementById('decrease-text');
  highContrastButton = document.getElementById('high-contrast');
  dyslexiaFontButton = document.getElementById('dyslexia-font');
  screenReaderButton = document.getElementById('screen-reader');
  voiceInputButton = document.getElementById('voice-input');
  networkStatus = document.getElementById('network-status');
  srAnnouncer = document.getElementById('sr-announcer');

  // Load saved settings
  loadAccessibilitySettings();

  // Add event listeners
  addEventListeners();

  // Initialize network status
  updateNetworkStatus();
  
  // Start network status monitoring
  setInterval(checkNetworkStatus, config.networkCheck.interval);
  
  // Initialize service worker if available
  initServiceWorker();
}

// Add event listeners
function addEventListeners() {
  // Accessibility toggle
  if (accessibilityToggle) {
    accessibilityToggle.addEventListener('click', toggleAccessibilityPanel);
    accessibilityToggle.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggleAccessibilityPanel();
      }
    });
  }

  // Text size buttons
  if (increaseTextButton) {
    increaseTextButton.addEventListener('click', increaseTextSize);
  }
  if (decreaseTextButton) {
    decreaseTextButton.addEventListener('click', decreaseTextSize);
  }

  // High contrast button
  if (highContrastButton) {
    highContrastButton.addEventListener('click', toggleHighContrast);
  }

  // Dyslexia font button
  if (dyslexiaFontButton) {
    dyslexiaFontButton.addEventListener('click', toggleDyslexiaFont);
  }

  // Screen reader mode button
  if (screenReaderButton) {
    screenReaderButton.addEventListener('click', toggleScreenReaderMode);
  }

  // Voice input button
  if (voiceInputButton) {
    voiceInputButton.addEventListener('click', toggleVoiceInput);
  }

  // Network status events
  window.addEventListener('online', updateNetworkStatus);
  window.addEventListener('offline', updateNetworkStatus);
  
  // Close accessibility panel when clicking outside
  document.addEventListener('click', (e) => {
    if (accessibilityPanel && 
        !accessibilityPanel.contains(e.target) && 
        e.target !== accessibilityToggle) {
      accessibilityPanel.classList.add('hidden');
    }
  });
  
  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    // Close accessibility panel with Escape key
    if (e.key === 'Escape' && accessibilityPanel && !accessibilityPanel.classList.contains('hidden')) {
      accessibilityPanel.classList.add('hidden');
      accessibilityToggle.focus();
    }
  });
}

// Toggle accessibility panel
function toggleAccessibilityPanel() {
  if (accessibilityPanel) {
    accessibilityPanel.classList.toggle('hidden');
    
    // Announce to screen readers
    if (!accessibilityPanel.classList.contains('hidden')) {
      announceToScreenReader('Accessibility panel opened');
    } else {
      announceToScreenReader('Accessibility panel closed');
    }
  }
}

// Increase text size
function increaseTextSize() {
  if (currentTextSize < config.accessibilitySettings.maxTextSizeIncrease) {
    currentTextSize += config.accessibilitySettings.textSizeIncrement;
    applyTextSize();
    saveAccessibilitySetting('textSize', currentTextSize);
    announceToScreenReader('Text size increased');
  } else {
    announceToScreenReader('Maximum text size reached');
  }
}

// Decrease text size
function decreaseTextSize() {
  if (currentTextSize > config.accessibilitySettings.minTextSizeDecrease) {
    currentTextSize -= config.accessibilitySettings.textSizeIncrement;
    applyTextSize();
    saveAccessibilitySetting('textSize', currentTextSize);
    announceToScreenReader('Text size decreased');
  } else {
    announceToScreenReader('Minimum text size reached');
  }
}

// Apply text size
function applyTextSize() {
  document.documentElement.style.setProperty('--text-size-adjustment', `${currentTextSize}px`);
}

// Toggle high contrast
function toggleHighContrast() {
  isHighContrast = !isHighContrast;
  document.body.classList.toggle('high-contrast', isHighContrast);
  highContrastButton.classList.toggle('active', isHighContrast);
  saveAccessibilitySetting('highContrast', isHighContrast);
  
  if (isHighContrast) {
    announceToScreenReader('High contrast mode enabled');
  } else {
    announceToScreenReader('High contrast mode disabled');
  }
}

// Toggle dyslexia font
function toggleDyslexiaFont() {
  isDyslexiaFont = !isDyslexiaFont;
  document.body.classList.toggle('dyslexia-font', isDyslexiaFont);
  dyslexiaFontButton.classList.toggle('active', isDyslexiaFont);
  saveAccessibilitySetting('dyslexiaFont', isDyslexiaFont);
  
  if (isDyslexiaFont) {
    announceToScreenReader('Dyslexia friendly font enabled');
  } else {
    announceToScreenReader('Dyslexia friendly font disabled');
  }
}

// Toggle screen reader mode
function toggleScreenReaderMode() {
  isScreenReaderMode = !isScreenReaderMode;
  document.body.classList.toggle('screen-reader-mode', isScreenReaderMode);
  screenReaderButton.classList.toggle('active', isScreenReaderMode);
  saveAccessibilitySetting('screenReaderMode', isScreenReaderMode);
  
  if (isScreenReaderMode) {
    announceToScreenReader('Screen reader mode enabled. Additional descriptions and context will be provided.');
  } else {
    announceToScreenReader('Screen reader mode disabled');
  }
}

// Toggle voice input
function toggleVoiceInput() {
  isVoiceInputEnabled = !isVoiceInputEnabled;
  voiceInputButton.classList.toggle('active', isVoiceInputEnabled);
  saveAccessibilitySetting('voiceInput', isVoiceInputEnabled);
  
  // Dispatch custom event for other components to listen to
  window.dispatchEvent(new CustomEvent('accessibilitySettingChanged', {
    detail: {
      setting: 'voice-input',
      enabled: isVoiceInputEnabled
    }
  }));
  
  if (isVoiceInputEnabled) {
    announceToScreenReader('Voice input enabled');
  } else {
    announceToScreenReader('Voice input disabled');
  }
}

// Save accessibility setting
function saveAccessibilitySetting(setting, value) {
  localStorage.setItem(`accessibility-${setting}`, JSON.stringify(value));
  localStorage.setItem(`${setting}-enabled`, value);
}

// Load accessibility settings
function loadAccessibilitySettings() {
  // Text size
  const savedTextSize = localStorage.getItem('accessibility-textSize');
  if (savedTextSize !== null) {
    currentTextSize = parseInt(savedTextSize, 10);
    applyTextSize();
  }
  
  // High contrast
  const savedHighContrast = localStorage.getItem('accessibility-highContrast');
  if (savedHighContrast !== null) {
    isHighContrast = JSON.parse(savedHighContrast);
    document.body.classList.toggle('high-contrast', isHighContrast);
    if (highContrastButton) {
      highContrastButton.classList.toggle('active', isHighContrast);
    }
  }
  
  // Dyslexia font
  const savedDyslexiaFont = localStorage.getItem('accessibility-dyslexiaFont');
  if (savedDyslexiaFont !== null) {
    isDyslexiaFont = JSON.parse(savedDyslexiaFont);
    document.body.classList.toggle('dyslexia-font', isDyslexiaFont);
    if (dyslexiaFontButton) {
      dyslexiaFontButton.classList.toggle('active', isDyslexiaFont);
    }
  }
  
  // Screen reader mode
  const savedScreenReaderMode = localStorage.getItem('accessibility-screenReaderMode');
  if (savedScreenReaderMode !== null) {
    isScreenReaderMode = JSON.parse(savedScreenReaderMode);
    document.body.classList.toggle('screen-reader-mode', isScreenReaderMode);
    if (screenReaderButton) {
      screenReaderButton.classList.toggle('active', isScreenReaderMode);
    }
  }
  
  // Voice input
  const savedVoiceInput = localStorage.getItem('accessibility-voiceInput');
  if (savedVoiceInput !== null) {
    isVoiceInputEnabled = JSON.parse(savedVoiceInput);
    if (voiceInputButton) {
      voiceInputButton.classList.toggle('active', isVoiceInputEnabled);
    }
  }
}

// Update network status
function updateNetworkStatus() {
  isOnline = navigator.onLine;
  
  if (networkStatus) {
    if (isOnline) {
      networkStatus.classList.remove('offline');
      networkStatus.classList.add('online');
      networkStatus.querySelector('.status-text').textContent = 'Online';
    } else {
      networkStatus.classList.remove('online');
      networkStatus.classList.add('offline');
      networkStatus.querySelector('.status-text').textContent = 'Offline';
      
      // Announce offline status to screen readers
      announceToScreenReader('You are now offline. Some features may be limited.');
    }
  }
  
  // Dispatch custom event for other components
  window.dispatchEvent(new CustomEvent('networkStatusChanged', {
    detail: {
      online: isOnline
    }
  }));
}

// Check network status by pinging a resource
function checkNetworkStatus() {
  // Only perform check if we think we're online
  if (navigator.onLine) {
    const timestamp = new Date().getTime();
    const testUrl = `/ping.txt?t=${timestamp}`;
    
    // Create a timeout promise
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Network check timed out')), config.networkCheck.timeout);
    });
    
    // Create a fetch promise
    const fetchPromise = fetch(testUrl, { method: 'HEAD' });
    
    // Race the promises
    Promise.race([fetchPromise, timeoutPromise])
      .then(() => {
        if (!isOnline) {
          isOnline = true;
          updateNetworkStatus();
        }
      })
      .catch(() => {
        if (isOnline) {
          isOnline = false;
          updateNetworkStatus();
        }
      });
  }
}

// Initialize service worker
function initServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/enhanced-service-worker.js')
        .then(registration => {
          console.log('Service Worker registered with scope:', registration.scope);
          
          // Listen for messages from service worker
          navigator.serviceWorker.addEventListener('message', event => {
            if (event.data && event.data.type === 'CACHE_UPDATED') {
              console.log('Content cache updated at:', new Date(event.data.timestamp).toLocaleString());
            }
            
            if (event.data && event.data.type === 'SYNC_COMPLETED') {
              console.log('Background sync completed:', event.data);
              
              // Notify user if there were successful syncs
              if (event.data.successCount > 0) {
                announceToScreenReader(`${event.data.successCount} items synchronized successfully.`);
              }
            }
          });
        })
        .catch(error => {
          console.error('Service Worker registration failed:', error);
        });
    });
  }
}

// Announce message to screen readers
function announceToScreenReader(message) {
  if (srAnnouncer) {
    srAnnouncer.textContent = message;
  }
}

// Initialize when DOM is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Export for testing
export default {
  increaseTextSize,
  decreaseTextSize,
  toggleHighContrast,
  toggleDyslexiaFont,
  toggleScreenReaderMode,
  toggleVoiceInput,
  updateNetworkStatus
};
