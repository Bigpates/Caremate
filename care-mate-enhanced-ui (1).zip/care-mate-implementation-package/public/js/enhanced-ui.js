/**
 * Care Mate - Enhanced UI JavaScript
 * 
 * This script provides enhanced UI functionality for the Care Mate application,
 * including animations, interactive elements, modals, and tour guide.
 */

// DOM Elements
let mobileMenuToggle;
let mobileMenu;
let searchToggle;
let searchOverlay;
let closeSearch;
let notificationsToggle;
let notificationsPanel;
let userProfileButton;
let userProfileMenu;
let closeAccessibility;
let backToTopButton;
let featureCards;
let stepInfoToggles;
let testimonialControls;
let welcomeModal;
let feedbackButton;
let feedbackModal;
let watchDemoButton;
let videoModal;
let takeTourButton;
let tourOverlay;

// State
let currentTestimonial = 0;
let currentWelcomeSlide = 0;
let currentTourStep = 0;
let isFirstVisit = true;

// Tour steps configuration
const tourSteps = [
  {
    element: '.hero-content h2',
    title: 'Welcome to Care Mate',
    description: 'Your AI-powered assistant for navigating the NDIS with confidence.',
    position: 'bottom'
  },
  {
    element: '#accessibility-toggle',
    title: 'Accessibility Features',
    description: 'Customize your experience with our comprehensive accessibility options.',
    position: 'bottom-left'
  },
  {
    element: '.feature-card:first-child',
    title: 'Interactive Features',
    description: 'Explore our key features by clicking on these cards for more information.',
    position: 'top'
  },
  {
    element: '.testimonial-carousel',
    title: 'User Testimonials',
    description: 'Read what other NDIS participants and coordinators say about Care Mate.',
    position: 'top'
  },
  {
    element: '.cta-buttons',
    title: 'Get Started',
    description: 'Create an account or contact us to begin your Care Mate journey.',
    position: 'top-right'
  }
];

// Initialize
function init() {
  // Get DOM elements
  mobileMenuToggle = document.getElementById('mobile-menu-toggle');
  mobileMenu = document.getElementById('mobile-menu');
  searchToggle = document.getElementById('search-toggle');
  searchOverlay = document.getElementById('search-overlay');
  closeSearch = document.getElementById('close-search');
  notificationsToggle = document.getElementById('notifications-toggle');
  notificationsPanel = document.getElementById('notifications-panel');
  userProfileButton = document.getElementById('user-profile');
  userProfileMenu = document.getElementById('user-profile-menu');
  closeAccessibility = document.getElementById('close-accessibility');
  backToTopButton = document.getElementById('back-to-top');
  featureCards = document.querySelectorAll('.feature-card');
  stepInfoToggles = document.querySelectorAll('.step-info-toggle');
  testimonialControls = {
    prev: document.getElementById('prev-testimonial'),
    next: document.getElementById('next-testimonial'),
    indicators: document.querySelectorAll('.testimonial-indicator')
  };
  welcomeModal = document.getElementById('welcome-modal');
  feedbackButton = document.getElementById('feedback-button');
  feedbackModal = document.getElementById('feedback-modal');
  watchDemoButton = document.getElementById('watch-demo');
  videoModal = document.getElementById('video-modal');
  takeTourButton = document.getElementById('take-tour');
  tourOverlay = document.getElementById('tour-overlay');

  // Add event listeners
  addEventListeners();

  // Initialize scroll animations
  initScrollAnimations();

  // Check if first visit
  checkFirstVisit();

  // Initialize testimonial carousel
  initTestimonialCarousel();
}

// Add event listeners
function addEventListeners() {
  // Mobile menu toggle
  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener('click', toggleMobileMenu);
  }

  // Search toggle
  if (searchToggle) {
    searchToggle.addEventListener('click', toggleSearch);
  }

  // Close search
  if (closeSearch) {
    closeSearch.addEventListener('click', toggleSearch);
  }

  // Notifications toggle
  if (notificationsToggle) {
    notificationsToggle.addEventListener('click', toggleNotifications);
  }

  // User profile button
  if (userProfileButton) {
    userProfileButton.addEventListener('click', toggleUserProfileMenu);
  }

  // Close accessibility panel
  if (closeAccessibility) {
    closeAccessibility.addEventListener('click', () => {
      const accessibilityPanel = document.getElementById('accessibility-panel');
      if (accessibilityPanel) {
        accessibilityPanel.classList.add('hidden');
      }
    });
  }

  // Back to top button
  if (backToTopButton) {
    window.addEventListener('scroll', toggleBackToTopButton);
    backToTopButton.addEventListener('click', scrollToTop);
  }

  // Feature cards
  featureCards.forEach(card => {
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const link = card.querySelector('.feature-link');
        if (link) {
          link.click();
        }
      }
    });
  });

  // Step info toggles
  stepInfoToggles.forEach(toggle => {
    toggle.addEventListener('click', toggleStepInfo);
  });

  // Testimonial controls
  if (testimonialControls.prev) {
    testimonialControls.prev.addEventListener('click', () => changeTestimonial('prev'));
  }
  if (testimonialControls.next) {
    testimonialControls.next.addEventListener('click', () => changeTestimonial('next'));
  }
  testimonialControls.indicators.forEach(indicator => {
    indicator.addEventListener('click', () => {
      const slideIndex = parseInt(indicator.dataset.slide);
      goToTestimonial(slideIndex);
    });
  });

  // Welcome modal
  if (welcomeModal) {
    const closeWelcomeModal = document.getElementById('close-welcome-modal');
    const nextSlideButtons = welcomeModal.querySelectorAll('.next-slide');
    const prevSlideButtons = welcomeModal.querySelectorAll('.prev-slide');
    const slideDots = welcomeModal.querySelectorAll('.slide-dot');
    const getStartedButton = document.getElementById('get-started');

    if (closeWelcomeModal) {
      closeWelcomeModal.addEventListener('click', () => {
        welcomeModal.classList.remove('active');
        localStorage.setItem('welcomeModalSeen', 'true');
      });
    }

    nextSlideButtons.forEach(button => {
      button.addEventListener('click', () => {
        changeWelcomeSlide('next');
      });
    });

    prevSlideButtons.forEach(button => {
      button.addEventListener('click', () => {
        changeWelcomeSlide('prev');
      });
    });

    slideDots.forEach(dot => {
      dot.addEventListener('click', () => {
        const slideIndex = parseInt(dot.dataset.slide) - 1;
        goToWelcomeSlide(slideIndex);
      });
    });

    if (getStartedButton) {
      getStartedButton.addEventListener('click', () => {
        welcomeModal.classList.remove('active');
        localStorage.setItem('welcomeModalSeen', 'true');
      });
    }
  }

  // Feedback button
  if (feedbackButton) {
    feedbackButton.addEventListener('click', () => {
      feedbackModal.classList.add('active');
    });

    const closeFeedbackModal = document.getElementById('close-feedback-modal');
    if (closeFeedbackModal) {
      closeFeedbackModal.addEventListener('click', () => {
        feedbackModal.classList.remove('active');
      });
    }

    const feedbackForm = document.getElementById('feedback-form');
    if (feedbackForm) {
      feedbackForm.addEventListener('submit', (e) => {
        e.preventDefault();
        submitFeedback();
      });
    }
  }

  // Watch demo button
  if (watchDemoButton) {
    watchDemoButton.addEventListener('click', () => {
      videoModal.classList.add('active');
    });

    const closeVideoModal = document.getElementById('close-video-modal');
    if (closeVideoModal) {
      closeVideoModal.addEventListener('click', () => {
        videoModal.classList.remove('active');
      });
    }
  }

  // Take tour button
  if (takeTourButton) {
    takeTourButton.addEventListener('click', startTour);
  }

  // Tour controls
  const tourPrev = document.getElementById('tour-prev');
  const tourNext = document.getElementById('tour-next');
  const tourClose = document.getElementById('tour-close');

  if (tourPrev) {
    tourPrev.addEventListener('click', () => changeTourStep('prev'));
  }
  if (tourNext) {
    tourNext.addEventListener('click', () => changeTourStep('next'));
  }
  if (tourClose) {
    tourClose.addEventListener('click', endTour);
  }

  // Close modals when clicking outside
  document.addEventListener('click', (e) => {
    // Notifications panel
    if (notificationsPanel && 
        !notificationsPanel.contains(e.target) && 
        e.target !== notificationsToggle) {
      notificationsPanel.classList.add('hidden');
    }

    // User profile menu
    if (userProfileMenu && 
        !userProfileMenu.contains(e.target) && 
        e.target !== userProfileButton) {
      userProfileMenu.classList.add('hidden');
    }

    // Search overlay - only close if clicking outside the search container
    if (searchOverlay && 
        !searchOverlay.classList.contains('hidden') && 
        e.target === searchOverlay) {
      searchOverlay.classList.add('hidden');
    }
  });

  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    // Close modals with Escape key
    if (e.key === 'Escape') {
      if (searchOverlay && !searchOverlay.classList.contains('hidden')) {
        searchOverlay.classList.add('hidden');
      }
      if (notificationsPanel && !notificationsPanel.classList.contains('hidden')) {
        notificationsPanel.classList.add('hidden');
      }
      if (userProfileMenu && !userProfileMenu.classList.contains('hidden')) {
        userProfileMenu.classList.add('hidden');
      }
      if (welcomeModal && welcomeModal.classList.contains('active')) {
        welcomeModal.classList.remove('active');
        localStorage.setItem('welcomeModalSeen', 'true');
      }
      if (feedbackModal && feedbackModal.classList.contains('active')) {
        feedbackModal.classList.remove('active');
      }
      if (videoModal && videoModal.classList.contains('active')) {
        videoModal.classList.remove('active');
      }
      if (tourOverlay && !tourOverlay.classList.contains('hidden')) {
        endTour();
      }
    }
  });

  // Mark notifications as read
  const markAllReadButton = document.getElementById('mark-all-read');
  if (markAllReadButton) {
    markAllReadButton.addEventListener('click', markAllNotificationsAsRead);
  }

  const notificationActions = document.querySelectorAll('.notification-action');
  notificationActions.forEach(button => {
    button.addEventListener('click', (e) => {
      const notificationItem = e.target.closest('.notification-item');
      if (notificationItem) {
        notificationItem.classList.remove('unread');
      }
      updateNotificationCount();
    });
  });

  // Quick search suggestions
  const suggestionTags = document.querySelectorAll('.suggestion-tag');
  suggestionTags.forEach(tag => {
    tag.addEventListener('click', () => {
      const searchInput = document.getElementById('search-input');
      if (searchInput) {
        searchInput.value = tag.textContent;
        searchInput.focus();
      }
    });
  });
}

// Toggle mobile menu
function toggleMobileMenu() {
  if (mobileMenuToggle && mobileMenu) {
    const isExpanded = mobileMenuToggle.getAttribute('aria-expanded') === 'true';
    mobileMenuToggle.setAttribute('aria-expanded', !isExpanded);
    mobileMenu.classList.toggle('hidden');
    mobileMenu.classList.toggle('visible');
  }
}

// Toggle search overlay
function toggleSearch() {
  if (searchOverlay) {
    searchOverlay.classList.toggle('hidden');
    if (!searchOverlay.classList.contains('hidden')) {
      const searchInput = document.getElementById('search-input');
      if (searchInput) {
        searchInput.focus();
      }
    }
  }
}

// Toggle notifications panel
function toggleNotifications() {
  if (notificationsPanel) {
    notificationsPanel.classList.toggle('hidden');
    
    // Close other panels
    if (userProfileMenu && !userProfileMenu.classList.contains('hidden')) {
      userProfileMenu.classList.add('hidden');
    }
  }
}

// Toggle user profile menu
function toggleUserProfileMenu() {
  if (userProfileMenu) {
    userProfileMenu.classList.toggle('hidden');
    
    // Close other panels
    if (notificationsPanel && !notificationsPanel.classList.contains('hidden')) {
      notificationsPanel.classList.add('hidden');
    }
  }
}

// Toggle back to top button
function toggleBackToTopButton() {
  if (backToTopButton) {
    if (window.pageYOffset > 300) {
      backToTopButton.classList.add('visible');
    } else {
      backToTopButton.classList.remove('visible');
    }
  }
}

// Scroll to top
function scrollToTop() {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
}

// Toggle step info
function toggleStepInfo(e) {
  const step = e.target.closest('.step');
  if (step) {
    const infoPanel = step.querySelector('.step-info-panel');
    if (infoPanel) {
      infoPanel.classList.toggle('hidden');
      
      // Update aria-expanded
      const expanded = !infoPanel.classList.contains('hidden');
      e.target.setAttribute('aria-expanded', expanded);
      
      // Update icon
      if (expanded) {
        e.target.innerHTML = '<i class="fas fa-times-circle"></i>';
        e.target.setAttribute('aria-label', 'Hide information');
      } else {
        e.target.innerHTML = '<i class="fas fa-info-circle"></i>';
        e.target.setAttribute('aria-label', 'Show more information');
      }
    }
  }
}

// Initialize scroll animations
function initScrollAnimations() {
  const animatedElements = document.querySelectorAll('.animate-on-scroll');
  
  // Check if element is in viewport
  function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
      rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8
    );
  }
  
  // Check elements on scroll
  function checkElements() {
    animatedElements.forEach(element => {
      if (isInViewport(element)) {
        element.classList.add('active');
      }
    });
  }
  
  // Initial check
  checkElements();
  
  // Check on scroll
  window.addEventListener('scroll', checkElements);
}

// Check if first visit
function checkFirstVisit() {
  const welcomeSeen = localStorage.getItem('welcomeModalSeen');
  if (!welcomeSeen && welcomeModal) {
    // Show welcome modal after a short delay
    setTimeout(() => {
      welcomeModal.classList.add('active');
    }, 1000);
  }
}

// Initialize testimonial carousel
function initTestimonialCarousel() {
  // Set initial state
  goToTestimonial(0);
  
  // Auto-rotate testimonials
  setInterval(() => {
    if (document.visibilityState === 'visible') {
      changeTestimonial('next');
    }
  }, 8000);
}

// Change testimonial
function changeTestimonial(direction) {
  const testimonials = document.querySelectorAll('.testimonial-slide');
  if (testimonials.length === 0) return;
  
  let newIndex = currentTestimonial;
  
  if (direction === 'next') {
    newIndex = (currentTestimonial + 1) % testimonials.length;
  } else if (direction === 'prev') {
    newIndex = (currentTestimonial - 1 + testimonials.length) % testimonials.length;
  }
  
  goToTestimonial(newIndex);
}

// Go to specific testimonial
function goToTestimonial(index) {
  const testimonials = document.querySelectorAll('.testimonial-slide');
  if (testimonials.length === 0) return;
  
  // Remove all classes
  testimonials.forEach(slide => {
    slide.classList.remove('active', 'prev');
  });
  
  // Add appropriate classes
  testimonials[currentTestimonial].classList.add('prev');
  testimonials[index].classList.add('active');
  
  // Update indicators
  testimonialControls.indicators.forEach((indicator, i) => {
    indicator.classList.toggle('active', i === index);
  });
  
  // Update current index
  currentTestimonial = index;
}

// Change welcome slide
function changeWelcomeSlide(direction) {
  const slides = document.querySelectorAll('.welcome-slide');
  if (slides.length === 0) return;
  
  let newIndex = currentWelcomeSlide;
  
  if (direction === 'next') {
    newIndex = (currentWelcomeSlide + 1) % slides.length;
  } else if (direction === 'prev') {
    newIndex = (currentWelcomeSlide - 1 + slides.length) % slides.length;
  }
  
  goToWelcomeSlide(newIndex);
}

// Go to specific welcome slide
function goToWelcomeSlide(index) {
  const slides = document.querySelectorAll('.welcome-slide');
  if (slides.length === 0) return;
  
  // Remove all classes
  slides.forEach(slide => {
    slide.classList.remove('active', 'prev');
  });
  
  // Add appropriate classes
  slides[currentWelcomeSlide].classList.add('prev');
  slides[index].classList.add('active');
  
  // Update dots
  const dots = document.querySelectorAll('.slide-dot');
  dots.forEach((dot, i) => {
    dot.classList.toggle('active', i === index);
  });
  
  // Update current index
  currentWelcomeSlide = index;
}

// Submit feedback
function submitFeedback() {
  const feedbackType = document.getElementById('feedback-type').value;
  const feedbackMessage = document.getElementById('feedback-message').value;
  const feedbackEmail = document.getElementById('feedback-email').value;
  
  // In a real implementation, this would send data to a server
  console.log('Feedback submitted:', { feedbackType, feedbackMessage, feedbackEmail });
  
  // Show success message
  const feedbackForm = document.getElementById('feedback-form');
  if (feedbackForm) {
    feedbackForm.innerHTML = `
      <div class="feedback-success">
        <i class="fas fa-check-circle"></i>
        <h3>Thank You for Your Feedback!</h3>
        <p>We appreciate your input and will use it to improve Care Mate.</p>
        <button id="close-feedback-success" class="button primary">Close</button>
      </div>
    `;
    
    // Add event listener to close button
    const closeButton = document.getElementById('close-feedback-success');
    if (closeButton) {
      closeButton.addEventListener('click', () => {
        feedbackModal.classList.remove('active');
      });
    }
  }
}

// Mark all notifications as read
function markAllNotificationsAsRead() {
  const unreadNotifications = document.querySelectorAll('.notification-item.unread');
  unreadNotifications.forEach(notification => {
    notification.classList.remove('unread');
  });
  updateNotificationCount();
}

// Update notification count
function updateNotificationCount() {
  const unreadCount = document.querySelectorAll('.notification-item.unread').length;
  const badge = document.querySelector('.notification-badge');
  if (badge) {
    badge.textContent = unreadCount;
    badge.style.display = unreadCount > 0 ? 'flex' : 'none';
  }
}

// Start tour
function startTour() {
  if (tourOverlay) {
    tourOverlay.classList.remove('hidden');
    currentTourStep = 0;
    showTourStep(currentTourStep);
  }
}

// End tour
function endTour() {
  if (tourOverlay) {
    tourOverlay.classList.add('hidden');
  }
}

// Change tour step
function changeTourStep(direction) {
  if (direction === 'next' && currentTourStep < tourSteps.length - 1) {
    currentTourStep++;
    showTourStep(currentTourStep);
  } else if (direction === 'prev' && currentTourStep > 0) {
    currentTourStep--;
    showTourStep(currentTourStep);
  } else if (direction === 'next' && currentTourStep === tourSteps.length - 1) {
    endTour();
  }
}

// Show tour step
function showTourStep(stepIndex) {
  const step = tourSteps[stepIndex];
  const targetElement = document.querySelector(step.element);
  
  if (!targetElement) {
    console.error('Tour target element not found:', step.element);
    return;
  }
  
  const highlight = document.getElementById('tour-highlight');
  const tooltip = document.getElementById('tour-tooltip');
  const tourStepTitle = document.getElementById('tour-step-title');
  const tourStepDescription = document.getElementById('tour-step-description');
  const tourProgress = document.getElementById('tour-progress');
  const tourPrev = document.getElementById('tour-prev');
  const tourNext = document.getElementById('tour-next');
  
  // Get element position
  const rect = targetElement.getBoundingClientRect();
  
  // Position highlight
  highlight.style.width = `${rect.width + 10}px`;
  highlight.style.height = `${rect.height + 10}px`;
  highlight.style.top = `${rect.top - 5 + window.scrollY}px`;
  highlight.style.left = `${rect.left - 5}px`;
  
  // Position tooltip
  let tooltipTop, tooltipLeft;
  
  switch (step.position) {
    case 'top':
      tooltipTop = rect.top - 10 - tooltip.offsetHeight + window.scrollY;
      tooltipLeft = rect.left + rect.width / 2 - tooltip.offsetWidth / 2;
      break;
    case 'bottom':
      tooltipTop = rect.bottom + 10 + window.scrollY;
      tooltipLeft = rect.left + rect.width / 2 - tooltip.offsetWidth / 2;
      break;
    case 'left':
      tooltipTop = rect.top + rect.height / 2 - tooltip.offsetHeight / 2 + window.scrollY;
      tooltipLeft = rect.left - 10 - tooltip.offsetWidth;
      break;
    case 'right':
      tooltipTop = rect.top + rect.height / 2 - tooltip.offsetHeight / 2 + window.scrollY;
      tooltipLeft = rect.right + 10;
      break;
    case 'top-left':
      tooltipTop = rect.top - 10 - tooltip.offsetHeight + window.scrollY;
      tooltipLeft = rect.left;
      break;
    case 'top-right':
      tooltipTop = rect.top - 10 - tooltip.offsetHeight + window.scrollY;
      tooltipLeft = rect.right - tooltip.offsetWidth;
      break;
    case 'bottom-left':
      tooltipTop = rect.bottom + 10 + window.scrollY;
      tooltipLeft = rect.left;
      break;
    case 'bottom-right':
      tooltipTop = rect.bottom + 10 + window.scrollY;
      tooltipLeft = rect.right - tooltip.offsetWidth;
      break;
    default:
      tooltipTop = rect.bottom + 10 + window.scrollY;
      tooltipLeft = rect.left + rect.width / 2 - tooltip.offsetWidth / 2;
  }
  
  // Ensure tooltip is within viewport
  if (tooltipLeft < 10) tooltipLeft = 10;
  if (tooltipLeft + tooltip.offsetWidth > window.innerWidth - 10) {
    tooltipLeft = window.innerWidth - tooltip.offsetWidth - 10;
  }
  
  tooltip.style.top = `${tooltipTop}px`;
  tooltip.style.left = `${tooltipLeft}px`;
  
  // Update tooltip content
  tourStepTitle.textContent = step.title;
  tourStepDescription.textContent = step.description;
  tourProgress.textContent = `Step ${stepIndex + 1} of ${tourSteps.length}`;
  
  // Update buttons
  tourPrev.disabled = stepIndex === 0;
  tourNext.textContent = stepIndex === tourSteps.length - 1 ? 'Finish' : 'Next';
  
  // Ensure element is in view
  targetElement.scrollIntoView({
    behavior: 'smooth',
    block: 'center'
  });
}

// Initialize when DOM is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Export for testing
export default {
  toggleMobileMenu,
  toggleSearch,
  toggleNotifications,
  toggleUserProfileMenu,
  changeTestimonial,
  changeWelcomeSlide,
  startTour,
  endTour
};
