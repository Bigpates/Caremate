/**
 * Care Mate - Audio Recorder
 * 
 * This script provides audio recording functionality for the Care Mate chat interface,
 * allowing users to send voice messages to the AI assistant.
 */

// Configuration
const config = {
  audioFormat: 'audio/webm',
  maxRecordingTime: 60, // seconds
  visualizerUpdateInterval: 100, // milliseconds
  audioQuality: {
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true
  }
};

// DOM Elements
const recordButton = document.getElementById('record-button');
const audioVisualizer = document.querySelector('.audio-visualizer');
const audioControls = document.querySelector('.audio-controls');
const audioTimer = document.querySelector('.audio-timer');
const audioCancelButton = document.getElementById('audio-cancel');
const audioSendButton = document.getElementById('audio-send');
const chatInput = document.getElementById('chat-input');
const sendButton = document.getElementById('send-button');
const srAnnouncer = document.getElementById('sr-announcer');

// State variables
let mediaRecorder = null;
let audioChunks = [];
let recordingStartTime = 0;
let timerInterval = null;
let visualizerInterval = null;
let audioBlob = null;
let isRecording = false;

// Initialize
function init() {
  // Check if browser supports audio recording
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    console.error('Audio recording is not supported in this browser');
    recordButton.disabled = true;
    recordButton.title = 'Audio recording not supported in this browser';
    return;
  }

  // Add event listeners
  recordButton.addEventListener('click', toggleRecording);
  audioCancelButton.addEventListener('click', cancelRecording);
  audioSendButton.addEventListener('click', sendAudioMessage);

  // Check if voice input is enabled in accessibility settings
  const voiceInputEnabled = localStorage.getItem('voice-input-enabled') === 'true';
  if (voiceInputEnabled) {
    recordButton.classList.add('enabled');
  }

  // Listen for accessibility setting changes
  window.addEventListener('accessibilitySettingChanged', (event) => {
    if (event.detail.setting === 'voice-input') {
      if (event.detail.enabled) {
        recordButton.classList.add('enabled');
      } else {
        recordButton.classList.remove('enabled');
        if (isRecording) {
          cancelRecording();
        }
      }
    }
  });
}

// Toggle recording state
async function toggleRecording() {
  if (isRecording) {
    stopRecording();
  } else {
    await startRecording();
  }
}

// Start recording
async function startRecording() {
  try {
    // Request microphone access
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: config.audioQuality
    });

    // Announce to screen readers
    announceToScreenReader('Recording started. Press the record button again to stop.');

    // Update UI
    recordButton.classList.add('recording');
    recordButton.setAttribute('aria-label', 'Stop recording');
    audioVisualizer.classList.remove('hidden');
    audioChunks = [];
    isRecording = true;

    // Create media recorder
    mediaRecorder = new MediaRecorder(stream);
    
    // Handle data available event
    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        audioChunks.push(event.data);
      }
    };

    // Handle recording stop event
    mediaRecorder.onstop = () => {
      // Create audio blob
      audioBlob = new Blob(audioChunks, { type: config.audioFormat });
      
      // Stop all tracks in the stream
      stream.getTracks().forEach(track => track.stop());
      
      // Show audio controls
      audioVisualizer.classList.add('hidden');
      audioControls.classList.remove('hidden');
      
      // Stop timer and visualizer
      clearInterval(timerInterval);
      clearInterval(visualizerInterval);
      
      // Update UI
      recordButton.classList.remove('recording');
      recordButton.setAttribute('aria-label', 'Record audio message');
      isRecording = false;
    };

    // Start recording
    mediaRecorder.start();
    recordingStartTime = Date.now();
    
    // Start timer
    startTimer();
    
    // Start visualizer
    startVisualizer(stream);
    
    // Set maximum recording time
    setTimeout(() => {
      if (mediaRecorder && mediaRecorder.state === 'recording') {
        stopRecording();
      }
    }, config.maxRecordingTime * 1000);
    
  } catch (error) {
    console.error('Error starting recording:', error);
    announceToScreenReader('Could not access microphone. Please check permissions and try again.');
    
    // Show error in UI
    recordButton.classList.remove('recording');
    isRecording = false;
  }
}

// Stop recording
function stopRecording() {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.stop();
  }
}

// Cancel recording
function cancelRecording() {
  // Reset UI
  audioControls.classList.add('hidden');
  audioVisualizer.classList.add('hidden');
  
  // Clear audio data
  audioChunks = [];
  audioBlob = null;
  
  // Announce to screen readers
  announceToScreenReader('Recording canceled.');
}

// Send audio message
async function sendAudioMessage() {
  if (!audioBlob) {
    return;
  }
  
  try {
    // Create form data
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.' + config.audioFormat.split('/')[1]);
    
    // Show sending indicator
    const messageContainer = document.querySelector('.chat-messages');
    const sendingMessage = document.createElement('div');
    sendingMessage.className = 'message user';
    sendingMessage.innerHTML = `
      <div class="message-content">
        <div class="message-sender">You</div>
        <div class="message-text">
          <p><em>Voice message (processing...)</em></p>
        </div>
        <div class="message-time">${getCurrentTime()}</div>
      </div>
      <div class="message-avatar">
        <img src="assets/icons/user-avatar.png" alt="User">
      </div>
    `;
    messageContainer.appendChild(sendingMessage);
    messageContainer.scrollTop = messageContainer.scrollHeight;
    
    // Reset UI
    audioControls.classList.add('hidden');
    
    // Announce to screen readers
    announceToScreenReader('Voice message sent. Processing audio...');
    
    // In a real implementation, you would send the audio to a server for processing
    // For this demo, we'll simulate a response after a short delay
    setTimeout(() => {
      // Update the message to show it's been processed
      sendingMessage.querySelector('.message-text p').innerHTML = '<em>Voice message</em> <audio controls src="' + URL.createObjectURL(audioBlob) + '"></audio>';
      
      // Add assistant response
      const assistantMessage = document.createElement('div');
      assistantMessage.className = 'message assistant';
      assistantMessage.innerHTML = `
        <div class="message-avatar">
          <img src="assets/icons/assistant-avatar.png" alt="Assistant">
        </div>
        <div class="message-content">
          <div class="message-sender">Care Mate Assistant</div>
          <div class="message-text">
            <p>I've received your voice message. How else can I help you with your plan review preparation?</p>
          </div>
          <div class="message-time">${getCurrentTime()}</div>
        </div>
      `;
      messageContainer.appendChild(assistantMessage);
      messageContainer.scrollTop = messageContainer.scrollHeight;
      
      // Announce to screen readers
      announceToScreenReader('Assistant responded to your voice message.');
    }, 2000);
    
    // Clear audio data
    audioChunks = [];
    audioBlob = null;
    
  } catch (error) {
    console.error('Error sending audio message:', error);
    announceToScreenReader('Error sending voice message. Please try again.');
  }
}

// Start timer
function startTimer() {
  updateTimer();
  timerInterval = setInterval(updateTimer, 1000);
}

// Update timer display
function updateTimer() {
  const elapsedSeconds = Math.floor((Date.now() - recordingStartTime) / 1000);
  const minutes = Math.floor(elapsedSeconds / 60);
  const seconds = elapsedSeconds % 60;
  audioTimer.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

// Start audio visualizer
function startVisualizer(stream) {
  try {
    // Create audio context
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const audioSource = audioContext.createMediaStreamSource(stream);
    const analyser = audioContext.createAnalyser();
    
    analyser.fftSize = 256;
    audioSource.connect(analyser);
    
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    
    const visualizerBars = document.querySelectorAll('.visualizer-bar');
    
    // Update visualizer
    visualizerInterval = setInterval(() => {
      analyser.getByteFrequencyData(dataArray);
      
      // Calculate average levels for each bar
      const barCount = visualizerBars.length;
      const samplesPerBar = Math.floor(bufferLength / barCount);
      
      for (let i = 0; i < barCount; i++) {
        let sum = 0;
        for (let j = 0; j < samplesPerBar; j++) {
          sum += dataArray[i * samplesPerBar + j];
        }
        const average = sum / samplesPerBar;
        
        // Scale the bar height (0-100)
        const height = Math.max(3, Math.min(30, average / 2.55));
        visualizerBars[i].style.height = `${height}px`;
      }
    }, config.visualizerUpdateInterval);
    
  } catch (error) {
    console.error('Error creating audio visualizer:', error);
  }
}

// Get current time in HH:MM format
function getCurrentTime() {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const formattedHours = hours % 12 || 12;
  const formattedMinutes = minutes.toString().padStart(2, '0');
  return `${formattedHours}:${formattedMinutes} ${ampm}`;
}

// Announce message to screen readers
function announceToScreenReader(message) {
  if (srAnnouncer) {
    srAnnouncer.textContent = message;
  }
}

// Initialize when DOM is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Export for testing
export default {
  toggleRecording,
  cancelRecording,
  sendAudioMessage
};
