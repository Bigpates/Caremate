/**
 * Care Mate - Enhanced Service Worker
 * 
 * This service worker provides advanced PWA capabilities including:
 * - Intelligent caching strategies
 * - Background sync with retry logic
 * - Rich push notifications
 * - Offline content management
 * - Performance optimization
 */

// Cache names
const STATIC_CACHE = 'care-mate-static-v1';
const DYNAMIC_CACHE = 'care-mate-dynamic-v1';
const API_CACHE = 'care-mate-api-v1';
const PREFETCH_CACHE = 'care-mate-prefetch-v1';
const IMAGE_CACHE = 'care-mate-images-v1';

// Resources to cache immediately
const STATIC_RESOURCES = [
  '/',
  '/index.html',
  '/chat.html',
  '/documents.html',
  '/offline.html',
  '/css/styles.css',
  '/css/accessibility.css',
  '/css/mobile.css',
  '/css/mobile-accessibility.css',
  '/js/main.js',
  '/js/audio-recorder.js',
  '/assets/icons/icon-192x192.png',
  '/assets/icons/icon-512x512.png',
  '/assets/icons/badge-96x96.png',
  '/assets/placeholder-hero.png'
];

// API endpoints to cache with network-first strategy
const API_ENDPOINTS = [
  '/api/user',
  '/api/plans',
  '/api/providers'
];

// Default configuration
let config = {
  cachingStrategy: {
    staticResources: 'cache-first',
    apiRequests: 'network-first',
    dynamicContent: 'stale-while-revalidate'
  },
  offlineSupport: {
    enabled: true,
    fallbackPage: '/offline.html'
  },
  backgroundSync: {
    enabled: true,
    maxRetries: 5,
    syncTag: 'care-mate-sync'
  },
  pushNotifications: {
    enabled: true,
    groupSimilar: true,
    maxPerHour: 5
  },
  prefetching: {
    enabled: true,
    maxItems: 20
  }
};

// Install event - cache static resources
self.addEventListener('install', event => {
  console.log('[Service Worker] Installing...');
  
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then(cache => {
        console.log('[Service Worker] Precaching static resources');
        return cache.addAll(STATIC_RESOURCES);
      })
      .then(() => {
        console.log('[Service Worker] Installation complete');
        return self.skipWaiting();
      })
      .catch(error => {
        console.error('[Service Worker] Installation failed:', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  console.log('[Service Worker] Activating...');
  
  const currentCaches = [
    STATIC_CACHE,
    DYNAMIC_CACHE,
    API_CACHE,
    PREFETCH_CACHE,
    IMAGE_CACHE
  ];
  
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => {
            if (!currentCaches.includes(cacheName)) {
              console.log('[Service Worker] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('[Service Worker] Activation complete');
        return self.clients.claim();
      })
      .catch(error => {
        console.error('[Service Worker] Activation failed:', error);
      })
  );
});

// Fetch event - handle requests with appropriate caching strategies
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  
  // Skip non-GET requests
  if (event.request.method !== 'GET') {
    return;
  }
  
  // Skip browser extensions and other non-http(s) requests
  if (!url.protocol.startsWith('http')) {
    return;
  }
  
  // Handle API requests
  if (isApiRequest(event.request)) {
    event.respondWith(handleApiRequest(event.request));
    return;
  }
  
  // Handle static resources
  if (isStaticResource(event.request)) {
    event.respondWith(handleStaticResource(event.request));
    return;
  }
  
  // Handle image requests
  if (isImageRequest(event.request)) {
    event.respondWith(handleImageRequest(event.request));
    return;
  }
  
  // Handle HTML navigation requests
  if (isHtmlRequest(event.request)) {
    event.respondWith(handleHtmlRequest(event.request));
    return;
  }
  
  // Handle all other requests with stale-while-revalidate
  event.respondWith(handleDynamicRequest(event.request));
});

// Push event - handle push notifications
self.addEventListener('push', event => {
  console.log('[Service Worker] Push received:', event);
  
  if (!event.data) {
    console.log('[Service Worker] Push received but no data');
    return;
  }
  
  try {
    // Parse notification data
    const data = event.data.json();
    
    // Check if notifications are enabled
    if (!config.pushNotifications.enabled) {
      console.log('[Service Worker] Push notifications are disabled');
      return;
    }
    
    // Check if we should throttle notifications
    if (shouldThrottleNotification(data.category)) {
      console.log('[Service Worker] Notification throttled');
      return;
    }
    
    // Show notification
    const title = data.title || 'Care Mate';
    const options = {
      body: data.body || '',
      icon: data.icon || '/assets/icons/icon-192x192.png',
      badge: data.badge || '/assets/icons/badge-96x96.png',
      data: {
        url: data.url || '/',
        category: data.category || 'general',
        timestamp: Date.now()
      }
    };
    
    // Add vibration if specified
    if (data.vibrate) {
      options.vibrate = data.vibrate;
    }
    
    // Add actions if specified
    if (data.actions && Array.isArray(data.actions)) {
      options.actions = data.actions;
    }
    
    // Show notification
    event.waitUntil(
      self.registration.showNotification(title, options)
        .then(() => {
          // Track notification for throttling
          trackNotification(data.category);
        })
    );
  } catch (error) {
    console.error('[Service Worker] Error showing notification:', error);
  }
});

// Notification click event - handle notification clicks
self.addEventListener('notificationclick', event => {
  console.log('[Service Worker] Notification clicked:', event.notification);
  
  // Close the notification
  event.notification.close();
  
  // Get notification data
  const data = event.notification.data || {};
  const url = data.url || '/';
  
  // Handle action clicks
  if (event.action) {
    console.log('[Service Worker] Action clicked:', event.action);
    
    // Handle specific actions
    switch (event.action) {
      case 'view':
        // Open the URL
        event.waitUntil(handleNotificationClick(url));
        break;
        
      case 'dismiss':
        // Just close the notification
        break;
        
      default:
        // For custom actions, we might have action-specific URLs
        const actionUrl = data[`${event.action}Url`] || url;
        event.waitUntil(handleNotificationClick(actionUrl));
    }
  } else {
    // Default click behavior - open the URL
    event.waitUntil(handleNotificationClick(url));
  }
});

// Sync event - handle background sync
self.addEventListener('sync', event => {
  console.log('[Service Worker] Background sync:', event.tag);
  
  if (event.tag === config.backgroundSync.syncTag) {
    event.waitUntil(handleBackgroundSync());
  }
});

// Periodic sync event - handle periodic background sync
self.addEventListener('periodicsync', event => {
  console.log('[Service Worker] Periodic sync:', event.tag);
  
  if (event.tag === 'ndis-updates') {
    event.waitUntil(handlePeriodicSync());
  }
});

// Message event - handle messages from clients
self.addEventListener('message', event => {
  console.log('[Service Worker] Message received:', event.data);
  
  if (!event.data) {
    return;
  }
  
  switch (event.data.type) {
    case 'CONFIGURE_DYNAMIC_CACHING':
      // Update caching configuration
      updateCachingConfig(event.data.config);
      break;
      
    case 'UPDATE_CONTENT':
      // Update cached content
      event.waitUntil(updateCachedContent());
      break;
      
    case 'SKIP_WAITING':
      // Skip waiting and activate new service worker
      self.skipWaiting();
      break;
  }
});

/**
 * Check if a request is for an API endpoint
 * @param {Request} request - The request to check
 * @returns {boolean} Whether the request is for an API endpoint
 */
function isApiRequest(request) {
  const url = new URL(request.url);
  return url.pathname.startsWith('/api/');
}

/**
 * Check if a request is for a static resource
 * @param {Request} request - The request to check
 * @returns {boolean} Whether the request is for a static resource
 */
function isStaticResource(request) {
  const url = new URL(request.url);
  
  // Check if it's in our static resources list
  if (STATIC_RESOURCES.includes(url.pathname)) {
    return true;
  }
  
  // Check file extensions for common static resources
  const staticExtensions = ['.css', '.js', '.woff', '.woff2', '.ttf', '.eot'];
  return staticExtensions.some(ext => url.pathname.endsWith(ext));
}

/**
 * Check if a request is for an image
 * @param {Request} request - The request to check
 * @returns {boolean} Whether the request is for an image
 */
function isImageRequest(request) {
  const url = new URL(request.url);
  const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.svg', '.webp', '.ico'];
  return imageExtensions.some(ext => url.pathname.endsWith(ext));
}

/**
 * Check if a request is for an HTML document
 * @param {Request} request - The request to check
 * @returns {boolean} Whether the request is for an HTML document
 */
function isHtmlRequest(request) {
  const url = new URL(request.url);
  const acceptHeader = request.headers.get('Accept') || '';
  
  // Check if it's a navigation request
  if (request.mode === 'navigate') {
    return true;
  }
  
  // Check if it accepts HTML
  if (acceptHeader.includes('text/html')) {
    return true;
  }
  
  // Check file extension
  return url.pathname.endsWith('.html') || url.pathname.endsWith('/');
}

/**
 * Handle API requests with network-first strategy
 * @param {Request} request - The request to handle
 * @returns {Promise<Response>} The response
 */
async function handleApiRequest(request) {
  const cache = await caches.open(API_CACHE);
  
  try {
    // Try network first
    const response = await fetch(request);
    
    // Cache successful responses
    if (response.ok) {
      await cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    console.log('[Service Worker] Network request failed, falling back to cache:', request.url);
    
    // Try cache
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // If not in cache, return a generic error response
    return new Response(JSON.stringify({
      error: 'Network request failed and no cached data available',
      offline: true
    }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

/**
 * Handle static resources with cache-first strategy
 * @param {Request} request - The request to handle
 * @returns {Promise<Response>} The response
 */
async function handleStaticResource(request) {
  const cache = await caches.open(STATIC_CACHE);
  
  // Try cache first
  const cachedResponse = await cache.match(request);
  
  if (cachedResponse) {
    // Update cache in the background
    updateStaticResourceInBackground(request, cache);
    return cachedResponse;
  }
  
  // If not in cache, get from network
  try {
    const response = await fetch(request);
    
    // Cache successful responses
    if (response.ok) {
      await cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    console.error('[Service Worker] Failed to fetch static resource:', error);
    
    // Return a generic error response
    return new Response('Failed to load resource', {
      status: 500,
      headers: { 'Content-Type': 'text/plain' }
    });
  }
}

/**
 * Update a static resource in the background
 * @param {Request} request - The request to update
 * @param {Cache} cache - The cache to update
 */
async function updateStaticResourceInBackground(request, cache) {
  try {
    const response = await fetch(request);
    
    if (response.ok) {
      await cache.put(request, response);
      console.log('[Service Worker] Updated static resource in background:', request.url);
    }
  } catch (error) {
    // Ignore errors, this is just a background update
  }
}

/**
 * Handle image requests with cache-first strategy
 * @param {Request} request - The request to handle
 * @returns {Promise<Response>} The response
 */
async function handleImageRequest(request) {
  const cache = await caches.open(IMAGE_CACHE);
  
  // Try cache first
  const cachedResponse = await cache.match(request);
  
  if (cachedResponse) {
    return cachedResponse;
  }
  
  // If not in cache, get from network
  try {
    const response = await fetch(request);
    
    // Cache successful responses
    if (response.ok) {
      await cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    console.error('[Service Worker] Failed to fetch image:', error);
    
    // Return a placeholder image if available
    const placeholderResponse = await cache.match('/assets/placeholder-hero.png');
    
    if (placeholderResponse) {
      return placeholderResponse;
    }
    
    // Return a generic error response
    return new Response('Image not available', {
      status: 404,
      headers: { 'Content-Type': 'text/plain' }
    });
  }
}

/**
 * Handle HTML requests with network-first strategy
 * @param {Request} request - The request to handle
 * @returns {Promise<Response>} The response
 */
async function handleHtmlRequest(request) {
  const cache = await caches.open(DYNAMIC_CACHE);
  
  try {
    // Try network first
    const response = await fetch(request);
    
    // Cache successful responses
    if (response.ok) {
      await cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    console.log('[Service Worker] Network request failed, falling back to cache:', request.url);
    
    // Try cache
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // If not in cache, return offline page
    if (config.offlineSupport.enabled) {
      const offlineResponse = await cache.match(config.offlineSupport.fallbackPage);
      
      if (offlineResponse) {
        return offlineResponse;
      }
    }
    
    // If offline page not available, return a generic error response
    return new Response('You are offline and this page is not available', {
      status: 503,
      headers: { 'Content-Type': 'text/plain' }
    });
  }
}

/**
 * Handle dynamic requests with stale-while-revalidate strategy
 * @param {Request} request - The request to handle
 * @returns {Promise<Response>} The response
 */
async function handleDynamicRequest(request) {
  const cache = await caches.open(DYNAMIC_CACHE);
  
  // Try cache first
  const cachedResponse = await cache.match(request);
  
  // Update cache in the background
  const fetchPromise = fetch(request)
    .then(response => {
      if (response.ok) {
        cache.put(request, response.clone());
      }
      return response;
    })
    .catch(error => {
      console.error('[Service Worker] Failed to fetch dynamic resource:', error);
      return null;
    });
  
  // Return cached response if available, otherwise wait for fetch
  return cachedResponse || fetchPromise;
}

/**
 * Handle notification click
 * @param {string} url - URL to open
 * @returns {Promise<void>} Promise that resolves when the URL is opened
 */
async function handleNotificationClick(url) {
  // Get all windows clients
  const clients = await self.clients.matchAll({
    type: 'window',
    includeUncontrolled: true
  });
  
  // Check if a window client is already open
  for (const client of clients) {
    if (client.url === url && 'focus' in client) {
      // Focus the existing window
      await client.focus();
      return;
    }
  }
  
  // If no matching client found, open a new window
  if (self.clients.openWindow) {
    await self.clients.openWindow(url);
  }
}

/**
 * Handle background sync
 * @returns {Promise<void>} Promise that resolves when sync is complete
 */
async function handleBackgroundSync() {
  if (!config.backgroundSync.enabled) {
    console.log('[Service Worker] Background sync is disabled');
    return;
  }
  
  try {
    // Open IndexedDB to get queued requests
    const db = await openSyncDatabase();
    const tx = db.transaction('sync-store', 'readwrite');
    const store = tx.objectStore('sync-store');
    const index = store.index('status');
    
    // Get all pending requests
    const pendingRequests = await index.getAll('pending');
    
    console.log(`[Service Worker] Processing ${pendingRequests.length} queued requests`);
    
    let successCount = 0;
    let failureCount = 0;
    
    // Process each request
    for (const request of pendingRequests) {
      try {
        // Try to send the request
        const result = await processSyncRequest(request);
        
        if (result.success) {
          // Mark as completed
          request.status = 'completed';
          request.completedAt = Date.now();
          successCount++;
        } else {
          // Increment retry count
          request.retries = (request.retries || 0) + 1;
          
          // Check if max retries reached
          if (request.retries >= config.backgroundSync.maxRetries) {
            request.status = 'failed';
            request.error = result.error;
            failureCount++;
          } else {
            // Keep as pending for next sync
            request.lastRetry = Date.now();
          }
        }
        
        // Update request in store
        await store.put(request);
      } catch (error) {
        console.error('[Service Worker] Error processing sync request:', error);
        failureCount++;
      }
    }
    
    // Close transaction
    await tx.complete;
    
    // Notify clients about sync completion
    const syncResult = {
      type: 'SYNC_COMPLETED',
      timestamp: Date.now(),
      totalCount: pendingRequests.length,
      successCount,
      failureCount
    };
    
    // Broadcast to all clients
    const clients = await self.clients.matchAll();
    clients.forEach(client => {
      client.postMessage(syncResult);
    });
    
    console.log(`[Service Worker] Sync completed: ${successCount} succeeded, ${failureCount} failed`);
  } catch (error) {
    console.error('[Service Worker] Background sync failed:', error);
  }
}

/**
 * Process a sync request
 * @param {Object} request - The request to process
 * @returns {Promise<Object>} Result of the sync operation
 */
async function processSyncRequest(request) {
  try {
    // Create fetch request from stored data
    const fetchRequest = new Request(request.url, {
      method: request.method,
      headers: request.headers,
      body: request.body,
      mode: 'cors',
      credentials: 'include'
    });
    
    // Send the request
    const response = await fetch(fetchRequest);
    
    if (response.ok) {
      return {
        success: true,
        response
      };
    } else {
      return {
        success: false,
        error: `Server responded with ${response.status}: ${response.statusText}`
      };
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Open the sync database
 * @returns {Promise<IDBDatabase>} IndexedDB database
 */
function openSyncDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('care-mate-sync-db', 1);
    
    request.onerror = event => {
      reject(new Error('Failed to open database'));
    };
    
    request.onsuccess = event => {
      resolve(event.target.result);
    };
    
    request.onupgradeneeded = event => {
      const db = event.target.result;
      
      // Create object store for sync actions
      if (!db.objectStoreNames.contains('sync-store')) {
        const store = db.createObjectStore('sync-store', { keyPath: 'id' });
        store.createIndex('status', 'status', { unique: false });
        store.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };
  });
}

/**
 * Handle periodic sync
 * @returns {Promise<void>} Promise that resolves when periodic sync is complete
 */
async function handlePeriodicSync() {
  try {
    console.log('[Service Worker] Performing periodic sync');
    
    // Update cached content
    await updateCachedContent();
    
    // Check for new notifications
    await checkForNewNotifications();
    
    console.log('[Service Worker] Periodic sync completed');
  } catch (error) {
    console.error('[Service Worker] Periodic sync failed:', error);
  }
}

/**
 * Update cached content
 * @returns {Promise<void>} Promise that resolves when content is updated
 */
async function updateCachedContent() {
  try {
    // Update static resources
    const staticCache = await caches.open(STATIC_CACHE);
    
    for (const resource of STATIC_RESOURCES) {
      try {
        const response = await fetch(resource);
        
        if (response.ok) {
          await staticCache.put(resource, response);
        }
      } catch (error) {
        console.error(`[Service Worker] Failed to update ${resource}:`, error);
      }
    }
    
    // Update API resources
    const apiCache = await caches.open(API_CACHE);
    
    for (const endpoint of API_ENDPOINTS) {
      try {
        const response = await fetch(endpoint);
        
        if (response.ok) {
          await apiCache.put(endpoint, response);
        }
      } catch (error) {
        console.error(`[Service Worker] Failed to update ${endpoint}:`, error);
      }
    }
    
    // Notify clients about content update
    const clients = await self.clients.matchAll();
    clients.forEach(client => {
      client.postMessage({
        type: 'CACHE_UPDATED',
        timestamp: Date.now()
      });
    });
    
    console.log('[Service Worker] Cached content updated');
  } catch (error) {
    console.error('[Service Worker] Failed to update cached content:', error);
  }
}

/**
 * Check for new notifications
 * @returns {Promise<void>} Promise that resolves when notifications are checked
 */
async function checkForNewNotifications() {
  try {
    // This would normally fetch from an API
    // For now, we'll just simulate it
    console.log('[Service Worker] Checking for new notifications');
    
    // In a real app, we would fetch from an API and show notifications
  } catch (error) {
    console.error('[Service Worker] Failed to check for notifications:', error);
  }
}

/**
 * Update caching configuration
 * @param {Object} newConfig - New configuration
 */
function updateCachingConfig(newConfig) {
  if (!newConfig) {
    return;
  }
  
  console.log('[Service Worker] Updating caching configuration:', newConfig);
  
  // Update config
  config = {
    ...config,
    ...newConfig
  };
}

/**
 * Check if a notification should be throttled
 * @param {string} category - Notification category
 * @returns {boolean} Whether the notification should be throttled
 */
function shouldThrottleNotification(category) {
  // Get notification history from last hour
  const now = Date.now();
  const oneHourAgo = now - (60 * 60 * 1000);
  
  // Get notification history from storage
  const notificationHistory = getNotificationHistory();
  
  // Filter to recent notifications
  const recentNotifications = notificationHistory.filter(notification => {
    return notification.timestamp > oneHourAgo;
  });
  
  // Count notifications in this category
  const categoryCount = recentNotifications.filter(notification => {
    return notification.category === category;
  }).length;
  
  // Check if we've exceeded the limit
  return categoryCount >= config.pushNotifications.maxPerHour;
}

/**
 * Track a notification for throttling
 * @param {string} category - Notification category
 */
function trackNotification(category) {
  // Get notification history
  const notificationHistory = getNotificationHistory();
  
  // Add new notification
  notificationHistory.push({
    category,
    timestamp: Date.now()
  });
  
  // Keep only last 100 notifications
  if (notificationHistory.length > 100) {
    notificationHistory.shift();
  }
  
  // Save notification history
  saveNotificationHistory(notificationHistory);
}

/**
 * Get notification history from storage
 * @returns {Array} Notification history
 */
function getNotificationHistory() {
  try {
    const history = self.registration.scope.notificationHistory;
    
    if (history) {
      return JSON.parse(history);
    }
  } catch (error) {
    // Ignore errors
  }
  
  return [];
}

/**
 * Save notification history to storage
 * @param {Array} history - Notification history
 */
function saveNotificationHistory(history) {
  try {
    self.registration.scope.notificationHistory = JSON.stringify(history);
  } catch (error) {
    // Ignore errors
  }
}
