# Care Mate NDIS AI Application - User Guide

## Introduction

Welcome to Care Mate, your AI-powered assistant for navigating the NDIS with confidence. This guide will help you understand the features and functionality of the Care Mate application, including the newly enhanced user interface and interactive elements.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Navigation](#navigation)
3. [Key Features](#key-features)
4. [Accessibility Options](#accessibility-options)
5. [Interactive Elements](#interactive-elements)
6. [Mobile Experience](#mobile-experience)
7. [Offline Capabilities](#offline-capabilities)
8. [Voice Input](#voice-input)
9. [Troubleshooting](#troubleshooting)
10. [Contact Support](#contact-support)

## Getting Started

When you first visit Care Mate, you'll be greeted with a welcome tour that introduces you to the key features of the application. This tour will guide you through:

- The AI assistant capabilities
- Personalized support options
- Progress tracking features

You can revisit this tour at any time by clicking the "Take a Tour" button on the home page.

## Navigation

The Care Mate application features an intuitive navigation system:

- **Main Navigation**: Located at the top of the screen, providing access to Home, Chat, Documents, Plan Management, and Providers sections.
- **Quick Access Controls**: Search, notifications, accessibility options, and user profile are available in the top-right corner.
- **Mobile Navigation**: On smaller screens, the main navigation collapses into a hamburger menu that can be toggled to access all sections.

## Key Features

### AI Assistant
Access the AI assistant through the Chat section to get instant answers to your NDIS questions and personalized support.

### Plan Management
Track and manage your NDIS plan, budgets, and spending with visual reports and insights.

### Provider Search
Find and connect with suitable service providers in your area based on location, service type, and ratings.

### Progress Tracking
Monitor your goals and track progress with visual reports that help you stay on track with your NDIS goals.

## Accessibility Options

Care Mate is designed to be accessible to all users. The accessibility panel can be accessed by clicking the accessibility icon in the top-right corner of the screen.

### Available Options:

- **Text Size**: Increase or decrease text size for better readability.
- **High Contrast**: Toggle high contrast mode for improved visibility.
- **Dyslexia Font**: Enable a font designed to be more readable for users with dyslexia.
- **Screen Reader Mode**: Optimize the interface for screen reader compatibility with additional descriptions and context.
- **Voice Input**: Enable voice input for hands-free interaction (see [Voice Input](#voice-input) section).
- **Reduce Motion**: Minimize animations and transitions for users sensitive to motion.
- **Focus Mode**: Simplify the interface to reduce distractions.

All accessibility settings are saved between sessions, so you only need to set them once.

## Interactive Elements

Care Mate features several interactive elements designed to enhance your experience:

### Feature Cards
Hover or focus on feature cards to reveal additional information and quick access links.

### How It Works Steps
Click the information icon on each step to learn more about that part of the process.

### Testimonial Carousel
Navigate through user testimonials using the arrow buttons or indicator dots. The carousel also rotates automatically.

### Feedback Form
Share your thoughts and suggestions by clicking the "Give Feedback" button in the footer.

## Mobile Experience

Care Mate is fully responsive and optimized for mobile devices:

- The navigation menu collapses into a hamburger menu for easy access.
- Touch targets are sized appropriately for comfortable tapping.
- Swipe gestures are supported for carousels and other interactive elements.
- The layout adjusts dynamically to provide an optimal experience on any screen size.

## Offline Capabilities

Care Mate includes Progressive Web App (PWA) features that allow you to use many functions even when offline:

- **Offline Access**: Basic information and previously loaded content remain accessible.
- **Automatic Sync**: Any actions performed while offline will sync automatically when you reconnect.
- **Installation**: You can install Care Mate on your device for quick access by selecting "Add to Home Screen" from your browser menu.

## Voice Input

Care Mate supports voice input for hands-free interaction:

1. Enable voice input through the accessibility panel.
2. When in the Chat section, click the microphone icon to start recording.
3. Speak clearly to send your message or request to the AI assistant.
4. Review the transcribed text before sending.

**Note**: When using voice input for the first time, you'll need to grant microphone permission. Some browsers may display this permission request differently, and you may need to adjust your browser settings if you initially denied permission.

## Troubleshooting

### Common Issues and Solutions

#### Page Not Loading
- Check your internet connection
- Try refreshing the page
- Clear your browser cache

#### Accessibility Settings Not Saving
- Ensure cookies are enabled in your browser
- Try using a different browser if the issue persists

#### Voice Input Not Working
- Check that you've granted microphone permissions
- Ensure your microphone is working properly
- Try using a different browser if the issue persists

#### Video Playback Issues
- Ensure your browser is up to date
- Check that JavaScript is enabled
- Try using a different browser if the issue persists

## Contact Support

If you encounter any issues or have questions about Care Mate:

- Email: support@caremate.example.com
- Phone: (02) 1234 5678
- Hours: Monday to Friday, 9am to 5pm AEST

You can also use the feedback form within the application to report issues or suggest improvements.

---

Thank you for choosing Care Mate as your NDIS assistant. We're committed to providing you with the best possible experience and welcome your feedback to help us improve.
