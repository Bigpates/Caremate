# NDIS API Integration Documentation

## Overview

The NDIS API Integration module provides a comprehensive set of tools for interacting with NDIS APIs, handling data transformation, caching, error management, and real-time updates. This documentation covers the architecture, usage, configuration options, and best practices for implementing these tools in the Care Mate application.

## Table of Contents

1. [Architecture](#architecture)
2. [Components](#components)
3. [Installation](#installation)
4. [Basic Usage](#basic-usage)
5. [Advanced Features](#advanced-features)
6. [Configuration Options](#configuration-options)
7. [Error Handling](#error-handling)
8. [Performance Optimization](#performance-optimization)
9. [Cross-Environment Compatibility](#cross-environment-compatibility)
10. [Testing and Validation](#testing-and-validation)

## Architecture

The NDIS API Integration module follows a modular architecture with clear separation of concerns:

```
┌─────────────────────────────────────────────────────────────┐
│                      Application Layer                      │
└───────────────────────────┬─────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────┐
│                    API Integration Layer                    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ API Client  │  │    Cache    │  │ Real-Time Updates  │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │    Data     │  │    Error    │  │ Advanced Search &   │  │
│  │ Transformer │  │   Handler   │  │ Profile Management  │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└───────────────────────────┬─────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────┐
│                     Storage Adapter Layer                   │
└─────────────────────────────────────────────────────────────┘
```

This architecture ensures:
- **Modularity**: Each component has a single responsibility
- **Extensibility**: New features can be added without modifying existing code
- **Testability**: Components can be tested in isolation
- **Cross-environment compatibility**: Works in both browser and Node.js environments

## Components

### NDISApiClient

The API client handles communication with NDIS endpoints, including authentication, request formatting, and response parsing.

**Key Features:**
- Token-based authentication with automatic refresh
- Retry logic for failed requests
- Rate limiting handling
- Comprehensive endpoint coverage for NDIS services

### NDISApiCacheManager

The cache manager improves performance by storing API responses locally, reducing unnecessary network requests.

**Key Features:**
- Time-based cache expiration
- LRU (Least Recently Used) eviction strategy
- Cross-environment storage support
- Automatic cache invalidation

### NDISDataTransformer

The data transformer normalizes and formats NDIS data structures for consistent use throughout the application.

**Key Features:**
- Plan data normalization
- Participant data normalization
- Budget and support category formatting
- Date and currency formatting utilities

### NDISErrorHandler

The error handler provides standardized error formatting, logging, and recovery strategies.

**Key Features:**
- Consistent error normalization
- User-friendly error messages
- Recovery suggestions
- Intelligent retry decision logic

### NDISRealTimeUpdates

The real-time updates module enables live data synchronization through WebSocket connections.

**Key Features:**
- Topic-based subscriptions
- Automatic reconnection
- Message handling framework
- Browser notification support

### NDISAdvancedSearch

The advanced search module provides powerful search capabilities across NDIS data.

**Key Features:**
- Fuzzy matching
- Multi-criteria filtering
- Location-based search
- Result highlighting

### NDISParticipantProfileManager

The participant profile manager maintains comprehensive records of NDIS participants.

**Key Features:**
- Profile creation and management
- Plan tracking and history
- Notes and preferences storage
- Profile synchronization

### NDISStorageAdapter

The storage adapter provides a consistent interface for data storage across different environments.

**Key Features:**
- Browser localStorage support
- Node.js memory/file storage
- Serialization and deserialization
- Error handling

## Installation

The NDIS API Integration module is included in the Care Mate application. No additional installation is required.

## Basic Usage

### Importing the API Integration

```javascript
// Import the API integration singleton
import apiIntegration from './api/index.js';

// Or import individual components
import { 
  NDISApiClient, 
  NDISDataTransformer 
} from './api/index.js';
```

### Fetching Participant Data

```javascript
// Using the API integration singleton
async function getParticipant(participantId) {
  try {
    const participant = await apiIntegration.getParticipantDetails(participantId);
    return participant;
  } catch (error) {
    console.error('Failed to fetch participant:', error);
    throw error;
  }
}

// Using the API client directly
async function getParticipantDirect(participantId) {
  const client = new NDISApiClient();
  
  try {
    const response = await client.getParticipantDetails(participantId);
    const normalizedData = NDISDataTransformer.normalizeParticipantData(response.data);
    return normalizedData;
  } catch (error) {
    console.error('Failed to fetch participant:', error);
    throw error;
  }
}
```

### Managing Participant Profiles

```javascript
import NDISParticipantProfileManager from './api/NDISParticipantProfileManager.js';

// Create profile manager
const profileManager = new NDISParticipantProfileManager();

// Create a new participant profile
const newParticipant = {
  id: 'participant-123',
  firstName: 'John',
  lastName: 'Doe',
  ndisNumber: 'NDIS12345678',
  dateOfBirth: new Date('1985-06-15')
};

const profile = profileManager.createProfile(newParticipant);

// Add a note to the profile
profileManager.addNote(
  'participant-123',
  'Initial meeting completed. Participant requires assistance with daily activities.',
  'meeting'
);

// Update plan information
const planData = {
  id: 'plan-456',
  startDate: new Date('2023-07-01'),
  endDate: new Date('2024-06-30'),
  status: 'active',
  goals: [/* ... */],
  budgets: [/* ... */]
};

profileManager.updatePlan('participant-123', planData, true);

// Search for profiles
const matchingProfiles = profileManager.searchProfiles({
  lastName: 'Doe'
});
```

### Using Advanced Search

```javascript
import NDISAdvancedSearch from './api/NDISAdvancedSearch.js';

// Create search instance
const search = new NDISAdvancedSearch();

// Search for providers
const providers = [/* ... array of provider objects ... */];
const searchResults = search.searchProviders(providers, {
  query: 'support',
  location: {
    latitude: -37.8136,
    longitude: 144.9631
  },
  radius: 10, // kilometers
  registrationGroups: ['Daily Personal Activities'],
  availability: {
    daysOfWeek: ['Monday', 'Wednesday', 'Friday']
  }
});
```

### Handling Errors

```javascript
import NDISErrorHandler from './api/NDISErrorHandler.js';

// Create error handler
const errorHandler = new NDISErrorHandler();

try {
  // API operation that might fail
  const result = await apiOperation();
  return result;
} catch (error) {
  // Normalize and handle the error
  const normalizedError = errorHandler.handleError(error, {
    endpoint: '/participants/123',
    method: 'GET'
  });
  
  // Get user-friendly message
  const userMessage = errorHandler.getUserFriendlyMessage(normalizedError);
  
  // Get recovery suggestions
  const suggestions = errorHandler.getRecoverySuggestions(normalizedError);
  
  // Display to user
  showErrorToUser(userMessage, suggestions);
  
  // Determine if retry is appropriate
  if (errorHandler.shouldRetry(normalizedError, 1)) {
    const retryDelay = errorHandler.getRetryDelay(normalizedError, 1);
    setTimeout(() => {
      // Retry the operation
      apiOperation();
    }, retryDelay);
  }
}
```

### Setting Up Real-Time Updates

```javascript
import NDISRealTimeUpdates from './api/NDISRealTimeUpdates.js';

// Create real-time updates instance
const realTimeUpdates = new NDISRealTimeUpdates();

// Connect to the WebSocket server
await realTimeUpdates.connect();

// Subscribe to updates for a specific participant
realTimeUpdates.subscribeToParticipant('participant-123', (message) => {
  console.log('Participant update received:', message);
  
  // Update UI or data based on the message
  if (message.type === 'plan_updated') {
    refreshPlanDisplay(message.data);
  }
});

// Register a handler for a specific message type
realTimeUpdates.registerMessageHandler('notification', (message) => {
  showNotification(message.title, message.body);
});

// Clean up when done
function cleanup() {
  realTimeUpdates.disconnect();
}
```

## Advanced Features

### Caching Strategies

The cache manager supports different caching strategies:

```javascript
import NDISApiCacheManager from './api/NDISApiCacheManager.js';

// Create cache with custom configuration
const cache = new NDISApiCacheManager({
  enabled: true,
  defaultTTL: 10 * 60 * 1000, // 10 minutes
  maxEntries: 200,
  storageKey: 'custom_cache_key'
});

// Set cache entry with custom TTL
cache.set('participant_123', participantData, 30 * 60 * 1000); // 30 minutes

// Get cached data
const cachedData = cache.get('participant_123');

// Check if data exists and is valid
if (cache.has('participant_123')) {
  // Use cached data
}

// Clear specific entry
cache.delete('participant_123');

// Clear entire cache
cache.clear();

// Dispose of resources when done
cache.dispose();
```

### Offline Support

The API integration can be configured to work offline:

```javascript
import apiIntegration from './api/index.js';

// Configure for offline mode
apiIntegration.configureOfflineMode({
  enabled: true,
  syncOnReconnect: true,
  persistenceLevel: 'session' // 'session', 'local', or 'none'
});

// Check if offline
if (apiIntegration.isOffline()) {
  showOfflineIndicator();
}

// Listen for online/offline events
apiIntegration.onConnectionChange((isOnline) => {
  if (isOnline) {
    hideOfflineIndicator();
    syncPendingChanges();
  } else {
    showOfflineIndicator();
  }
});
```

## Configuration Options

### API Client Configuration

```javascript
const apiClientConfig = {
  baseUrl: 'https://api.ndis.gov.au/v1',
  timeout: 30000, // 30 seconds
  retryAttempts: 3,
  retryDelay: 1000, // 1 second
  headers: {
    'X-API-Version': '2023-06-01'
  }
};

const client = new NDISApiClient(apiClientConfig);
```

### Cache Manager Configuration

```javascript
const cacheConfig = {
  enabled: true,
  defaultTTL: 5 * 60 * 1000, // 5 minutes
  maxEntries: 100,
  storageKey: 'ndis_api_cache'
};

const cache = new NDISApiCacheManager(cacheConfig);
```

### Error Handler Configuration

```javascript
const errorHandlerConfig = {
  logErrors: true,
  enableRetry: true,
  maxRetries: 3,
  retryDelay: 1000, // 1 second
  retryStatusCodes: [408, 429, 500, 502, 503, 504]
};

const errorHandler = new NDISErrorHandler(errorHandlerConfig);
```

### Real-Time Updates Configuration

```javascript
const realTimeConfig = {
  websocketUrl: 'wss://api.ndis.gov.au/v1/ws',
  reconnectInterval: 3000, // 3 seconds
  maxReconnectAttempts: 5,
  enableNotifications: true
};

const realTimeUpdates = new NDISRealTimeUpdates(realTimeConfig);
```

### Advanced Search Configuration

```javascript
const searchConfig = {
  fuzzyMatchThreshold: 0.7, // 0-1, higher = stricter matching
  maxResults: 50,
  enableHighlighting: true
};

const search = new NDISAdvancedSearch(searchConfig);
```

### Participant Profile Manager Configuration

```javascript
const profileConfig = {
  storageKey: 'ndis_participant_profiles',
  maxProfiles: 100,
  syncEnabled: true,
  syncInterval: 3600000 // 1 hour
};

const profileManager = new NDISParticipantProfileManager(profileConfig);
```

## Error Handling

### Error Codes

The error handler defines standard error codes:

| Code | Description | Retryable |
|------|-------------|-----------|
| `AUTH_FAILED` | Authentication failed | No |
| `TOKEN_EXPIRED` | Authentication token expired | No |
| `UNAUTHORIZED` | User not authorized for resource | No |
| `NETWORK_ERROR` | Network connection issue | Yes |
| `TIMEOUT` | Request timed out | Yes |
| `SERVER_UNAVAILABLE` | Server error or maintenance | Yes |
| `INVALID_REQUEST` | Invalid request parameters | No |
| `RESOURCE_NOT_FOUND` | Requested resource not found | No |
| `VALIDATION_ERROR` | Input validation failed | No |
| `RATE_LIMITED` | Too many requests | Yes |
| `UNKNOWN_ERROR` | Unspecified error | No |

### Error Normalization

The error handler normalizes errors from different sources into a consistent format:

```javascript
// Normalized error structure
{
  code: 'NETWORK_ERROR',
  message: 'Unable to connect to the server',
  details: 'TypeError: Failed to fetch',
  timestamp: Date,
  context: {
    endpoint: '/participants/123',
    method: 'GET',
    params: null
  },
  originalError: Error,
  retryable: true
}
```

### Error Recovery

The error handler provides recovery suggestions based on the error type:

```javascript
// Example recovery suggestions
{
  'NETWORK_ERROR': [
    'Check your internet connection',
    'Try again in a few minutes'
  ],
  'TIMEOUT': [
    'Try again later',
    'Contact support if the problem persists'
  ]
}
```

## Performance Optimization

### Caching

- Use appropriate TTL values based on data volatility
- Consider using shorter TTLs for frequently changing data
- Use longer TTLs for reference data that rarely changes

```javascript
// Example: Different TTLs for different data types
cache.set('participant_details', data, 5 * 60 * 1000);  // 5 minutes
cache.set('reference_data', data, 24 * 60 * 60 * 1000); // 24 hours
```

### Batch Operations

- Use batch operations when fetching multiple related items
- Combine multiple requests into a single request when possible

```javascript
// Instead of multiple individual requests
const participants = await Promise.all([
  apiIntegration.getParticipantDetails('123'),
  apiIntegration.getParticipantDetails('456'),
  apiIntegration.getParticipantDetails('789')
]);

// Use batch operation
const participants = await apiIntegration.getParticipantDetailsBatch(['123', '456', '789']);
```

### Selective Loading

- Only fetch the data you need
- Use field selection when supported by the API

```javascript
// Specify fields to include
const participant = await apiIntegration.getParticipantDetails('123', {
  fields: ['id', 'firstName', 'lastName', 'currentPlan']
});
```

## Cross-Environment Compatibility

The NDIS API Integration module is designed to work in both browser and Node.js environments.

### Storage Adapter

The storage adapter automatically detects the environment and uses the appropriate storage mechanism:

- In browsers: Uses `localStorage`
- In Node.js: Uses in-memory storage (can be extended to use file system)

```javascript
import NDISStorageAdapter from './api/NDISStorageAdapter.js';

const storage = new NDISStorageAdapter({
  storageKey: 'my_storage'
});

// Works in both browser and Node.js
storage.setItem('key', value);
const value = storage.getItem('key');
storage.removeItem('key');
storage.clear();
```

### Environment Detection

The module includes utilities for environment detection:

```javascript
import { isNodeEnvironment, isBrowserEnvironment } from './api/utils.js';

if (isBrowserEnvironment()) {
  // Browser-specific code
} else if (isNodeEnvironment()) {
  // Node.js-specific code
}
```

## Testing and Validation

The NDIS API Integration module includes comprehensive testing utilities:

### Validation Script

```javascript
import { validateApiIntegration } from './api/NDISApiValidation.js';

// Run validation
const results = await validateApiIntegration();

console.log(`Validation ${results.success ? 'passed' : 'failed'}`);
if (!results.success) {
  console.error('Errors:', results.errors);
}

// Check individual test results
Object.entries(results.tests).forEach(([testName, testResult]) => {
  console.log(`${testName}: ${testResult.success ? 'PASSED' : 'FAILED'}`);
  console.log(`Message: ${testResult.message}`);
});
```

### Mock Data

The module includes test data for validation:

```javascript
import { 
  TEST_PARTICIPANT, 
  TEST_PLAN, 
  TEST_PROVIDERS 
} from './api/NDISApiValidation.js';

// Use test data for development and testing
console.log(TEST_PARTICIPANT);
console.log(TEST_PLAN);
console.log(TEST_PROVIDERS);
```

## Conclusion

The NDIS API Integration module provides a comprehensive set of tools for interacting with NDIS APIs. By following the guidelines in this documentation, developers can effectively implement and extend these tools to meet the needs of the Care Mate application.

For additional support or questions, please contact the development team.
