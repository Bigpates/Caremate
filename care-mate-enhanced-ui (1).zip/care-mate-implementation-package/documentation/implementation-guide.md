# Care Mate NDIS AI Application - Implementation Guide

## Introduction

This guide will walk you through implementing the Care Mate NDIS AI application enhancements step by step. It's designed for non-developers and assumes no prior development experience. We'll cover everything from setting up your environment to activating and testing each feature.

## Table of Contents

1. [Required Tools](#required-tools)
2. [Preparing Your Environment](#preparing-your-environment)
3. [Extracting and Organizing Files](#extracting-and-organizing-files)
4. [API Integration Implementation](#api-integration-implementation)
5. [Audio Recording Implementation](#audio-recording-implementation)
6. [PWA Features Implementation](#pwa-features-implementation)
7. [Testing Your Implementation](#testing-your-implementation)
8. [Troubleshooting](#troubleshooting)
9. [Getting Help](#getting-help)

## Required Tools

Before starting, you'll need the following tools:

### 1. Web Browser
- **Recommended**: Google Chrome (version 90+) or Microsoft Edge (version 90+)
- These browsers have the best support for all features

### 2. File Management Tools
- **File Explorer** (Windows) or **Finder** (Mac) for navigating directories
- **7-Zip** (Windows) or built-in archive utility (Mac) for extracting ZIP files

### 3. Text Editor (for any minor adjustments if needed)
- **Recommended**: Notepad++ (Windows) or TextEdit (Mac)
- Only needed if you need to make small text changes to configuration files

### 4. Web Server Software (choose one)
- **Option A**: XAMPP (easiest for beginners)
- **Option B**: Web hosting service with FTP access
- **Option C**: Microsoft IIS (if you're on a Windows server)

## Preparing Your Environment

### Installing XAMPP (Option A - Recommended for beginners)

1. **Download XAMPP**:
   - Go to [https://www.apachefriends.org/](https://www.apachefriends.org/)
   - Download the version for your operating system (Windows, Mac, or Linux)

2. **Install XAMPP**:
   - Windows: Run the installer and follow the prompts
   - Mac: Open the DMG file and drag XAMPP to your Applications folder
   - Accept all default settings during installation

3. **Start XAMPP**:
   - Windows: Open the XAMPP Control Panel from your Start menu
   - Mac: Open XAMPP from your Applications folder
   - Click "Start" next to Apache (web server)

4. **Verify Installation**:
   - Open your web browser
   - Navigate to: http://localhost/
   - You should see the XAMPP welcome page

### Setting Up Web Hosting (Option B)

If you're using a web hosting service:

1. **Gather your credentials**:
   - FTP hostname (e.g., ftp.yourdomainname.com)
   - FTP username and password
   - Your website domain name

2. **Download an FTP client**:
   - FileZilla is recommended: [https://filezilla-project.org/](https://filezilla-project.org/)
   - Install it on your computer

3. **Connect to your hosting**:
   - Open FileZilla
   - Enter your FTP hostname, username, and password
   - Click "Quickconnect"

## Extracting and Organizing Files

### 1. Create Your Project Folder

If using XAMPP:

1. **Locate the htdocs folder**:
   - Windows: Usually at `C:\xampp\htdocs\`
   - Mac: Usually at `/Applications/XAMPP/xamppfiles/htdocs/`

2. **Create a folder for Care Mate**:
   - Create a new folder named `care-mate` inside the htdocs folder
   - This will be your project's root directory

If using web hosting:

1. **Navigate to your website's root directory** using FileZilla
2. **Create a folder** named `care-mate` (or use your preferred name)

### 2. Extract the Enhancement Files

1. **Locate the ZIP files** you received:
   - `api-integration-tools.zip`
   - `audio-recording-feature.zip`
   - `pwa-enhancements.zip`

2. **Extract each ZIP file**:
   - Right-click each ZIP file and select "Extract" or "Extract All"
   - Extract them to a temporary location on your computer

3. **Copy files to your project folder**:
   - Open the extracted folders
   - Copy all files and folders from each extracted directory
   - Paste them into your `care-mate` project folder

### 3. Organize the Project Structure

Ensure your project structure looks like this:

```
care-mate/
├── public/
│   ├── css/
│   ├── js/
│   ├── assets/
│   ├── enhanced-service-worker.js
│   ├── index.html
│   ├── chat.html
│   └── documents.html
├── src/
│   ├── api/
│   ├── audio/
│   ├── pwa/
│   └── main.js
└── documentation/
    ├── api-integration-documentation.md
    ├── audio-feature-documentation.md
    └── pwa-documentation.md
```

If the structure doesn't match exactly, create any missing folders and move files to their appropriate locations.

## API Integration Implementation

### 1. Configure the API Settings

1. **Locate the API configuration file**:
   - Navigate to `care-mate/src/api/`
   - Find the file named `NDISApiClient.js`

2. **Update the API endpoint** (if needed):
   - Open `NDISApiClient.js` with your text editor
   - Look for a line that contains `baseUrl:`
   - If you need to change the API endpoint, update this value
   - If you're using the default test endpoint, no changes are needed

### 2. Set Up API Cache Directory

1. **Create a cache directory**:
   - Navigate to `care-mate/public/`
   - Create a new folder named `cache`
   - Make sure this folder has write permissions:
     - Windows: Right-click > Properties > Security > Edit > Allow "Write" for Users
     - Mac/Linux: In terminal, run `chmod 755 cache` from the public directory

### 3. Link API Integration to Main Application

1. **Ensure the API is properly linked**:
   - Open `care-mate/public/index.html` with your text editor
   - Look for the following lines near the bottom of the file:

   ```html
   <script src="../src/api/index.js" type="module"></script>
   ```

   - If this line is missing, add it just before the closing `</body>` tag

## Audio Recording Implementation

### 1. Add Audio Recording Files to HTML

1. **Update the chat page**:
   - Open `care-mate/public/chat.html` with your text editor
   - Find the `<head>` section and add:

   ```html
   <link rel="stylesheet" href="css/audio-recorder.css">
   ```

   - Find the end of the file (before `</body>`) and add:

   ```html
   <script src="js/audio-recorder.js" type="module"></script>
   ```

### 2. Create Audio Storage Directory

1. **Create an audio uploads directory**:
   - Navigate to `care-mate/public/`
   - Create a new folder named `audio-uploads`
   - Set appropriate permissions:
     - Windows: Right-click > Properties > Security > Edit > Allow "Write" for Users
     - Mac/Linux: In terminal, run `chmod 755 audio-uploads` from the public directory

### 3. Test Audio Recording Permissions

Modern browsers require secure contexts (HTTPS) for audio recording. For local testing:

1. **Update your hosts file** (optional, for advanced users):
   - Windows: Edit `C:\Windows\System32\drivers\etc\hosts`
   - Mac/Linux: Edit `/etc/hosts`
   - Add: `127.0.0.1 care-mate.local`

2. **Or use Chrome with special flags** (easier):
   - Create a shortcut to Chrome
   - Right-click > Properties
   - In the Target field, add: `--unsafely-treat-insecure-origin-as-secure="http://localhost"` at the end
   - Use this shortcut when testing audio features

## PWA Features Implementation

### 1. Configure the Web App Manifest

1. **Create or update the manifest file**:
   - Navigate to `care-mate/public/`
   - Create a file named `manifest.json` if it doesn't exist
   - Copy this content into the file:

   ```json
   {
     "name": "Care Mate NDIS AI Assistant",
     "short_name": "Care Mate",
     "start_url": "/",
     "display": "standalone",
     "background_color": "#ffffff",
     "theme_color": "#4285f4",
     "icons": [
       {
         "src": "assets/icons/icon-192x192.png",
         "sizes": "192x192",
         "type": "image/png"
       },
       {
         "src": "assets/icons/icon-512x512.png",
         "sizes": "512x512",
         "type": "image/png"
       }
     ]
   }
   ```

2. **Create icons directory**:
   - Navigate to `care-mate/public/assets/`
   - Create a folder named `icons` if it doesn't exist
   - Place your app icons in this folder (named `icon-192x192.png` and `icon-512x512.png`)
   - If you don't have icons, sample ones are included in the PWA enhancement package

### 2. Link the Service Worker

1. **Update HTML files to register the service worker**:
   - Open `care-mate/public/index.html` with your text editor
   - Find the `<head>` section and add:

   ```html
   <link rel="manifest" href="manifest.json">
   ```

   - Find the end of the file (before `</body>`) and add:

   ```html
   <script>
     if ('serviceWorker' in navigator) {
       window.addEventListener('load', () => {
         navigator.serviceWorker.register('/enhanced-service-worker.js')
           .then(registration => {
             console.log('Service Worker registered with scope:', registration.scope);
           })
           .catch(error => {
             console.error('Service Worker registration failed:', error);
           });
       });
     }
   </script>
   ```

2. **Copy the service worker file**:
   - Ensure `enhanced-service-worker.js` is in the `care-mate/public/` directory
   - If it's not there, copy it from `pwa-enhancements/enhanced-service-worker.js`

### 3. Create Offline Page

1. **Create an offline fallback page**:
   - Navigate to `care-mate/public/`
   - Create a file named `offline.html` with this content:

   ```html
   <!DOCTYPE html>
   <html lang="en">
   <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Care Mate - Offline</title>
     <link rel="stylesheet" href="css/styles.css">
   </head>
   <body>
     <header>
       <h1>Care Mate</h1>
     </header>
     <main>
       <div class="offline-message">
         <h2>You are currently offline</h2>
         <p>Please check your internet connection and try again.</p>
         <p>Some features may still be available while you're offline.</p>
       </div>
     </main>
   </body>
   </html>
   ```

## Testing Your Implementation

### 1. Start Your Web Server

If using XAMPP:
1. Open XAMPP Control Panel
2. Ensure Apache is running (green light)
3. Open your browser and navigate to: `http://localhost/care-mate/`

If using web hosting:
1. Open your browser
2. Navigate to your website: `https://yourdomainname.com/care-mate/`

### 2. Test API Integration

1. **Open the application** in your browser
2. **Navigate to the Documents page**
3. **Check the console** for API connection messages:
   - Right-click on the page > Inspect > Console
   - Look for messages like "API Client initialized" or "Connected to NDIS API"
4. **Try searching for a document** to test the API functionality

### 3. Test Audio Recording

1. **Navigate to the Chat page**
2. **Look for the microphone icon** or audio recording button
3. **Click the button** and allow microphone permissions when prompted
4. **Record a short message** and submit it
5. **Verify** that the message appears in the chat

### 4. Test PWA Features

1. **Test offline functionality**:
   - Open the application in your browser
   - Navigate to a few pages to cache them
   - Disconnect from the internet (turn off Wi-Fi or use browser DevTools > Network > Offline)
   - Refresh the page and verify it still loads
   - Reconnect to the internet

2. **Test installation**:
   - Look for the installation prompt in your browser
   - If it doesn't appear automatically, look for the install icon in the address bar
   - Follow the prompts to install the app
   - Verify the app launches as a standalone application

## Troubleshooting

### Common Issues and Solutions

#### API Integration Issues

1. **"Failed to connect to API" error**:
   - Check your internet connection
   - Verify the API endpoint in `NDISApiClient.js`
   - Ensure your server allows outgoing connections

2. **"CORS error" in console**:
   - This is a security feature preventing cross-domain requests
   - For local testing, use the Chrome shortcut with flags mentioned earlier
   - For production, ensure your API server allows requests from your domain

#### Audio Recording Issues

1. **Microphone permission denied**:
   - Check browser permissions: Click the lock icon in the address bar > Site settings
   - Reset permissions and try again
   - Ensure you're using a secure context (HTTPS or localhost)

2. **"Audio recording not supported" message**:
   - Try a different browser (Chrome or Edge recommended)
   - Update your browser to the latest version

#### PWA Issues

1. **Service worker not registering**:
   - Verify the path to `enhanced-service-worker.js` is correct
   - Check the console for specific error messages
   - Ensure the service worker file is in the root of your public directory

2. **App not installable**:
   - PWA installation requires HTTPS (except on localhost)
   - Verify your manifest.json is correctly formatted
   - Ensure you have the required icons

### Checking for Errors

1. **Use the browser console**:
   - Right-click on the page > Inspect > Console
   - Look for red error messages
   - Note any specific error codes or messages

2. **Check server logs**:
   - If using XAMPP: Open XAMPP Control Panel > Apache > Logs
   - If using web hosting: Check your hosting control panel for error logs

## Getting Help

If you encounter issues that aren't covered in this guide:

1. **Consult the documentation**:
   - Review the detailed documentation files in the `documentation` folder
   - Each enhancement has its own comprehensive documentation

2. **Check file permissions**:
   - Ensure all directories have appropriate read/write permissions
   - Cache and upload directories need write permissions

3. **Verify file paths**:
   - Double-check that all file paths in HTML and JavaScript files are correct
   - Paths are case-sensitive on many servers

4. **Contact support**:
   - Reach out to the development team with:
     - A clear description of the issue
     - Screenshots of any error messages
     - The browser and operating system you're using

## Conclusion

Congratulations! You've successfully implemented the Care Mate NDIS AI application enhancements. The application now features robust API integration, audio recording capabilities, and progressive web app features that improve the user experience.

Remember to regularly check for updates and new features that may be released in the future.
