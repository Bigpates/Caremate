# Audio Recording Feature Documentation

## Overview

The Care Mate NDIS AI application now includes an audio recording feature that allows users to send voice messages to the AI assistant. This feature enhances accessibility and provides a more natural interaction method for users who prefer speaking over typing.

## Features

- **Voice Message Recording**: Record audio messages directly within the chat interface
- **Audio Visualization**: Visual feedback during recording shows audio levels
- **Playback**: Review recordings before sending
- **Transcription**: Automatic conversion of speech to text
- **Accessibility Integration**: Fully integrated with existing accessibility controls
- **Cross-Browser Support**: Works across modern browsers and devices
- **Fallback Mechanisms**: Graceful degradation when features aren't supported

## User Guide

### Enabling Voice Input

1. Open the accessibility panel by clicking the accessibility icon (♿) in the bottom right corner of the screen
2. Toggle the "Voice Input" option to enable audio recording functionality
3. The audio recording button will appear in the chat input area

### Recording a Message

1. Click the microphone button (🎤) in the chat input area to start recording
2. Speak your message clearly
3. The audio visualizer will show your voice levels as you speak
4. A timer will display the current recording duration

### Managing Your Recording

While recording, you have several options:
- **Pause/Resume**: Click the pause button to temporarily pause recording, and the play button to resume
- **Cancel**: Click the X button to discard the current recording
- **Stop**: Click the stop button (the same microphone button you used to start) to finish recording

### Reviewing and Sending

After stopping a recording:
1. A playback interface will appear showing the recording duration
2. Click the play button to review your recording
3. Click the send button (paper airplane icon) to send the message to the AI
4. Click the X button if you want to discard the recording and start over

### Receiving AI Responses

After sending an audio message:
1. Your audio message will appear in the chat as a voice message indicator
2. The AI will process your audio (transcribing it to text)
3. The AI will respond to your message as it would with a text message

## Accessibility Features

The audio recording functionality has been designed with accessibility in mind:

- **Screen Reader Support**: All buttons and status changes are announced to screen readers
- **Keyboard Navigation**: All controls can be operated using keyboard only
- **Visual Feedback**: Clear visual indicators show recording status
- **High Contrast Support**: Compatible with high contrast mode
- **Error Announcements**: Errors are clearly announced to screen readers

## Browser Compatibility

The audio recording feature is supported in the following browsers:

| Browser | Version | Support Level |
|---------|---------|--------------|
| Chrome  | 60+     | Full         |
| Firefox | 75+     | Full         |
| Safari  | 14.1+   | Full         |
| Edge    | 79+     | Full         |
| iOS Safari | 14.5+ | Full        |
| Chrome for Android | 90+ | Full  |
| Samsung Internet | 12.0+ | Full  |
| Opera   | 47+     | Full         |
| Internet Explorer | N/A | Not supported |

### Fallback Behavior

If your browser doesn't support certain features:

1. **MediaRecorder API not supported**: Audio recording will be disabled
2. **Web Speech API not supported**: Remote transcription will be used instead of local

## Privacy Considerations

- Audio is processed locally when possible to maintain privacy
- When remote transcription is used, audio data is sent securely
- No audio is stored permanently unless explicitly saved by the user
- Audio data is only used for the purpose of transcription and AI response

## Troubleshooting

### Common Issues

**Microphone access denied**
- Check your browser permissions and allow microphone access for the Care Mate website
- Look for the camera/microphone icon in your browser's address bar to manage permissions

**Audio recording button not appearing**
- Ensure voice input is enabled in the accessibility panel
- Check if your browser supports the required APIs (see compatibility table)

**Poor transcription quality**
- Speak clearly and at a moderate pace
- Reduce background noise when recording
- Position yourself closer to your microphone

**Recording not working on mobile**
- Ensure your mobile browser supports the MediaRecorder API
- Check that you've granted microphone permissions
- Try using the latest version of Chrome or Safari on mobile

### Error Messages

| Error Message | Possible Cause | Solution |
|---------------|----------------|----------|
| "Could not access microphone" | Microphone permission denied | Allow microphone access in browser settings |
| "Recording failed" | Browser compatibility issue | Try a different browser |
| "Transcription failed" | Network issue or unsupported speech | Try again or use text input instead |
| "Audio file too large" | Recording exceeds maximum size | Record a shorter message |

## Developer Guide

### Architecture

The audio recording feature consists of several components:

1. **AudioRecorder**: Core class for recording audio
2. **AudioRecorderUI**: UI integration for the recorder
3. **AudioTranscriptionService**: Service for transcribing audio to text
4. **AudioFeatureTestSuite**: Test suite for validating functionality

### Integration Points

The audio recording functionality integrates with the existing chat interface:

- Added to the chat input container
- Connected to the accessibility controls
- Sends messages through the same channel as text input

### File Structure

```
/src/audio/
  ├── AudioRecorder.js         # Core recording functionality
  ├── AudioTranscriptionService.js  # Transcription service
  └── AudioFeatureTestSuite.js # Test suite

/public/
  ├── css/
  │   └── audio-recorder.css   # Styles for audio recorder
  └── js/
      └── audio-recorder.js    # UI integration script
```

### Key Classes and Methods

#### AudioRecorder

```javascript
// Create an instance
const recorder = new AudioRecorder({
  maxDuration: 60,
  mimeType: 'audio/webm',
  enableVisualFeedback: true
});

// Start recording
await recorder.start(visualizerElement);

// Stop recording
const recording = await recorder.stop();

// Other methods
recorder.pause();
recorder.resume();
recorder.cancel();
```

#### AudioTranscriptionService

```javascript
// Create an instance
const transcriptionService = new AudioTranscriptionService({
  apiEndpoint: '/api/transcribe',
  fallbackToLocal: true,
  language: 'en-US'
});

// Transcribe audio
const result = await transcriptionService.transcribe(audioBlob);

// Send to AI
const aiResponse = await transcriptionService.sendToAI(result.text);
```

### Event Handling

The audio recorder emits several events that can be handled:

```javascript
// Recording events
recorder.onStart = () => { /* Handle recording start */ };
recorder.onStop = (recording) => { /* Handle recording stop */ };
recorder.onPause = () => { /* Handle recording pause */ };
recorder.onResume = () => { /* Handle recording resume */ };
recorder.onError = (error) => { /* Handle recording error */ };

// Transcription events
transcriptionService.onTranscriptionStart = () => { /* Handle transcription start */ };
transcriptionService.onTranscriptionComplete = (result) => { /* Handle transcription complete */ };
transcriptionService.onTranscriptionError = (error) => { /* Handle transcription error */ };
```

### Accessibility Implementation

The audio recorder follows these accessibility best practices:

- All interactive elements have appropriate ARIA attributes
- Status changes are announced via aria-live regions
- All controls are keyboard accessible
- Visual indicators have sufficient color contrast
- Error messages are clearly announced

## Future Enhancements

Planned improvements for future versions:

1. **Enhanced Noise Reduction**: Improved algorithms for cleaner audio in noisy environments
2. **Multiple Language Support**: Expanded language options for transcription
3. **Voice Commands**: Ability to control the application using voice commands
4. **Audio Message Library**: Save and organize frequently used voice messages
5. **Waveform Visualization**: More detailed audio visualization with waveform display
