/**
 * Care Mate - State Management Documentation
 * 
 * This document provides an overview of the state management system implemented
 * in the Care Mate NDIS AI application, including architecture, usage patterns,
 * and best practices.
 */

# State Management System Documentation

## Overview

The Care Mate NDIS AI application uses a custom state management solution inspired by Redux and Context API patterns. This system provides a predictable state container with actions, reducers, and subscription capabilities, allowing for centralized state management across the application.

## Architecture

The state management system consists of the following components:

1. **Store**: Central state container that holds the application state
2. **Reducers**: Pure functions that specify how state changes in response to actions
3. **Actions**: Plain objects that describe state changes
4. **Subscribers**: Callback functions that execute when state changes

## Core Components

### Store

The store is the central repository for application state. It provides methods for:

- Getting the current state (`getState`)
- Dispatching actions to update state (`dispatch`)
- Subscribing to state changes (`subscribe`)
- Registering reducers for specific state slices (`registerReducer`)
- Persisting and loading state from localStorage

```javascript
// Example store usage
import store from './state/index.js';

// Get current state
const currentState = store.getState();

// Subscribe to state changes
const unsubscribe = store.subscribe((newState) => {
  console.log('State updated:', newState);
});

// Dispatch an action
store.dispatch({
  type: 'accessibility/TOGGLE_HIGH_CONTRAST'
});

// Unsubscribe when no longer needed
unsubscribe();
```

### Reducers

Reducers are pure functions that take the current state and an action, and return a new state. Each reducer manages a specific slice of the application state.

```javascript
// Example reducer
function accessibilityReducer(state = initialState, action) {
  switch (action.type) {
    case TOGGLE_HIGH_CONTRAST:
      return {
        ...state,
        highContrast: !state.highContrast
      };
    // Other cases...
    default:
      return state;
  }
}
```

### Actions

Actions are plain JavaScript objects that describe state changes. They must have a `type` property and may include additional data in a `payload` property.

```javascript
// Example action creators
export const toggleHighContrast = () => ({
  type: TOGGLE_HIGH_CONTRAST
});

export const setActiveView = (view) => ({
  type: SET_ACTIVE_VIEW,
  payload: view
});
```

## State Structure

The application state is organized into the following main sections:

### Preferences

Contains user preferences and settings, including accessibility options:

```javascript
preferences: {
  accessibility: {
    highContrast: false,
    largeText: false,
    screenReader: false,
    simplifiedLanguage: false,
    voiceInput: false,
    reducedMotion: false
  },
  notifications: {
    enabled: true,
    planUpdates: true,
    appointmentReminders: true,
    budgetAlerts: true
  },
  display: {
    theme: 'light',
    compactView: false,
    dashboardLayout: 'default'
  }
}
```

### Authentication

Manages user authentication state:

```javascript
auth: {
  isAuthenticated: false,
  user: null,
  token: null,
  loading: false,
  error: null
}
```

### NDIS Plan Data

Stores NDIS plan information:

```javascript
plan: {
  current: null,
  previous: null,
  loading: false,
  error: null,
  comparison: null
}
```

### UI State

Manages application UI state:

```javascript
ui: {
  activeView: 'dashboard',
  sidebarOpen: true,
  modals: {
    active: null,
    data: null
  },
  notifications: [],
  errors: [],
  loading: {
    global: false,
    components: {}
  }
}
```

## Integration with Components

Components can interact with the state management system in two ways:

1. **Direct Integration**: Components can import the store and directly dispatch actions and subscribe to state changes.

```javascript
import store from '../state/index.js';
import { toggleHighContrast } from '../state/reducers/accessibilityReducer.js';

// Dispatch an action
store.dispatch(toggleHighContrast());

// Subscribe to state changes
const unsubscribe = store.subscribe(() => {
  const state = store.getState();
  // Update component based on new state
});
```

2. **Component-Specific Integration**: Components can be designed to work with the state management system through specific interfaces.

```javascript
class AccessibilityControls {
  constructor() {
    // Initialize component
    
    // Subscribe to state changes
    store.subscribe(this.updateControlsFromState);
  }
  
  updateControlsFromState() {
    const accessibilityState = store.getState().accessibility;
    // Update component based on state
  }
}
```

## State Persistence

The state management system includes built-in persistence using localStorage:

```javascript
// Persist state to localStorage
store.persistState('careMateState');

// Load state from localStorage
store.loadState('careMateState');
```

This ensures that user preferences and settings are preserved between sessions.

## Best Practices

1. **Use Action Creators**: Always use action creators instead of dispatching action objects directly.

```javascript
// Good
store.dispatch(toggleHighContrast());

// Avoid
store.dispatch({ type: 'accessibility/TOGGLE_HIGH_CONTRAST' });
```

2. **Keep Reducers Pure**: Reducers should be pure functions without side effects.

3. **Normalize Complex State**: For complex data structures, normalize the state to avoid duplication.

4. **Use Selectors**: Create selector functions to extract specific data from the state.

```javascript
// Example selector
function getAccessibilitySettings(state) {
  return state.preferences.accessibility;
}

const accessibilitySettings = getAccessibilitySettings(store.getState());
```

5. **Unsubscribe When Done**: Always unsubscribe from the store when components are unmounted.

```javascript
const unsubscribe = store.subscribe(listener);
// Later when no longer needed:
unsubscribe();
```

## Debugging

The state management system includes built-in logging for actions and state changes in development mode:

```javascript
// Action logging
console.log('%cAction:', 'color: #9E9E9E; font-weight: bold;', action);

// New state logging
console.log('%cNew State:', 'color: #4CAF50; font-weight: bold;', this.state);
```

This helps with debugging and understanding state changes during development.

## Extending the System

To add new state slices:

1. Create a new reducer file in `src/state/reducers/`
2. Define action types, initial state, and reducer function
3. Register the reducer with the store in `src/state/index.js`

```javascript
import newReducer from './reducers/newReducer.js';
store.registerReducer('newSlice', newReducer);
```

## Conclusion

This state management system provides a robust foundation for managing application state in the Care Mate NDIS AI application. It centralizes state management, ensures predictable state changes, and integrates seamlessly with components throughout the application.
