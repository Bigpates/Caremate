/**
 * Care Mate - Smart Content Prefetcher
 * 
 * This module enhances the PWA experience by intelligently prefetching content
 * based on user behavior patterns, network conditions, and device capabilities.
 */

class SmartContentPrefetcher {
  constructor(options = {}) {
    // Default configuration
    this.config = {
      enabled: true,
      maxConcurrentPrefetches: 3,
      minBatteryLevel: 0.2, // Minimum battery level to prefetch (20%)
      networkConditions: {
        wifi: {
          enabled: true,
          maxItems: 10
        },
        cellular: {
          enabled: false,
          maxItems: 3
        }
      },
      prefetchTriggers: {
        pageLoad: true,
        idle: true,
        navigation: true
      },
      ...options
    };

    // State
    this.prefetchQueue = [];
    this.activePrefetches = 0;
    this.networkType = 'unknown';
    this.batteryLevel = 1.0;
    this.userIsIdle = false;
    this.idleTime = 0;
    this.idleThreshold = 60000; // 60 seconds
    this.pageViewHistory = [];
    this.initialized = false;

    // Bind methods
    this.init = this.init.bind(this);
    this.setupEventListeners = this.setupEventListeners.bind(this);
    this.checkNetworkConditions = this.checkNetworkConditions.bind(this);
    this.checkBatteryStatus = this.checkBatteryStatus.bind(this);
    this.trackUserActivity = this.trackUserActivity.bind(this);
    this.trackPageView = this.trackPageView.bind(this);
    this.queuePrefetch = this.queuePrefetch.bind(this);
    this.processPrefetchQueue = this.processPrefetchQueue.bind(this);
    this.prefetchContent = this.prefetchContent.bind(this);
    this.predictNextPages = this.predictNextPages.bind(this);
  }

  /**
   * Initialize the smart content prefetcher
   * @returns {Promise<boolean>} Whether initialization was successful
   */
  async init() {
    if (this.initialized) {
      return true;
    }

    try {
      // Check if prefetching is supported
      if (!('fetch' in window) || !('caches' in window)) {
        console.warn('[SmartPrefetcher] Prefetching not supported in this browser');
        return false;
      }

      // Load history from storage
      this.loadPageViewHistory();

      // Set up event listeners
      this.setupEventListeners();

      // Check network conditions
      await this.checkNetworkConditions();

      // Check battery status if available
      await this.checkBatteryStatus();

      // Start idle detection
      this.startIdleDetection();

      // Track current page view
      this.trackPageView(window.location.href);

      // Set up periodic queue processing
      setInterval(() => {
        this.processPrefetchQueue();
      }, 5000);

      this.initialized = true;
      console.log('[SmartPrefetcher] Initialized successfully');
      
      // Initial prefetch of likely next pages
      this.prefetchLikelyNextPages();

      return true;
    } catch (error) {
      console.error('[SmartPrefetcher] Initialization failed:', error);
      return false;
    }
  }

  /**
   * Set up event listeners
   */
  setupEventListeners() {
    // Network change events
    if ('connection' in navigator) {
      // @ts-ignore - Navigator connection is not in all type definitions
      navigator.connection.addEventListener('change', () => {
        this.checkNetworkConditions();
      });
    }

    // Battery status events
    if ('getBattery' in navigator) {
      navigator.getBattery().then(battery => {
        battery.addEventListener('levelchange', () => {
          this.batteryLevel = battery.level;
        });
      });
    }

    // Page visibility events
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        // User returned to the app, check for prefetch opportunities
        this.prefetchLikelyNextPages();
      }
    });

    // Click events for navigation prediction
    document.addEventListener('click', event => {
      // Check if the click is on a link
      let target = event.target;
      while (target && target !== document.body) {
        if (target.tagName === 'A' && target.href) {
          // Found a link, check if it's an internal link
          const url = new URL(target.href, window.location.origin);
          if (url.origin === window.location.origin) {
            // It's an internal link, prefetch linked resources
            this.prefetchLinkedResources(url.href);
          }
          break;
        }
        target = target.parentElement;
      }
    });

    // History change events
    window.addEventListener('popstate', () => {
      this.trackPageView(window.location.href);
    });
  }

  /**
   * Check network conditions
   */
  async checkNetworkConditions() {
    if ('connection' in navigator) {
      // @ts-ignore - Navigator connection is not in all type definitions
      const connection = navigator.connection;
      this.networkType = connection.type || (connection.effectiveType || 'unknown');
      
      console.log(`[SmartPrefetcher] Network type: ${this.networkType}`);
      
      // Adjust prefetching based on network type
      if (this.networkType === 'wifi' || this.networkType === '4g') {
        this.config.enabled = this.config.networkConditions.wifi.enabled;
        this.config.maxConcurrentPrefetches = this.config.networkConditions.wifi.maxItems;
      } else {
        this.config.enabled = this.config.networkConditions.cellular.enabled;
        this.config.maxConcurrentPrefetches = this.config.networkConditions.cellular.maxItems;
      }
    }
  }

  /**
   * Check battery status
   */
  async checkBatteryStatus() {
    if ('getBattery' in navigator) {
      try {
        const battery = await navigator.getBattery();
        this.batteryLevel = battery.level;
        
        console.log(`[SmartPrefetcher] Battery level: ${Math.round(this.batteryLevel * 100)}%`);
        
        // Disable prefetching if battery is too low
        if (this.batteryLevel < this.config.minBatteryLevel) {
          console.log('[SmartPrefetcher] Battery level too low, disabling prefetching');
          this.config.enabled = false;
        }
      } catch (error) {
        console.warn('[SmartPrefetcher] Could not access battery status:', error);
      }
    }
  }

  /**
   * Start idle detection
   */
  startIdleDetection() {
    // Reset idle timer on user activity
    const resetIdleTimer = () => {
      this.idleTime = 0;
      
      if (this.userIsIdle) {
        this.userIsIdle = false;
        console.log('[SmartPrefetcher] User is active');
      }
    };
    
    // User activity events
    const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    activityEvents.forEach(event => {
      document.addEventListener(event, resetIdleTimer, true);
    });
    
    // Check idle status every second
    setInterval(() => {
      this.idleTime += 1000;
      
      if (!this.userIsIdle && this.idleTime >= this.idleThreshold) {
        this.userIsIdle = true;
        console.log('[SmartPrefetcher] User is idle, checking for prefetch opportunities');
        
        // User is idle, good time to prefetch
        if (this.config.prefetchTriggers.idle) {
          this.prefetchLikelyNextPages();
        }
      }
    }, 1000);
  }

  /**
   * Track user activity
   * @param {string} activityType - Type of activity
   * @param {Object} data - Activity data
   */
  trackUserActivity(activityType, data = {}) {
    // Reset idle timer
    this.idleTime = 0;
    
    // Record activity for prediction
    const activity = {
      type: activityType,
      timestamp: Date.now(),
      data
    };
    
    // Store activity for pattern recognition
    // This would be more sophisticated in a real implementation
    console.log(`[SmartPrefetcher] User activity: ${activityType}`);
  }

  /**
   * Track page view
   * @param {string} url - URL of the page
   */
  trackPageView(url) {
    // Create page view record
    const pageView = {
      url,
      timestamp: Date.now()
    };
    
    // Add to history
    this.pageViewHistory.push(pageView);
    
    // Keep history at a reasonable size
    if (this.pageViewHistory.length > 100) {
      this.pageViewHistory.shift();
    }
    
    // Save history to storage
    this.savePageViewHistory();
    
    console.log(`[SmartPrefetcher] Page view tracked: ${url}`);
    
    // Prefetch likely next pages if enabled
    if (this.config.prefetchTriggers.pageLoad) {
      this.prefetchLikelyNextPages();
    }
  }

  /**
   * Save page view history to localStorage
   */
  savePageViewHistory() {
    try {
      localStorage.setItem('care-mate-page-view-history', JSON.stringify(this.pageViewHistory));
    } catch (error) {
      console.warn('[SmartPrefetcher] Could not save page view history:', error);
    }
  }

  /**
   * Load page view history from localStorage
   */
  loadPageViewHistory() {
    try {
      const history = localStorage.getItem('care-mate-page-view-history');
      if (history) {
        this.pageViewHistory = JSON.parse(history);
        console.log(`[SmartPrefetcher] Loaded ${this.pageViewHistory.length} page views from history`);
      }
    } catch (error) {
      console.warn('[SmartPrefetcher] Could not load page view history:', error);
    }
  }

  /**
   * Queue a URL for prefetching
   * @param {string} url - URL to prefetch
   * @param {number} priority - Priority (1-10, higher is more important)
   */
  queuePrefetch(url, priority = 5) {
    // Skip if already in queue
    if (this.prefetchQueue.some(item => item.url === url)) {
      return;
    }
    
    // Skip if not enabled
    if (!this.config.enabled) {
      return;
    }
    
    // Add to queue
    this.prefetchQueue.push({
      url,
      priority,
      timestamp: Date.now()
    });
    
    // Sort queue by priority (highest first)
    this.prefetchQueue.sort((a, b) => b.priority - a.priority);
    
    console.log(`[SmartPrefetcher] Queued for prefetch: ${url} (priority: ${priority})`);
  }

  /**
   * Process the prefetch queue
   */
  processPrefetchQueue() {
    // Skip if not enabled
    if (!this.config.enabled) {
      return;
    }
    
    // Skip if too many active prefetches
    if (this.activePrefetches >= this.config.maxConcurrentPrefetches) {
      return;
    }
    
    // Skip if battery is too low
    if (this.batteryLevel < this.config.minBatteryLevel) {
      return;
    }
    
    // Process queue items
    while (this.prefetchQueue.length > 0 && this.activePrefetches < this.config.maxConcurrentPrefetches) {
      const item = this.prefetchQueue.shift();
      this.prefetchContent(item.url);
    }
  }

  /**
   * Prefetch content
   * @param {string} url - URL to prefetch
   */
  async prefetchContent(url) {
    // Skip if not enabled
    if (!this.config.enabled) {
      return;
    }
    
    try {
      this.activePrefetches++;
      
      console.log(`[SmartPrefetcher] Prefetching: ${url}`);
      
      // Check if already in cache
      const cache = await caches.open('care-mate-prefetch');
      const cachedResponse = await cache.match(url);
      
      if (cachedResponse) {
        console.log(`[SmartPrefetcher] Already cached: ${url}`);
        this.activePrefetches--;
        return;
      }
      
      // Fetch the resource
      const response = await fetch(url, { credentials: 'same-origin' });
      
      if (!response.ok) {
        throw new Error(`Failed to prefetch: ${response.status} ${response.statusText}`);
      }
      
      // Cache the response
      await cache.put(url, response.clone());
      
      console.log(`[SmartPrefetcher] Successfully prefetched: ${url}`);
    } catch (error) {
      console.error(`[SmartPrefetcher] Prefetch failed for ${url}:`, error);
    } finally {
      this.activePrefetches--;
    }
  }

  /**
   * Prefetch likely next pages based on user history
   */
  prefetchLikelyNextPages() {
    // Skip if not enabled
    if (!this.config.enabled) {
      return;
    }
    
    // Get predictions
    const predictions = this.predictNextPages();
    
    // Queue top predictions for prefetching
    predictions.forEach(prediction => {
      this.queuePrefetch(prediction.url, Math.round(prediction.probability * 10));
    });
  }

  /**
   * Prefetch resources linked from a page
   * @param {string} url - URL of the page
   */
  async prefetchLinkedResources(url) {
    // Skip if not enabled
    if (!this.config.enabled) {
      return;
    }
    
    try {
      console.log(`[SmartPrefetcher] Prefetching linked resources for: ${url}`);
      
      // Queue the page itself
      this.queuePrefetch(url, 10);
      
      // In a real implementation, we would fetch the page and parse it for resources
      // For now, we'll just simulate this with common resource patterns
      
      // Queue common resources
      const urlObj = new URL(url);
      const path = urlObj.pathname;
      
      // Queue CSS
      this.queuePrefetch(`${urlObj.origin}/css/styles.css`, 9);
      
      // Queue JS
      this.queuePrefetch(`${urlObj.origin}/js/main.js`, 8);
      
      // Queue page-specific resources based on path patterns
      if (path.includes('chat')) {
        this.queuePrefetch(`${urlObj.origin}/js/chat.js`, 7);
        this.queuePrefetch(`${urlObj.origin}/css/chat.css`, 7);
      } else if (path.includes('documents')) {
        this.queuePrefetch(`${urlObj.origin}/js/documents.js`, 7);
        this.queuePrefetch(`${urlObj.origin}/css/documents.css`, 7);
      }
    } catch (error) {
      console.error(`[SmartPrefetcher] Failed to prefetch linked resources for ${url}:`, error);
    }
  }

  /**
   * Predict next pages based on user history
   * @returns {Array<Object>} Array of predictions with URLs and probabilities
   */
  predictNextPages() {
    // Skip if no history
    if (this.pageViewHistory.length < 2) {
      return [];
    }
    
    // Get current page
    const currentUrl = window.location.href;
    
    // Find transitions from current page in history
    const transitions = new Map();
    let totalTransitions = 0;
    
    for (let i = 0; i < this.pageViewHistory.length - 1; i++) {
      if (this.pageViewHistory[i].url === currentUrl) {
        const nextUrl = this.pageViewHistory[i + 1].url;
        
        // Skip self-transitions
        if (nextUrl === currentUrl) {
          continue;
        }
        
        // Count transition
        const count = transitions.get(nextUrl) || 0;
        transitions.set(nextUrl, count + 1);
        totalTransitions++;
      }
    }
    
    // Convert to probabilities
    const predictions = Array.from(transitions.entries()).map(([url, count]) => ({
      url,
      probability: count / totalTransitions
    }));
    
    // Sort by probability (highest first)
    predictions.sort((a, b) => b.probability - a.probability);
    
    // Take top 5
    return predictions.slice(0, 5);
  }

  /**
   * Get prefetch queue status
   * @returns {Object} Queue status
   */
  getQueueStatus() {
    return {
      enabled: this.config.enabled,
      queueLength: this.prefetchQueue.length,
      activePrefetches: this.activePrefetches,
      networkType: this.networkType,
      batteryLevel: Math.round(this.batteryLevel * 100)
    };
  }

  /**
   * Update configuration
   * @param {Object} config - New configuration
   */
  updateConfig(config) {
    this.config = {
      ...this.config,
      ...config
    };
    
    console.log('[SmartPrefetcher] Configuration updated');
  }
}

export default SmartContentPrefetcher;
