/**
 * Care Mate - PWA Integration Module
 * 
 * This module integrates all PWA-related components and provides a unified
 * interface for managing progressive web app features throughout the application.
 */

import BackgroundSyncManager from './BackgroundSyncManager.js';
import PushNotificationManager from './PushNotificationManager.js';
import AppInstallationManager from './AppInstallationManager.js';

/**
 * PWA Integration class
 * Provides a unified interface for managing PWA features
 */
class PWAIntegration {
  constructor(config = {}) {
    // Store config
    this.config = {
      enableBackgroundSync: true,
      enablePushNotifications: true,
      enableAppInstallation: true,
      ...config
    };
    
    // Initialize components
    this.backgroundSync = this.config.enableBackgroundSync ? new BackgroundSyncManager() : null;
    this.pushNotifications = this.config.enablePushNotifications ? new PushNotificationManager() : null;
    this.appInstallation = this.config.enableAppInstallation ? new AppInstallationManager() : null;
    
    // Bind methods
    this.init = this.init.bind(this);
    this.isOnline = this.isOnline.bind(this);
    this.registerNetworkHandlers = this.registerNetworkHandlers.bind(this);
    this.queueApiRequest = this.queueApiRequest.bind(this);
    
    // Initialize
    this.init();
  }
  
  /**
   * Initialize the PWA integration
   */
  init() {
    // Register network status handlers
    this.registerNetworkHandlers();
    
    console.log('[PWA] Integration initialized successfully');
  }
  
  /**
   * Register handlers for network status changes
   */
  registerNetworkHandlers() {
    // Set up online/offline event listeners
    window.addEventListener('online', () => {
      console.log('[PWA] Device is online');
      this.updateOnlineStatus(true);
    });
    
    window.addEventListener('offline', () => {
      console.log('[PWA] Device is offline');
      this.updateOnlineStatus(false);
    });
    
    // Initial status update
    this.updateOnlineStatus(this.isOnline());
  }
  
  /**
   * Update UI based on online status
   * @param {boolean} isOnline - Whether the device is online
   */
  updateOnlineStatus(isOnline) {
    // Update body class
    document.body.classList.toggle('offline', !isOnline);
    document.body.classList.toggle('online', isOnline);
    
    // Find or create status indicator
    let statusIndicator = document.getElementById('network-status');
    
    if (!statusIndicator) {
      statusIndicator = document.createElement('div');
      statusIndicator.id = 'network-status';
      statusIndicator.className = 'network-status';
      statusIndicator.setAttribute('aria-live', 'polite');
      
      // Add to appropriate container
      const container = document.querySelector('.app-header') || 
                        document.querySelector('header') || 
                        document.body;
      
      container.appendChild(statusIndicator);
    }
    
    // Update status indicator
    statusIndicator.textContent = isOnline ? 'Online' : 'Offline';
    statusIndicator.className = `network-status ${isOnline ? 'online' : 'offline'}`;
    statusIndicator.setAttribute('aria-label', `Network status: ${isOnline ? 'Online' : 'Offline'}`);
    
    // Announce status change to screen readers
    const announcement = document.createElement('div');
    announcement.className = 'sr-only';
    announcement.setAttribute('aria-live', 'assertive');
    announcement.textContent = `You are now ${isOnline ? 'online' : 'offline'}`;
    document.body.appendChild(announcement);
    
    // Remove announcement after it's been read
    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 3000);
  }
  
  /**
   * Check if the device is online
   * @returns {boolean} Whether the device is online
   */
  isOnline() {
    return navigator.onLine;
  }
  
  /**
   * Queue an API request for background sync when offline
   * @param {Request} request - The request to queue
   * @returns {Promise<string|null>} ID of the queued request or null if not queued
   */
  async queueApiRequest(request) {
    if (!this.backgroundSync) {
      console.warn('[PWA] Background sync is not enabled');
      return null;
    }
    
    try {
      return await this.backgroundSync.queueRequest(request);
    } catch (error) {
      console.error('[PWA] Failed to queue API request:', error);
      return null;
    }
  }
  
  /**
   * Subscribe to push notifications
   * @returns {Promise<boolean>} Whether subscription was successful
   */
  async subscribeToPushNotifications() {
    if (!this.pushNotifications) {
      console.warn('[PWA] Push notifications are not enabled');
      return false;
    }
    
    return await this.pushNotifications.subscribe();
  }
  
  /**
   * Show app installation prompt
   * @returns {Promise<boolean>} Whether the app was installed
   */
  async showInstallPrompt() {
    if (!this.appInstallation) {
      console.warn('[PWA] App installation is not enabled');
      return false;
    }
    
    return await this.appInstallation.showInstallPrompt();
  }
  
  /**
   * Check if the app is installable
   * @returns {boolean} Whether the app can be installed
   */
  canBeInstalled() {
    return this.appInstallation ? this.appInstallation.canBeInstalled() : false;
  }
  
  /**
   * Check if push notifications are supported
   * @returns {boolean} Whether push notifications are supported
   */
  arePushNotificationsSupported() {
    return this.pushNotifications ? this.pushNotifications.isSupported() : false;
  }
  
  /**
   * Check if background sync is supported
   * @returns {boolean} Whether background sync is supported
   */
  isBackgroundSyncSupported() {
    return this.backgroundSync ? this.backgroundSync.isSupported() : false;
  }
}

// Create and export a singleton instance
const pwaIntegration = new PWAIntegration();

export default pwaIntegration;

// Also export individual components for direct use if needed
export {
  BackgroundSyncManager,
  PushNotificationManager,
  AppInstallationManager
};
