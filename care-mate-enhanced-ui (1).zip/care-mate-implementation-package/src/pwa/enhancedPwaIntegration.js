/**
 * Care Mate - Enhanced PWA Integration Module
 * 
 * This module integrates all enhanced PWA components and provides a unified
 * interface for managing progressive web app features throughout the application.
 */

import pwaIntegration from './index.js';
import EnhancedOfflineContent from './EnhancedOfflineContent.js';
import SmartContentPrefetcher from './SmartContentPrefetcher.js';
import EnhancedPushNotificationManager from './EnhancedPushNotificationManager.js';

/**
 * Enhanced PWA Integration class
 * Provides a unified interface for managing enhanced PWA features
 */
class EnhancedPWAIntegration {
  constructor(config = {}) {
    // Store config
    this.config = {
      enableEnhancedOffline: true,
      enableSmartPrefetching: true,
      enableEnhancedPushNotifications: true,
      ...config
    };
    
    // Initialize components
    this.offlineContent = this.config.enableEnhancedOffline ? new EnhancedOfflineContent() : null;
    this.contentPrefetcher = this.config.enableSmartPrefetching ? new SmartContentPrefetcher() : null;
    this.pushNotifications = this.config.enableEnhancedPushNotifications ? new EnhancedPushNotificationManager() : null;
    
    // Original PWA integration
    this.originalPWA = pwaIntegration;
    
    // Bind methods
    this.init = this.init.bind(this);
    this.setupEventListeners = this.setupEventListeners.bind(this);
    this.setupAccessibilityFeatures = this.setupAccessibilityFeatures.bind(this);
    this.createSettingsUI = this.createSettingsUI.bind(this);
    this.handleNetworkChange = this.handleNetworkChange.bind(this);
  }
  
  /**
   * Initialize the enhanced PWA integration
   * @returns {Promise<boolean>} Whether initialization was successful
   */
  async init() {
    try {
      console.log('[EnhancedPWA] Initializing enhanced PWA features...');
      
      // Initialize components
      const initPromises = [];
      
      if (this.offlineContent) {
        initPromises.push(this.offlineContent.init());
      }
      
      if (this.contentPrefetcher) {
        initPromises.push(this.contentPrefetcher.init());
      }
      
      if (this.pushNotifications) {
        initPromises.push(this.pushNotifications.init());
      }
      
      // Wait for all components to initialize
      await Promise.all(initPromises);
      
      // Set up event listeners
      this.setupEventListeners();
      
      // Set up accessibility features
      this.setupAccessibilityFeatures();
      
      // Create settings UI
      this.createSettingsUI();
      
      console.log('[EnhancedPWA] Enhanced PWA features initialized successfully');
      return true;
    } catch (error) {
      console.error('[EnhancedPWA] Initialization failed:', error);
      return false;
    }
  }
  
  /**
   * Set up event listeners
   */
  setupEventListeners() {
    // Network status changes
    window.addEventListener('online', () => this.handleNetworkChange(true));
    window.addEventListener('offline', () => this.handleNetworkChange(false));
    
    // Page visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        console.log('[EnhancedPWA] Page became visible, refreshing content');
        this.refreshContent();
      }
    });
    
    // Listen for messages from service worker
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.addEventListener('message', event => {
        if (event.data && event.data.type) {
          this.handleServiceWorkerMessage(event.data);
        }
      });
    }
  }
  
  /**
   * Handle network status change
   * @param {boolean} isOnline - Whether the device is online
   */
  handleNetworkChange(isOnline) {
    console.log(`[EnhancedPWA] Network status changed: ${isOnline ? 'online' : 'offline'}`);
    
    // Update UI to reflect network status
    document.body.classList.toggle('offline', !isOnline);
    document.body.classList.toggle('online', isOnline);
    
    // Find or create status indicator
    let statusIndicator = document.getElementById('network-status');
    
    if (!statusIndicator) {
      statusIndicator = document.createElement('div');
      statusIndicator.id = 'network-status';
      statusIndicator.className = 'network-status';
      statusIndicator.setAttribute('aria-live', 'polite');
      
      // Add to appropriate container
      const container = document.querySelector('.app-header') || 
                        document.querySelector('header') || 
                        document.body;
      
      container.appendChild(statusIndicator);
    }
    
    // Update status indicator
    statusIndicator.textContent = isOnline ? 'Online' : 'Offline';
    statusIndicator.className = `network-status ${isOnline ? 'online' : 'offline'}`;
    statusIndicator.setAttribute('aria-label', `Network status: ${isOnline ? 'Online' : 'Offline'}`);
    
    // Announce status change to screen readers
    this.announceToScreenReader(`You are now ${isOnline ? 'online' : 'offline'}`);
    
    // If coming back online, refresh content
    if (isOnline) {
      this.refreshContent();
    }
  }
  
  /**
   * Handle messages from service worker
   * @param {Object} message - Message data
   */
  handleServiceWorkerMessage(message) {
    console.log('[EnhancedPWA] Received message from service worker:', message);
    
    switch (message.type) {
      case 'CACHE_UPDATED':
        // Cache was updated, refresh content if needed
        if (this.offlineContent) {
          this.offlineContent.updateCacheStats();
        }
        break;
        
      case 'SYNC_COMPLETED':
        // Background sync completed
        this.announceToScreenReader(`Background sync completed. ${message.successCount} of ${message.totalCount} items synchronized.`);
        break;
        
      case 'NEW_CONTENT_AVAILABLE':
        // New content is available
        this.promptForContentRefresh();
        break;
    }
  }
  
  /**
   * Refresh content
   */
  refreshContent() {
    // Refresh dynamic content
    if (this.offlineContent) {
      this.offlineContent.updateCacheStats();
    }
    
    // Check for new content to prefetch
    if (this.contentPrefetcher) {
      this.contentPrefetcher.prefetchLikelyNextPages();
    }
  }
  
  /**
   * Prompt user to refresh content
   */
  promptForContentRefresh() {
    // Create or update refresh prompt
    let refreshPrompt = document.getElementById('refresh-prompt');
    
    if (!refreshPrompt) {
      refreshPrompt = document.createElement('div');
      refreshPrompt.id = 'refresh-prompt';
      refreshPrompt.className = 'refresh-prompt';
      refreshPrompt.setAttribute('role', 'alert');
      
      const message = document.createElement('span');
      message.textContent = 'New content is available.';
      
      const refreshButton = document.createElement('button');
      refreshButton.textContent = 'Refresh';
      refreshButton.className = 'btn btn-primary';
      refreshButton.addEventListener('click', () => {
        window.location.reload();
      });
      
      const dismissButton = document.createElement('button');
      dismissButton.textContent = 'Dismiss';
      dismissButton.className = 'btn btn-secondary';
      dismissButton.addEventListener('click', () => {
        refreshPrompt.style.display = 'none';
      });
      
      refreshPrompt.appendChild(message);
      refreshPrompt.appendChild(refreshButton);
      refreshPrompt.appendChild(dismissButton);
      
      document.body.appendChild(refreshPrompt);
    } else {
      refreshPrompt.style.display = 'flex';
    }
  }
  
  /**
   * Set up accessibility features
   */
  setupAccessibilityFeatures() {
    // Create screen reader announcement area if it doesn't exist
    let srAnnouncements = document.getElementById('sr-announcements');
    
    if (!srAnnouncements) {
      srAnnouncements = document.createElement('div');
      srAnnouncements.id = 'sr-announcements';
      srAnnouncements.className = 'sr-only';
      srAnnouncements.setAttribute('aria-live', 'polite');
      document.body.appendChild(srAnnouncements);
    }
    
    // Create error announcement area if it doesn't exist
    let errorAnnouncements = document.getElementById('error-live-region');
    
    if (!errorAnnouncements) {
      errorAnnouncements = document.createElement('div');
      errorAnnouncements.id = 'error-live-region';
      errorAnnouncements.className = 'sr-only';
      errorAnnouncements.setAttribute('aria-live', 'assertive');
      document.body.appendChild(errorAnnouncements);
    }
    
    // Add offline mode indicator for screen readers
    const offlineIndicator = document.createElement('div');
    offlineIndicator.id = 'offline-indicator';
    offlineIndicator.className = 'offline-indicator';
    offlineIndicator.setAttribute('role', 'status');
    offlineIndicator.style.display = 'none';
    document.body.appendChild(offlineIndicator);
    
    // Update offline indicator when network status changes
    window.addEventListener('online', () => {
      offlineIndicator.style.display = 'none';
    });
    
    window.addEventListener('offline', () => {
      offlineIndicator.style.display = 'block';
      offlineIndicator.textContent = 'You are currently offline. Some features may be limited.';
    });
  }
  
  /**
   * Announce message to screen reader
   * @param {string} message - Message to announce
   */
  announceToScreenReader(message) {
    const srAnnouncements = document.getElementById('sr-announcements');
    
    if (srAnnouncements) {
      srAnnouncements.textContent = message;
    }
  }
  
  /**
   * Announce error to screen reader
   * @param {string} error - Error message to announce
   */
  announceErrorToScreenReader(error) {
    const errorAnnouncements = document.getElementById('error-live-region');
    
    if (errorAnnouncements) {
      errorAnnouncements.textContent = `Error: ${error}`;
    }
  }
  
  /**
   * Create settings UI for PWA features
   */
  createSettingsUI() {
    // Find or create settings container
    let settingsContainer = document.querySelector('.settings-container');
    
    if (!settingsContainer) {
      // Look for settings modal
      const settingsModal = document.querySelector('.settings-modal');
      
      if (settingsModal) {
        // Find content container within modal
        settingsContainer = settingsModal.querySelector('.settings-content');
        
        if (!settingsContainer) {
          // Create content container
          settingsContainer = document.createElement('div');
          settingsContainer.className = 'settings-content';
          settingsModal.appendChild(settingsContainer);
        }
      } else {
        // Create settings container if it doesn't exist
        settingsContainer = document.createElement('div');
        settingsContainer.className = 'settings-container';
        
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'settings-modal';
        
        // Create header
        const header = document.createElement('div');
        header.className = 'settings-header';
        
        const heading = document.createElement('h3');
        heading.textContent = 'Settings';
        
        const closeButton = document.createElement('button');
        closeButton.className = 'btn-close';
        closeButton.innerHTML = '&times;';
        closeButton.setAttribute('aria-label', 'Close');
        closeButton.addEventListener('click', () => {
          modal.classList.remove('active');
        });
        
        header.appendChild(heading);
        header.appendChild(closeButton);
        
        // Create settings content
        settingsContainer.appendChild(header);
        
        modal.appendChild(settingsContainer);
        document.body.appendChild(modal);
        
        // Create button to open settings
        const settingsButton = document.createElement('button');
        settingsButton.className = 'settings-button';
        settingsButton.setAttribute('aria-label', 'Settings');
        settingsButton.innerHTML = '<i class="fas fa-cog"></i>';
        settingsButton.addEventListener('click', () => {
          modal.classList.add('active');
        });
        
        // Add to appropriate container
        const container = document.querySelector('.app-header') || 
                          document.querySelector('header') || 
                          document.body;
        
        container.appendChild(settingsButton);
      }
    }
    
    // Create PWA settings section
    let pwaSettings = document.getElementById('pwa-settings');
    
    if (!pwaSettings) {
      pwaSettings = document.createElement('div');
      pwaSettings.id = 'pwa-settings';
      pwaSettings.className = 'settings-section';
      
      const heading = document.createElement('h3');
      heading.textContent = 'App Settings';
      pwaSettings.appendChild(heading);
      
      settingsContainer.appendChild(pwaSettings);
    }
    
    // Create offline settings
    if (this.offlineContent) {
      const offlineSection = document.createElement('div');
      offlineSection.className = 'settings-subsection';
      
      const offlineHeading = document.createElement('h4');
      offlineHeading.textContent = 'Offline Content';
      offlineSection.appendChild(offlineHeading);
      
      // Predictive caching toggle
      const predictiveCachingContainer = document.createElement('div');
      predictiveCachingContainer.className = 'setting-item';
      
      const predictiveCachingLabel = document.createElement('label');
      predictiveCachingLabel.textContent = 'Enable Predictive Caching';
      predictiveCachingLabel.setAttribute('for', 'predictive-caching-toggle');
      
      const predictiveCachingToggle = document.createElement('input');
      predictiveCachingToggle.type = 'checkbox';
      predictiveCachingToggle.id = 'predictive-caching-toggle';
      predictiveCachingToggle.checked = this.offlineContent.getUserPreferences().enablePredictiveCaching;
      predictiveCachingToggle.addEventListener('change', () => {
        this.offlineContent.updateUserPreferences({
          enablePredictiveCaching: predictiveCachingToggle.checked
        });
      });
      
      predictiveCachingContainer.appendChild(predictiveCachingLabel);
      predictiveCachingContainer.appendChild(predictiveCachingToggle);
      offlineSection.appendChild(predictiveCachingContainer);
      
      // Cache size slider
      const cacheSizeContainer = document.createElement('div');
      cacheSizeContainer.className = 'setting-item';
      
      const cacheSizeLabel = document.createElement('label');
      cacheSizeLabel.textContent = 'Maximum Cache Size (MB)';
      cacheSizeLabel.setAttribute('for', 'cache-size-slider');
      
      const cacheSizeValue = document.createElement('span');
      cacheSizeValue.className = 'setting-value';
      cacheSizeValue.textContent = (this.offlineContent.getUserPreferences().maxCacheSize / (1024 * 1024)).toFixed(0);
      
      const cacheSizeSlider = document.createElement('input');
      cacheSizeSlider.type = 'range';
      cacheSizeSlider.id = 'cache-size-slider';
      cacheSizeSlider.min = '10';
      cacheSizeSlider.max = '500';
      cacheSizeSlider.step = '10';
      cacheSizeSlider.value = (this.offlineContent.getUserPreferences().maxCacheSize / (1024 * 1024)).toFixed(0);
      cacheSizeSlider.addEventListener('input', () => {
        cacheSizeValue.textContent = cacheSizeSlider.value;
      });
      cacheSizeSlider.addEventListener('change', () => {
        this.offlineContent.updateUserPreferences({
          maxCacheSize: parseInt(cacheSizeSlider.value, 10) * 1024 * 1024
        });
      });
      
      cacheSizeContainer.appendChild(cacheSizeLabel);
      cacheSizeContainer.appendChild(cacheSizeSlider);
      cacheSizeContainer.appendChild(cacheSizeValue);
      offlineSection.appendChild(cacheSizeContainer);
      
      // WiFi only toggle
      const wifiOnlyContainer = document.createElement('div');
      wifiOnlyContainer.className = 'setting-item';
      
      const wifiOnlyLabel = document.createElement('label');
      wifiOnlyLabel.textContent = 'Prefetch on WiFi Only';
      wifiOnlyLabel.setAttribute('for', 'wifi-only-toggle');
      
      const wifiOnlyToggle = document.createElement('input');
      wifiOnlyToggle.type = 'checkbox';
      wifiOnlyToggle.id = 'wifi-only-toggle';
      wifiOnlyToggle.checked = this.offlineContent.getUserPreferences().prefetchOnWifi;
      wifiOnlyToggle.addEventListener('change', () => {
        this.offlineContent.updateUserPreferences({
          prefetchOnWifi: wifiOnlyToggle.checked
        });
      });
      
      wifiOnlyContainer.appendChild(wifiOnlyLabel);
      wifiOnlyContainer.appendChild(wifiOnlyToggle);
      offlineSection.appendChild(wifiOnlyContainer);
      
      // Cache stats
      const cacheStatsContainer = document.createElement('div');
      cacheStatsContainer.className = 'setting-info';
      
      const cacheStatsHeading = document.createElement('h5');
      cacheStatsHeading.textContent = 'Cache Statistics';
      
      const cacheStats = this.offlineContent.getCacheStats();
      
      const cacheStatsContent = document.createElement('div');
      cacheStatsContent.innerHTML = `
        <p>Used: ${cacheStats.sizeInMB} MB (${cacheStats.percentUsed}%)</p>
        <p>Items: ${cacheStats.items}</p>
        <p>Last updated: ${new Date(cacheStats.lastUpdated).toLocaleTimeString()}</p>
      `;
      
      const clearCacheButton = document.createElement('button');
      clearCacheButton.textContent = 'Clear Cache';
      clearCacheButton.className = 'btn btn-secondary';
      clearCacheButton.addEventListener('click', async () => {
        const count = await this.offlineContent.cleanupCache();
        this.announceToScreenReader(`Cache cleared. Removed ${count} items.`);
        
        // Update stats display
        const newStats = this.offlineContent.getCacheStats();
        cacheStatsContent.innerHTML = `
          <p>Used: ${newStats.sizeInMB} MB (${newStats.percentUsed}%)</p>
          <p>Items: ${newStats.items}</p>
          <p>Last updated: ${new Date(newStats.lastUpdated).toLocaleTimeString()}</p>
        `;
      });
      
      cacheStatsContainer.appendChild(cacheStatsHeading);
      cacheStatsContainer.appendChild(cacheStatsContent);
      cacheStatsContainer.appendChild(clearCacheButton);
      offlineSection.appendChild(cacheStatsContainer);
      
      pwaSettings.appendChild(offlineSection);
    }
    
    // Create prefetching settings
    if (this.contentPrefetcher) {
      const prefetchSection = document.createElement('div');
      prefetchSection.className = 'settings-subsection';
      
      const prefetchHeading = document.createElement('h4');
      prefetchHeading.textContent = 'Content Prefetching';
      prefetchSection.appendChild(prefetchHeading);
      
      // Enable prefetching toggle
      const enablePrefetchContainer = document.createElement('div');
      enablePrefetchContainer.className = 'setting-item';
      
      const enablePrefetchLabel = document.createElement('label');
      enablePrefetchLabel.textContent = 'Enable Smart Prefetching';
      enablePrefetchLabel.setAttribute('for', 'enable-prefetch-toggle');
      
      const enablePrefetchToggle = document.createElement('input');
      enablePrefetchToggle.type = 'checkbox';
      enablePrefetchToggle.id = 'enable-prefetch-toggle';
      enablePrefetchToggle.checked = this.contentPrefetcher.config.enabled;
      enablePrefetchToggle.addEventListener('change', () => {
        this.contentPrefetcher.updateConfig({
          enabled: enablePrefetchToggle.checked
        });
      });
      
      enablePrefetchContainer.appendChild(enablePrefetchLabel);
      enablePrefetchContainer.appendChild(enablePrefetchToggle);
      prefetchSection.appendChild(enablePrefetchContainer);
      
      // Prefetch on cellular toggle
      const cellularPrefetchContainer = document.createElement('div');
      cellularPrefetchContainer.className = 'setting-item';
      
      const cellularPrefetchLabel = document.createElement('label');
      cellularPrefetchLabel.textContent = 'Allow Prefetching on Cellular';
      cellularPrefetchLabel.setAttribute('for', 'cellular-prefetch-toggle');
      
      const cellularPrefetchToggle = document.createElement('input');
      cellularPrefetchToggle.type = 'checkbox';
      cellularPrefetchToggle.id = 'cellular-prefetch-toggle';
      cellularPrefetchToggle.checked = this.contentPrefetcher.config.networkConditions.cellular.enabled;
      cellularPrefetchToggle.addEventListener('change', () => {
        const newConfig = { ...this.contentPrefetcher.config };
        newConfig.networkConditions.cellular.enabled = cellularPrefetchToggle.checked;
        this.contentPrefetcher.updateConfig(newConfig);
      });
      
      cellularPrefetchContainer.appendChild(cellularPrefetchLabel);
      cellularPrefetchContainer.appendChild(cellularPrefetchToggle);
      prefetchSection.appendChild(cellularPrefetchContainer);
      
      // Prefetch status
      const prefetchStatusContainer = document.createElement('div');
      prefetchStatusContainer.className = 'setting-info';
      
      const prefetchStatusHeading = document.createElement('h5');
      prefetchStatusHeading.textContent = 'Prefetch Status';
      
      const status = this.contentPrefetcher.getQueueStatus();
      
      const prefetchStatusContent = document.createElement('div');
      prefetchStatusContent.innerHTML = `
        <p>Network: ${status.networkType}</p>
        <p>Battery: ${status.batteryLevel}%</p>
        <p>Queue: ${status.queueLength} items</p>
        <p>Active: ${status.activePrefetches} prefetches</p>
      `;
      
      prefetchStatusContainer.appendChild(prefetchStatusHeading);
      prefetchStatusContainer.appendChild(prefetchStatusContent);
      prefetchSection.appendChild(prefetchStatusContainer);
      
      pwaSettings.appendChild(prefetchSection);
    }
    
    // Add app installation section
    const installSection = document.createElement('div');
    installSection.className = 'settings-subsection';
    
    const installHeading = document.createElement('h4');
    installHeading.textContent = 'App Installation';
    installSection.appendChild(installHeading);
    
    // Check if app can be installed
    const canBeInstalled = this.originalPWA.canBeInstalled();
    
    if (canBeInstalled) {
      const installButton = document.createElement('button');
      installButton.textContent = 'Install App';
      installButton.className = 'btn btn-primary';
      installButton.addEventListener('click', async () => {
        const installed = await this.originalPWA.showInstallPrompt();
        if (installed) {
          installButton.style.display = 'none';
          installStatusContent.textContent = 'App is installed.';
        }
      });
      
      installSection.appendChild(installButton);
    }
    
    // Installation status
    const installStatusContainer = document.createElement('div');
    installStatusContainer.className = 'setting-info';
    
    const installStatusContent = document.createElement('p');
    installStatusContent.textContent = canBeInstalled ? 
      'App can be installed on your device.' : 
      'App is already installed or cannot be installed on this device.';
    
    installStatusContainer.appendChild(installStatusContent);
    installSection.appendChild(installStatusContainer);
    
    pwaSettings.appendChild(installSection);
  }
  
  /**
   * Queue an API request for background sync when offline
   * @param {Request} request - The request to queue
   * @returns {Promise<string|null>} ID of the queued request or null if not queued
   */
  async queueApiRequest(request) {
    return this.originalPWA.queueApiRequest(request);
  }
  
  /**
   * Cache content with priority level
   * @param {string} url - URL of the content to cache
   * @param {string} priority - Priority level ('critical', 'high', 'medium', 'low')
   * @param {Object} metadata - Additional metadata about the content
   * @returns {Promise<boolean>} Whether caching was successful
   */
  async cacheContent(url, priority = 'medium', metadata = {}) {
    if (this.offlineContent) {
      return this.offlineContent.cacheContent(url, priority, metadata);
    }
    return false;
  }
  
  /**
   * Prefetch content based on URL and priority
   * @param {string} url - URL of the content to prefetch
   * @param {number} priority - Priority (1-10, higher is more important)
   * @returns {Promise<boolean>} Whether prefetching was queued
   */
  queuePrefetch(url, priority = 5) {
    if (this.contentPrefetcher) {
      this.contentPrefetcher.queuePrefetch(url, priority);
      return true;
    }
    return false;
  }
  
  /**
   * Show a notification
   * @param {string} title - Notification title
   * @param {Object} options - Notification options
   * @returns {Promise<boolean>} Whether notification was shown
   */
  async showNotification(title, options = {}) {
    if (this.pushNotifications) {
      return this.pushNotifications.showNotification(title, options);
    }
    return false;
  }
  
  /**
   * Update user preferences for notifications
   * @param {Object} preferences - New preferences
   * @returns {boolean} Whether update was successful
   */
  updateNotificationPreferences(preferences) {
    if (this.pushNotifications) {
      this.pushNotifications.updateUserPreferences(preferences);
      return true;
    }
    return false;
  }
  
  /**
   * Get the status of all PWA features
   * @returns {Object} Status of all PWA features
   */
  getStatus() {
    return {
      isOnline: navigator.onLine,
      offlineContent: this.offlineContent ? {
        enabled: this.offlineContent.getUserPreferences().enablePredictiveCaching,
        cacheStats: this.offlineContent.getCacheStats()
      } : null,
      contentPrefetcher: this.contentPrefetcher ? {
        enabled: this.contentPrefetcher.config.enabled,
        queueStatus: this.contentPrefetcher.getQueueStatus()
      } : null,
      pushNotifications: this.pushNotifications ? {
        enabled: this.pushNotifications.getUserPreferences().enabled,
        permission: this.pushNotifications.getPermissionStatus()
      } : null,
      appInstallation: {
        canBeInstalled: this.originalPWA.canBeInstalled()
      }
    };
  }
}

// Create and export a singleton instance
const enhancedPWA = new EnhancedPWAIntegration();

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    enhancedPWA.init();
  });
} else {
  enhancedPWA.init();
}

export default enhancedPWA;
