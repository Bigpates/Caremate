/**
 * Care Mate - Background Sync Manager
 * 
 * This module provides functionality for queuing API requests when offline
 * and syncing them when the connection is restored using the Background Sync API.
 */

class BackgroundSyncManager {
  constructor() {
    this.dbName = 'care-mate-sync-db';
    this.storeName = 'sync-requests';
    this.syncQueueName = 'care-mate-sync-queue';
    this.db = null;
    
    // Bind methods
    this.init = this.init.bind(this);
    this.openDatabase = this.openDatabase.bind(this);
    this.queueRequest = this.queueRequest.bind(this);
    this.registerSync = this.registerSync.bind(this);
    this.setupEventListeners = this.setupEventListeners.bind(this);
    
    // Initialize
    this.init();
  }
  
  /**
   * Initialize the sync manager
   */
  async init() {
    try {
      // Open the database
      this.db = await this.openDatabase();
      
      // Set up event listeners
      this.setupEventListeners();
      
      console.log('[BackgroundSync] Initialized successfully');
    } catch (error) {
      console.error('[BackgroundSync] Initialization failed:', error);
    }
  }
  
  /**
   * Open the IndexedDB database
   * @returns {Promise<IDBDatabase>} The database
   */
  openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1);
      
      request.onerror = event => {
        reject('Database error: ' + event.target.errorCode);
      };
      
      request.onsuccess = event => {
        resolve(event.target.result);
      };
      
      request.onupgradeneeded = event => {
        const db = event.target.result;
        
        // Create object store for sync requests
        if (!db.objectStoreNames.contains(this.storeName)) {
          const store = db.createObjectStore(this.storeName, { keyPath: 'id' });
          store.createIndex('timestamp', 'timestamp', { unique: false });
        }
      };
    });
  }
  
  /**
   * Queue a request for background sync
   * @param {Request} request - The request to queue
   * @returns {Promise<string>} ID of the queued request
   */
  async queueRequest(request) {
    try {
      // Clone the request to read its body
      const clonedRequest = request.clone();
      
      // Extract request details
      const body = await clonedRequest.text();
      const headers = {};
      clonedRequest.headers.forEach((value, key) => {
        headers[key] = value;
      });
      
      // Create a unique ID
      const id = `sync-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      // Store the request in IndexedDB
      const transaction = this.db.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      
      const syncRequest = {
        id,
        url: request.url,
        method: request.method,
        headers,
        body,
        timestamp: Date.now()
      };
      
      await new Promise((resolve, reject) => {
        const storeRequest = store.add(syncRequest);
        storeRequest.onsuccess = () => resolve();
        storeRequest.onerror = event => reject(event.target.error);
      });
      
      // Register for background sync
      await this.registerSync();
      
      console.log('[BackgroundSync] Request queued:', id);
      return id;
    } catch (error) {
      console.error('[BackgroundSync] Failed to queue request:', error);
      throw error;
    }
  }
  
  /**
   * Register for background sync
   * @returns {Promise<void>}
   */
  async registerSync() {
    try {
      if ('serviceWorker' in navigator && 'SyncManager' in window) {
        const registration = await navigator.serviceWorker.ready;
        await registration.sync.register(this.syncQueueName);
        console.log('[BackgroundSync] Sync registered');
      } else {
        console.warn('[BackgroundSync] Background Sync not supported');
      }
    } catch (error) {
      console.error('[BackgroundSync] Failed to register sync:', error);
    }
  }
  
  /**
   * Set up event listeners
   */
  setupEventListeners() {
    // Listen for messages from the service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', event => {
        if (event.data && event.data.type === 'SYNC_COMPLETED') {
          console.log(
            '[BackgroundSync] Sync completed:',
            event.data.successCount,
            'of',
            event.data.totalCount,
            'requests processed'
          );
          
          // Dispatch a custom event
          window.dispatchEvent(new CustomEvent('background-sync-completed', {
            detail: {
              successCount: event.data.successCount,
              totalCount: event.data.totalCount
            }
          }));
        }
      });
    }
    
    // Listen for online/offline events
    window.addEventListener('online', () => {
      console.log('[BackgroundSync] Device is online, triggering sync');
      this.registerSync();
    });
    
    window.addEventListener('offline', () => {
      console.log('[BackgroundSync] Device is offline');
    });
  }
  
  /**
   * Check if background sync is supported
   * @returns {boolean} Whether background sync is supported
   */
  isSupported() {
    return 'serviceWorker' in navigator && 'SyncManager' in window;
  }
  
  /**
   * Get all pending sync requests
   * @returns {Promise<Array>} Array of pending requests
   */
  async getPendingRequests() {
    try {
      const transaction = this.db.transaction([this.storeName], 'readonly');
      const store = transaction.objectStore(this.storeName);
      
      return new Promise((resolve, reject) => {
        const request = store.getAll();
        request.onsuccess = event => resolve(event.target.result);
        request.onerror = event => reject(event.target.error);
      });
    } catch (error) {
      console.error('[BackgroundSync] Failed to get pending requests:', error);
      return [];
    }
  }
  
  /**
   * Clear all pending sync requests
   * @returns {Promise<void>}
   */
  async clearPendingRequests() {
    try {
      const transaction = this.db.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      
      return new Promise((resolve, reject) => {
        const request = store.clear();
        request.onsuccess = () => resolve();
        request.onerror = event => reject(event.target.error);
      });
    } catch (error) {
      console.error('[BackgroundSync] Failed to clear pending requests:', error);
    }
  }
}

// Export the BackgroundSyncManager class
export default BackgroundSyncManager;
