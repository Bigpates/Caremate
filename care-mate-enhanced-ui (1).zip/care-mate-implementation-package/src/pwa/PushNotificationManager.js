/**
 * Care Mate - Push Notification Manager
 * 
 * This module provides functionality for managing push notifications,
 * including subscription management, permission handling, and sending
 * notifications to users.
 */

class PushNotificationManager {
  constructor() {
    this.serverPublicKey = 'BLGrxQGXHCPBX9Lv4K0wsA8ySuRTBRYJkMZQBp9KQPjnIm9vJQJiTsLKj_SYB_K1vqNzYk7pG6Dz7ozX3iG0XDk';
    this.isSubscribed = false;
    this.swRegistration = null;
    
    // Bind methods
    this.init = this.init.bind(this);
    this.registerServiceWorker = this.registerServiceWorker.bind(this);
    this.checkSubscription = this.checkSubscription.bind(this);
    this.subscribe = this.subscribe.bind(this);
    this.unsubscribe = this.unsubscribe.bind(this);
    this.updateSubscriptionOnServer = this.updateSubscriptionOnServer.bind(this);
    this.setupUI = this.setupUI.bind(this);
    
    // Initialize
    this.init();
  }
  
  /**
   * Initialize the push notification manager
   */
  async init() {
    try {
      // Check if push notifications are supported
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
        console.warn('[PushNotification] Push notifications not supported');
        return;
      }
      
      // Register service worker
      this.swRegistration = await this.registerServiceWorker();
      
      // Check subscription status
      await this.checkSubscription();
      
      // Set up UI elements
      this.setupUI();
      
      console.log('[PushNotification] Initialized successfully');
    } catch (error) {
      console.error('[PushNotification] Initialization failed:', error);
    }
  }
  
  /**
   * Register the service worker
   * @returns {Promise<ServiceWorkerRegistration>} Service worker registration
   */
  async registerServiceWorker() {
    try {
      return await navigator.serviceWorker.register('/enhanced-service-worker.js');
    } catch (error) {
      console.error('[PushNotification] Service Worker registration failed:', error);
      throw error;
    }
  }
  
  /**
   * Check if the user is already subscribed to push notifications
   */
  async checkSubscription() {
    try {
      const subscription = await this.swRegistration.pushManager.getSubscription();
      this.isSubscribed = subscription !== null;
      
      console.log('[PushNotification] User is' + (this.isSubscribed ? '' : ' not') + ' subscribed');
      
      // Update UI based on subscription status
      this.updateUI();
      
      return this.isSubscribed;
    } catch (error) {
      console.error('[PushNotification] Error checking subscription:', error);
      return false;
    }
  }
  
  /**
   * Subscribe to push notifications
   */
  async subscribe() {
    try {
      // Request notification permission
      const permission = await Notification.requestPermission();
      
      if (permission !== 'granted') {
        console.warn('[PushNotification] Permission not granted');
        return false;
      }
      
      // Convert the public key to Uint8Array
      const applicationServerKey = this.urlB64ToUint8Array(this.serverPublicKey);
      
      // Subscribe to push notifications
      const subscription = await this.swRegistration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey
      });
      
      console.log('[PushNotification] User subscribed:', subscription);
      
      // Update subscription on server
      await this.updateSubscriptionOnServer(subscription);
      
      this.isSubscribed = true;
      this.updateUI();
      
      return true;
    } catch (error) {
      console.error('[PushNotification] Failed to subscribe:', error);
      return false;
    }
  }
  
  /**
   * Unsubscribe from push notifications
   */
  async unsubscribe() {
    try {
      const subscription = await this.swRegistration.pushManager.getSubscription();
      
      if (!subscription) {
        console.warn('[PushNotification] No subscription to unsubscribe from');
        return false;
      }
      
      // Unsubscribe
      await subscription.unsubscribe();
      
      console.log('[PushNotification] User unsubscribed');
      
      // Update subscription on server
      await this.updateSubscriptionOnServer(null);
      
      this.isSubscribed = false;
      this.updateUI();
      
      return true;
    } catch (error) {
      console.error('[PushNotification] Error unsubscribing:', error);
      return false;
    }
  }
  
  /**
   * Update subscription on server
   * @param {PushSubscription|null} subscription - Push subscription or null if unsubscribed
   */
  async updateSubscriptionOnServer(subscription) {
    try {
      const endpoint = '/api/push-subscription';
      
      if (subscription) {
        // Send subscription to server
        await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(subscription)
        });
      } else {
        // Remove subscription from server
        await fetch(endpoint, {
          method: 'DELETE'
        });
      }
      
      console.log('[PushNotification] Subscription updated on server');
      return true;
    } catch (error) {
      console.error('[PushNotification] Failed to update subscription on server:', error);
      return false;
    }
  }
  
  /**
   * Set up UI elements for push notifications
   */
  setupUI() {
    // Find or create push notification toggle button
    let pushToggle = document.getElementById('push-notification-toggle');
    
    if (!pushToggle) {
      // Create the button if it doesn't exist
      pushToggle = document.createElement('button');
      pushToggle.id = 'push-notification-toggle';
      pushToggle.className = 'push-notification-toggle';
      pushToggle.setAttribute('aria-label', 'Toggle Push Notifications');
      
      // Add to notification settings section or create one
      let notificationSettings = document.getElementById('notification-settings');
      
      if (!notificationSettings) {
        notificationSettings = document.createElement('div');
        notificationSettings.id = 'notification-settings';
        notificationSettings.className = 'settings-section';
        
        const heading = document.createElement('h3');
        heading.textContent = 'Notification Settings';
        notificationSettings.appendChild(heading);
        
        // Add to settings container or body
        const settingsContainer = document.querySelector('.settings-container') || document.body;
        settingsContainer.appendChild(notificationSettings);
      }
      
      notificationSettings.appendChild(pushToggle);
    }
    
    // Add event listener
    pushToggle.addEventListener('click', async () => {
      if (this.isSubscribed) {
        await this.unsubscribe();
      } else {
        await this.subscribe();
      }
    });
    
    // Initial UI update
    this.updateUI();
  }
  
  /**
   * Update UI based on subscription status
   */
  updateUI() {
    const pushToggle = document.getElementById('push-notification-toggle');
    
    if (pushToggle) {
      pushToggle.textContent = this.isSubscribed ? 'Disable Notifications' : 'Enable Notifications';
      pushToggle.classList.toggle('subscribed', this.isSubscribed);
      pushToggle.setAttribute('aria-pressed', this.isSubscribed);
    }
  }
  
  /**
   * Convert base64 string to Uint8Array for applicationServerKey
   * @param {string} base64String - Base64 encoded string
   * @returns {Uint8Array} Converted array
   */
  urlB64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/\-/g, '+')
      .replace(/_/g, '/');
    
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    
    return outputArray;
  }
  
  /**
   * Check if push notifications are supported
   * @returns {boolean} Whether push notifications are supported
   */
  isSupported() {
    return 'serviceWorker' in navigator && 'PushManager' in window;
  }
  
  /**
   * Get the current permission status
   * @returns {string} Permission status ('granted', 'denied', or 'default')
   */
  getPermissionStatus() {
    return Notification.permission;
  }
  
  /**
   * Send a test notification
   * @param {string} title - Notification title
   * @param {string} body - Notification body
   * @returns {Promise<boolean>} Whether the notification was sent
   */
  async sendTestNotification(title = 'Test Notification', body = 'This is a test notification from Care Mate') {
    try {
      if (!this.isSubscribed) {
        console.warn('[PushNotification] User not subscribed to notifications');
        return false;
      }
      
      // In a real app, this would be sent from the server
      // This is just a client-side simulation
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        
        await registration.showNotification(title, {
          body,
          icon: '/assets/icons/icon-192x192.png',
          badge: '/assets/icons/badge-96x96.png',
          vibrate: [100, 50, 100],
          data: {
            url: window.location.href
          }
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('[PushNotification] Error sending test notification:', error);
      return false;
    }
  }
}

// Export the PushNotificationManager class
export default PushNotificationManager;
