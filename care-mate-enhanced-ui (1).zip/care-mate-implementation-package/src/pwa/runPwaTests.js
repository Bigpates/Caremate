/**
 * Care Mate - PWA Test Runner
 * 
 * This script runs the PWA test framework in the browser environment
 * and generates a comprehensive report of PWA feature compliance.
 */

import PWATestFramework from './PWATestFramework.js';

// Create test framework instance
const pwaTestFramework = new PWATestFramework({
  logLevel: 'info',
  testTimeout: 30000,
  retryCount: 3
});

// Run tests when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', runTests);
} else {
  runTests();
}

/**
 * Run PWA tests and display results
 */
async function runTests() {
  console.log('Starting PWA tests...');
  
  // Create or find results container
  let resultsContainer = document.getElementById('pwa-test-results');
  
  if (!resultsContainer) {
    resultsContainer = document.createElement('div');
    resultsContainer.id = 'pwa-test-results';
    resultsContainer.className = 'pwa-test-results';
    document.body.appendChild(resultsContainer);
  }
  
  // Show loading indicator
  resultsContainer.innerHTML = '<p>Running PWA tests...</p>';
  
  try {
    // Run tests
    const results = await pwaTestFramework.runTests();
    
    // Generate HTML report
    const htmlReport = pwaTestFramework.generateReport('html');
    
    // Display results
    resultsContainer.innerHTML = htmlReport;
    
    // Save results to localStorage for later reference
    localStorage.setItem('pwa-test-results', JSON.stringify(results));
    localStorage.setItem('pwa-test-timestamp', Date.now().toString());
    
    console.log('PWA tests completed:', results);
  } catch (error) {
    console.error('Error running PWA tests:', error);
    resultsContainer.innerHTML = `
      <div class="error">
        <h2>Error Running PWA Tests</h2>
        <p>${error.message}</p>
      </div>
    `;
  }
}

// Export the test framework for external use
export { pwaTestFramework };
