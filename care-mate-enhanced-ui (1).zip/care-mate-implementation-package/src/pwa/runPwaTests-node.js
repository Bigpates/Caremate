/**
 * Care Mate - PWA Test Runner (Node.js version)
 * 
 * This script runs the PWA test framework in a Node.js environment
 * for automated testing and CI/CD integration.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Get current file directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Mock browser environment for testing
global.window = {
  matchMedia: () => ({
    matches: false,
    addEventListener: () => {}
  }),
  addEventListener: () => {},
  navigator: {
    serviceWorker: {
      register: async () => ({ scope: '/' }),
      getRegistration: async () => null,
      ready: Promise.resolve({
        sync: {
          register: async () => {}
        },
        pushManager: {
          getSubscription: async () => null
        }
      })
    },
    onLine: true
  },
  caches: {
    open: async () => ({
      match: async () => null,
      keys: async () => [],
      put: async () => {}
    }),
    keys: async () => []
  },
  indexedDB: {
    open: () => ({
      onerror: null,
      onsuccess: null,
      onupgradeneeded: null
    })
  },
  Notification: {
    permission: 'default',
    requestPermission: async () => 'default'
  }
};

global.document = {
  readyState: 'complete',
  createElement: () => ({
    className: '',
    style: {},
    appendChild: () => {}
  }),
  body: {
    appendChild: () => {}
  },
  querySelectorAll: () => [],
  getElementById: () => null,
  querySelector: () => null,
  addEventListener: () => {}
};

// Import the test framework - using dynamic import to handle ES modules
async function main() {
  console.log('Starting PWA tests in Node.js environment...');
  
  try {
    // Dynamically import the test framework
    const { default: PWATestFramework } = await import('./PWATestFramework.js');
    
    // Create test framework instance
    const pwaTestFramework = new PWATestFramework({
      logLevel: 'info',
      testTimeout: 5000, // Reduced timeout for faster testing
      retryCount: 1,
      testEnvironment: 'node'
    });
    
    console.log('Running PWA tests...');
    
    // Run tests
    const results = await pwaTestFramework.runTests();
    
    // Generate reports
    const jsonReport = pwaTestFramework.generateReport('json');
    const textReport = pwaTestFramework.generateReport('text');
    
    // Save reports to files
    const reportsDir = path.join(__dirname, '..', 'reports');
    
    // Create reports directory if it doesn't exist
    if (!fs.existsSync(reportsDir)) {
      fs.mkdirSync(reportsDir, { recursive: true });
    }
    
    // Save JSON report
    fs.writeFileSync(
      path.join(reportsDir, 'pwa-test-results.json'),
      jsonReport
    );
    
    // Save text report
    fs.writeFileSync(
      path.join(reportsDir, 'pwa-test-results.txt'),
      textReport
    );
    
    console.log('PWA tests completed:');
    console.log(`- Passed: ${results.passed}`);
    console.log(`- Failed: ${results.failed}`);
    console.log(`- Skipped: ${results.skipped}`);
    console.log(`- Total: ${results.total}`);
    console.log(`Reports saved to ${reportsDir}`);
    
    // Explicitly exit to avoid hanging
    console.log('Exiting test runner...');
    process.exit(results.failed > 0 ? 1 : 0);
  } catch (error) {
    console.error('Error running PWA tests:', error);
    process.exit(1);
  }
}

// Run the main function
main().catch(error => {
  console.error('Unhandled error in test runner:', error);
  process.exit(1);
});
