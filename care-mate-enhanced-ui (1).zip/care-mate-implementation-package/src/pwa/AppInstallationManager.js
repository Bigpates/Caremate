/**
 * Care Mate - App Installation Manager
 * 
 * This module provides functionality for managing the installation of the
 * Care Mate PWA, including detecting installation eligibility, prompting
 * users to install, and tracking installation events.
 */

class AppInstallationManager {
  constructor() {
    this.deferredPrompt = null;
    this.isInstallable = false;
    this.isInstalled = false;
    
    // Bind methods
    this.init = this.init.bind(this);
    this.setupEventListeners = this.setupEventListeners.bind(this);
    this.checkInstallationStatus = this.checkInstallationStatus.bind(this);
    this.showInstallPrompt = this.showInstallPrompt.bind(this);
    this.createInstallButton = this.createInstallButton.bind(this);
    this.updateUI = this.updateUI.bind(this);
    
    // Initialize
    this.init();
  }
  
  /**
   * Initialize the app installation manager
   */
  init() {
    // Check if app is already installed
    this.checkInstallationStatus();
    
    // Set up event listeners
    this.setupEventListeners();
    
    // Create install button
    this.createInstallButton();
    
    console.log('[AppInstall] Initialized successfully');
  }
  
  /**
   * Set up event listeners for installation events
   */
  setupEventListeners() {
    // Listen for beforeinstallprompt event
    window.addEventListener('beforeinstallprompt', (event) => {
      // Prevent the default prompt
      event.preventDefault();
      
      // Store the event for later use
      this.deferredPrompt = event;
      this.isInstallable = true;
      
      console.log('[AppInstall] App is installable');
      
      // Update UI
      this.updateUI();
    });
    
    // Listen for appinstalled event
    window.addEventListener('appinstalled', (event) => {
      this.isInstalled = true;
      this.deferredPrompt = null;
      
      console.log('[AppInstall] App was installed');
      
      // Track installation
      this.trackInstallation();
      
      // Update UI
      this.updateUI();
    });
    
    // Listen for display mode changes
    window.matchMedia('(display-mode: standalone)').addEventListener('change', (event) => {
      this.isInstalled = event.matches;
      console.log('[AppInstall] Display mode changed, standalone:', event.matches);
      this.updateUI();
    });
  }
  
  /**
   * Check if the app is already installed
   */
  checkInstallationStatus() {
    // Check if app is in standalone mode
    if (window.matchMedia('(display-mode: standalone)').matches) {
      this.isInstalled = true;
      console.log('[AppInstall] App is already installed (standalone mode)');
    }
    
    // Check if app was launched from homescreen
    if (window.navigator.standalone === true) {
      this.isInstalled = true;
      console.log('[AppInstall] App is already installed (iOS standalone)');
    }
  }
  
  /**
   * Show the installation prompt
   * @returns {Promise<boolean>} Whether the app was installed
   */
  async showInstallPrompt() {
    if (!this.deferredPrompt) {
      console.warn('[AppInstall] No installation prompt available');
      return false;
    }
    
    try {
      // Show the prompt
      this.deferredPrompt.prompt();
      
      // Wait for the user to respond
      const choiceResult = await this.deferredPrompt.userChoice;
      
      // Reset the deferred prompt
      this.deferredPrompt = null;
      
      if (choiceResult.outcome === 'accepted') {
        console.log('[AppInstall] User accepted the installation prompt');
        return true;
      } else {
        console.log('[AppInstall] User dismissed the installation prompt');
        return false;
      }
    } catch (error) {
      console.error('[AppInstall] Error showing installation prompt:', error);
      return false;
    }
  }
  
  /**
   * Create an install button in the UI
   */
  createInstallButton() {
    // Find or create install button
    let installButton = document.getElementById('app-install-button');
    
    if (!installButton) {
      // Create the button if it doesn't exist
      installButton = document.createElement('button');
      installButton.id = 'app-install-button';
      installButton.className = 'app-install-button';
      installButton.setAttribute('aria-label', 'Install App');
      installButton.textContent = 'Install App';
      
      // Add to appropriate container
      const container = document.querySelector('.app-header') || 
                        document.querySelector('header') || 
                        document.body;
      
      container.appendChild(installButton);
    }
    
    // Add event listener
    installButton.addEventListener('click', async () => {
      await this.showInstallPrompt();
    });
    
    // Initial UI update
    this.updateUI();
  }
  
  /**
   * Update UI based on installation status
   */
  updateUI() {
    const installButton = document.getElementById('app-install-button');
    
    if (installButton) {
      // Show button only if app is installable and not already installed
      if (this.isInstallable && !this.isInstalled) {
        installButton.style.display = 'block';
      } else {
        installButton.style.display = 'none';
      }
    }
  }
  
  /**
   * Track installation event (analytics)
   */
  trackInstallation() {
    // In a real app, this would send data to an analytics service
    console.log('[AppInstall] Tracking installation event');
    
    // Example analytics event
    if (window.gtag) {
      window.gtag('event', 'app_install', {
        event_category: 'engagement',
        event_label: 'PWA Installation'
      });
    }
  }
  
  /**
   * Check if the app can be installed
   * @returns {boolean} Whether the app can be installed
   */
  canBeInstalled() {
    return this.isInstallable && !this.isInstalled;
  }
  
  /**
   * Check if the app is already installed
   * @returns {boolean} Whether the app is installed
   */
  isAppInstalled() {
    return this.isInstalled;
  }
}

// Export the AppInstallationManager class
export default AppInstallationManager;
