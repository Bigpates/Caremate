/**
 * Care Mate - PWA Test Framework
 * 
 * This module provides a comprehensive testing framework for validating
 * PWA features including offline capabilities, push notifications,
 * background sync, and installation.
 */

class PWATestFramework {
  constructor(options = {}) {
    // Default configuration
    this.config = {
      testTimeout: 30000, // 30 seconds
      retryCount: 3,
      logLevel: 'info', // 'debug', 'info', 'warn', 'error'
      testEnvironment: 'browser', // 'browser', 'node'
      ...options
    };
    
    // Test results
    this.results = {
      passed: 0,
      failed: 0,
      skipped: 0,
      total: 0,
      tests: []
    };
    
    // Bind methods
    this.runTests = this.runTests.bind(this);
    this.testServiceWorker = this.testServiceWorker.bind(this);
    this.testCaching = this.testCaching.bind(this);
    this.testOfflineSupport = this.testOfflineSupport.bind(this);
    this.testBackgroundSync = this.testBackgroundSync.bind(this);
    this.testPushNotifications = this.testPushNotifications.bind(this);
    this.testInstallability = this.testInstallability.bind(this);
    this.testAccessibility = this.testAccessibility.bind(this);
    this.generateReport = this.generateReport.bind(this);
  }
  
  /**
   * Run all PWA tests
   * @returns {Promise<Object>} Test results
   */
  async runTests() {
    this.log('info', 'Starting PWA tests...');
    
    // Reset results
    this.results = {
      passed: 0,
      failed: 0,
      skipped: 0,
      total: 0,
      tests: [],
      startTime: Date.now()
    };
    
    try {
      // Run tests
      await this.testServiceWorker();
      await this.testCaching();
      await this.testOfflineSupport();
      await this.testBackgroundSync();
      await this.testPushNotifications();
      await this.testInstallability();
      await this.testAccessibility();
      
      // Generate report
      this.results.endTime = Date.now();
      this.results.duration = this.results.endTime - this.results.startTime;
      
      this.log('info', `PWA tests completed: ${this.results.passed} passed, ${this.results.failed} failed, ${this.results.skipped} skipped`);
      
      return this.results;
    } catch (error) {
      this.log('error', 'Error running PWA tests:', error);
      
      this.results.error = error.message;
      this.results.endTime = Date.now();
      this.results.duration = this.results.endTime - this.results.startTime;
      
      return this.results;
    }
  }
  
  /**
   * Test service worker registration and activation
   * @returns {Promise<void>}
   */
  async testServiceWorker() {
    this.log('info', 'Testing service worker...');
    
    // Skip if not in browser environment
    if (this.config.testEnvironment !== 'browser') {
      this.recordTest('service-worker-registration', 'skipped', 'Service worker tests can only run in browser environment');
      this.recordTest('service-worker-activation', 'skipped', 'Service worker tests can only run in browser environment');
      return;
    }
    
    // Test service worker registration
    try {
      // Check if service worker is supported
      if (!('serviceWorker' in navigator)) {
        this.recordTest('service-worker-support', 'failed', 'Service Worker is not supported in this browser');
        return;
      } else {
        this.recordTest('service-worker-support', 'passed');
      }
      
      // Check if service worker is registered
      const registration = await navigator.serviceWorker.getRegistration();
      
      if (registration) {
        this.recordTest('service-worker-registration', 'passed', 'Service worker is registered');
        
        // Check service worker state
        const activeWorker = registration.active;
        
        if (activeWorker) {
          this.recordTest('service-worker-activation', 'passed', `Service worker is active (${activeWorker.scriptURL})`);
        } else {
          this.recordTest('service-worker-activation', 'failed', 'Service worker is registered but not active');
        }
      } else {
        this.recordTest('service-worker-registration', 'failed', 'Service worker is not registered');
        this.recordTest('service-worker-activation', 'skipped', 'Service worker is not registered');
      }
    } catch (error) {
      this.recordTest('service-worker-registration', 'failed', `Error testing service worker: ${error.message}`);
    }
  }
  
  /**
   * Test caching capabilities
   * @returns {Promise<void>}
   */
  async testCaching() {
    this.log('info', 'Testing caching capabilities...');
    
    // Skip if not in browser environment
    if (this.config.testEnvironment !== 'browser') {
      this.recordTest('cache-api-support', 'skipped', 'Cache tests can only run in browser environment');
      this.recordTest('static-resources-cached', 'skipped', 'Cache tests can only run in browser environment');
      return;
    }
    
    // Test cache API support
    try {
      if ('caches' in window) {
        this.recordTest('cache-api-support', 'passed', 'Cache API is supported');
        
        // Test if static resources are cached
        const cacheNames = await caches.keys();
        
        if (cacheNames.length > 0) {
          this.recordTest('cache-exists', 'passed', `Found ${cacheNames.length} caches: ${cacheNames.join(', ')}`);
          
          // Check for static cache
          const staticCacheName = cacheNames.find(name => name.includes('static'));
          
          if (staticCacheName) {
            const staticCache = await caches.open(staticCacheName);
            const cachedResources = await staticCache.keys();
            
            if (cachedResources.length > 0) {
              this.recordTest('static-resources-cached', 'passed', `Found ${cachedResources.length} cached static resources`);
            } else {
              this.recordTest('static-resources-cached', 'failed', 'Static cache exists but contains no resources');
            }
          } else {
            this.recordTest('static-resources-cached', 'failed', 'No static cache found');
          }
        } else {
          this.recordTest('cache-exists', 'failed', 'No caches found');
          this.recordTest('static-resources-cached', 'skipped', 'No caches found');
        }
      } else {
        this.recordTest('cache-api-support', 'failed', 'Cache API is not supported');
        this.recordTest('static-resources-cached', 'skipped', 'Cache API is not supported');
      }
    } catch (error) {
      this.recordTest('cache-api-support', 'failed', `Error testing cache API: ${error.message}`);
    }
  }
  
  /**
   * Test offline support
   * @returns {Promise<void>}
   */
  async testOfflineSupport() {
    this.log('info', 'Testing offline support...');
    
    // Skip if not in browser environment
    if (this.config.testEnvironment !== 'browser') {
      this.recordTest('offline-page-available', 'skipped', 'Offline tests can only run in browser environment');
      return;
    }
    
    // Test if offline page is available
    try {
      const cache = await caches.open('care-mate-static-v1');
      const offlineResponse = await cache.match('/offline.html');
      
      if (offlineResponse) {
        this.recordTest('offline-page-available', 'passed', 'Offline page is cached');
      } else {
        this.recordTest('offline-page-available', 'failed', 'Offline page is not cached');
      }
    } catch (error) {
      this.recordTest('offline-page-available', 'failed', `Error testing offline page: ${error.message}`);
    }
    
    // Test if app shell is cached
    try {
      const cache = await caches.open('care-mate-static-v1');
      const shellResources = [
        '/',
        '/index.html',
        '/css/styles.css',
        '/js/main.js'
      ];
      
      const results = await Promise.all(
        shellResources.map(async resource => {
          const response = await cache.match(resource);
          return { resource, cached: !!response };
        })
      );
      
      const allCached = results.every(result => result.cached);
      const cachedCount = results.filter(result => result.cached).length;
      
      if (allCached) {
        this.recordTest('app-shell-cached', 'passed', 'All app shell resources are cached');
      } else {
        this.recordTest('app-shell-cached', 'failed', `Only ${cachedCount}/${shellResources.length} app shell resources are cached`);
      }
    } catch (error) {
      this.recordTest('app-shell-cached', 'failed', `Error testing app shell cache: ${error.message}`);
    }
  }
  
  /**
   * Test background sync capabilities
   * @returns {Promise<void>}
   */
  async testBackgroundSync() {
    this.log('info', 'Testing background sync...');
    
    // Skip if not in browser environment
    if (this.config.testEnvironment !== 'browser') {
      this.recordTest('background-sync-support', 'skipped', 'Background sync tests can only run in browser environment');
      return;
    }
    
    // Test background sync support
    try {
      if ('serviceWorker' in navigator && 'SyncManager' in window) {
        this.recordTest('background-sync-support', 'passed', 'Background sync is supported');
        
        // Test background sync registration
        try {
          const registration = await navigator.serviceWorker.ready;
          await registration.sync.register('test-sync');
          this.recordTest('background-sync-registration', 'passed', 'Background sync registration successful');
        } catch (error) {
          this.recordTest('background-sync-registration', 'failed', `Background sync registration failed: ${error.message}`);
        }
      } else {
        this.recordTest('background-sync-support', 'failed', 'Background sync is not supported');
        this.recordTest('background-sync-registration', 'skipped', 'Background sync is not supported');
      }
    } catch (error) {
      this.recordTest('background-sync-support', 'failed', `Error testing background sync: ${error.message}`);
    }
  }
  
  /**
   * Test push notification capabilities
   * @returns {Promise<void>}
   */
  async testPushNotifications() {
    this.log('info', 'Testing push notifications...');
    
    // Skip if not in browser environment
    if (this.config.testEnvironment !== 'browser') {
      this.recordTest('push-api-support', 'skipped', 'Push notification tests can only run in browser environment');
      return;
    }
    
    // Test push API support
    try {
      if ('serviceWorker' in navigator && 'PushManager' in window) {
        this.recordTest('push-api-support', 'passed', 'Push API is supported');
        
        // Check notification permission
        const permission = Notification.permission;
        
        if (permission === 'granted') {
          this.recordTest('notification-permission', 'passed', 'Notification permission is granted');
        } else if (permission === 'denied') {
          this.recordTest('notification-permission', 'failed', 'Notification permission is denied');
        } else {
          this.recordTest('notification-permission', 'skipped', 'Notification permission is not determined');
        }
      } else {
        this.recordTest('push-api-support', 'failed', 'Push API is not supported');
        this.recordTest('notification-permission', 'skipped', 'Push API is not supported');
      }
    } catch (error) {
      this.recordTest('push-api-support', 'failed', `Error testing push API: ${error.message}`);
    }
  }
  
  /**
   * Test installability
   * @returns {Promise<void>}
   */
  async testInstallability() {
    this.log('info', 'Testing installability...');
    
    // Skip if not in browser environment
    if (this.config.testEnvironment !== 'browser') {
      this.recordTest('manifest-available', 'skipped', 'Installability tests can only run in browser environment');
      return;
    }
    
    // Test web app manifest
    try {
      const manifestLinks = document.querySelectorAll('link[rel="manifest"]');
      
      if (manifestLinks.length > 0) {
        this.recordTest('manifest-available', 'passed', 'Web app manifest is linked');
        
        // Fetch and validate manifest
        try {
          const manifestUrl = manifestLinks[0].href;
          const response = await fetch(manifestUrl);
          
          if (response.ok) {
            const manifest = await response.json();
            
            // Check required fields
            const requiredFields = ['name', 'short_name', 'icons', 'start_url', 'display'];
            const missingFields = requiredFields.filter(field => !(field in manifest));
            
            if (missingFields.length === 0) {
              this.recordTest('manifest-valid', 'passed', 'Web app manifest contains all required fields');
            } else {
              this.recordTest('manifest-valid', 'failed', `Web app manifest is missing required fields: ${missingFields.join(', ')}`);
            }
            
            // Check icons
            if (manifest.icons && Array.isArray(manifest.icons)) {
              const hasSufficientIcons = manifest.icons.some(icon => 
                icon.sizes && (icon.sizes.includes('192x192') || icon.sizes.includes('512x512'))
              );
              
              if (hasSufficientIcons) {
                this.recordTest('manifest-icons', 'passed', 'Web app manifest has sufficient icons');
              } else {
                this.recordTest('manifest-icons', 'failed', 'Web app manifest does not have sufficient icons (192x192 or 512x512)');
              }
            } else {
              this.recordTest('manifest-icons', 'failed', 'Web app manifest does not have icons array');
            }
          } else {
            this.recordTest('manifest-valid', 'failed', `Failed to fetch manifest: ${response.status} ${response.statusText}`);
          }
        } catch (error) {
          this.recordTest('manifest-valid', 'failed', `Error validating manifest: ${error.message}`);
        }
      } else {
        this.recordTest('manifest-available', 'failed', 'Web app manifest is not linked');
        this.recordTest('manifest-valid', 'skipped', 'Web app manifest is not linked');
        this.recordTest('manifest-icons', 'skipped', 'Web app manifest is not linked');
      }
    } catch (error) {
      this.recordTest('manifest-available', 'failed', `Error testing manifest: ${error.message}`);
    }
    
    // Test installability criteria
    try {
      if ('serviceWorker' in navigator && 'PushManager' in window) {
        // Check if app is already installed
        const isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                            (window.navigator.standalone === true);
        
        if (isStandalone) {
          this.recordTest('app-installed', 'passed', 'App is already installed');
        } else {
          this.recordTest('app-installed', 'skipped', 'App is not installed');
        }
      } else {
        this.recordTest('app-installed', 'skipped', 'App cannot be installed (missing requirements)');
      }
    } catch (error) {
      this.recordTest('app-installed', 'failed', `Error testing installation: ${error.message}`);
    }
  }
  
  /**
   * Test accessibility of PWA features
   * @returns {Promise<void>}
   */
  async testAccessibility() {
    this.log('info', 'Testing accessibility...');
    
    // Skip if not in browser environment
    if (this.config.testEnvironment !== 'browser') {
      this.recordTest('offline-indicator', 'skipped', 'Accessibility tests can only run in browser environment');
      return;
    }
    
    // Test offline indicator
    try {
      const offlineIndicator = document.getElementById('network-status') || 
                              document.querySelector('.network-status') ||
                              document.querySelector('[aria-label*="network status"]');
      
      if (offlineIndicator) {
        const hasAriaLive = offlineIndicator.getAttribute('aria-live') === 'polite' || 
                           offlineIndicator.getAttribute('aria-live') === 'assertive';
        
        if (hasAriaLive) {
          this.recordTest('offline-indicator', 'passed', 'Offline indicator has proper ARIA attributes');
        } else {
          this.recordTest('offline-indicator', 'failed', 'Offline indicator does not have aria-live attribute');
        }
      } else {
        this.recordTest('offline-indicator', 'failed', 'No offline indicator found');
      }
    } catch (error) {
      this.recordTest('offline-indicator', 'failed', `Error testing offline indicator: ${error.message}`);
    }
    
    // Test install button
    try {
      const installButton = document.getElementById('app-install-button') || 
                           document.querySelector('[aria-label*="install"]');
      
      if (installButton) {
        const hasAccessibleName = installButton.textContent || 
                                 installButton.getAttribute('aria-label') || 
                                 installButton.getAttribute('title');
        
        if (hasAccessibleName) {
          this.recordTest('install-button', 'passed', 'Install button has accessible name');
        } else {
          this.recordTest('install-button', 'failed', 'Install button does not have accessible name');
        }
      } else {
        this.recordTest('install-button', 'skipped', 'No install button found');
      }
    } catch (error) {
      this.recordTest('install-button', 'failed', `Error testing install button: ${error.message}`);
    }
  }
  
  /**
   * Record a test result
   * @param {string} name - Test name
   * @param {string} status - Test status ('passed', 'failed', 'skipped')
   * @param {string} message - Test message
   */
  recordTest(name, status, message = '') {
    this.results.total++;
    
    if (status === 'passed') {
      this.results.passed++;
      this.log('info', `✓ PASS: ${name}${message ? ' - ' + message : ''}`);
    } else if (status === 'failed') {
      this.results.failed++;
      this.log('error', `✗ FAIL: ${name}${message ? ' - ' + message : ''}`);
    } else if (status === 'skipped') {
      this.results.skipped++;
      this.log('warn', `○ SKIP: ${name}${message ? ' - ' + message : ''}`);
    }
    
    this.results.tests.push({
      name,
      status,
      message,
      timestamp: Date.now()
    });
  }
  
  /**
   * Generate a test report
   * @param {string} format - Report format ('json', 'html', 'text')
   * @returns {string} Test report
   */
  generateReport(format = 'json') {
    if (format === 'json') {
      return JSON.stringify(this.results, null, 2);
    } else if (format === 'html') {
      return this.generateHtmlReport();
    } else {
      return this.generateTextReport();
    }
  }
  
  /**
   * Generate an HTML test report
   * @returns {string} HTML report
   */
  generateHtmlReport() {
    const passRate = this.results.total > 0 ? 
      Math.round((this.results.passed / this.results.total) * 100) : 0;
    
    let html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PWA Test Report</title>
        <style>
          body { font-family: system-ui, -apple-system, sans-serif; line-height: 1.5; max-width: 800px; margin: 0 auto; padding: 20px; }
          h1 { color: #333; }
          .summary { display: flex; gap: 20px; margin-bottom: 20px; }
          .summary-item { padding: 15px; border-radius: 5px; flex: 1; }
          .passed { background-color: #d4edda; color: #155724; }
          .failed { background-color: #f8d7da; color: #721c24; }
          .skipped { background-color: #fff3cd; color: #856404; }
          .test-list { list-style: none; padding: 0; }
          .test-item { padding: 10px; margin-bottom: 10px; border-radius: 5px; }
          .test-passed { background-color: #d4edda; }
          .test-failed { background-color: #f8d7da; }
          .test-skipped { background-color: #fff3cd; }
          .progress-bar { height: 20px; background-color: #e9ecef; border-radius: 5px; margin-bottom: 20px; overflow: hidden; }
          .progress-bar-inner { height: 100%; background-color: #28a745; width: ${passRate}%; }
        </style>
      </head>
      <body>
        <h1>PWA Test Report</h1>
        <p>Generated on ${new Date(this.results.endTime).toLocaleString()}</p>
        <p>Duration: ${(this.results.duration / 1000).toFixed(2)} seconds</p>
        
        <div class="progress-bar">
          <div class="progress-bar-inner"></div>
        </div>
        
        <div class="summary">
          <div class="summary-item passed">
            <h2>Passed</h2>
            <p>${this.results.passed} tests (${passRate}%)</p>
          </div>
          <div class="summary-item failed">
            <h2>Failed</h2>
            <p>${this.results.failed} tests</p>
          </div>
          <div class="summary-item skipped">
            <h2>Skipped</h2>
            <p>${this.results.skipped} tests</p>
          </div>
        </div>
        
        <h2>Test Results</h2>
        <ul class="test-list">
    `;
    
    // Group tests by category
    const categories = {};
    
    this.results.tests.forEach(test => {
      const category = test.name.split('-')[0];
      
      if (!categories[category]) {
        categories[category] = [];
      }
      
      categories[category].push(test);
    });
    
    // Add tests by category
    Object.entries(categories).forEach(([category, tests]) => {
      html += `<h3>${this.formatCategoryName(category)}</h3>`;
      
      tests.forEach(test => {
        const statusClass = `test-${test.status}`;
        const statusIcon = test.status === 'passed' ? '✓' : (test.status === 'failed' ? '✗' : '○');
        
        html += `
          <li class="test-item ${statusClass}">
            <strong>${statusIcon} ${this.formatTestName(test.name)}</strong>
            ${test.message ? `<p>${test.message}</p>` : ''}
          </li>
        `;
      });
    });
    
    html += `
        </ul>
      </body>
      </html>
    `;
    
    return html;
  }
  
  /**
   * Generate a text test report
   * @returns {string} Text report
   */
  generateTextReport() {
    const passRate = this.results.total > 0 ? 
      Math.round((this.results.passed / this.results.total) * 100) : 0;
    
    let text = `
PWA Test Report
==============

Generated on ${new Date(this.results.endTime).toLocaleString()}
Duration: ${(this.results.duration / 1000).toFixed(2)} seconds

Summary
-------
Passed: ${this.results.passed} tests (${passRate}%)
Failed: ${this.results.failed} tests
Skipped: ${this.results.skipped} tests

Test Results
-----------
`;
    
    // Group tests by category
    const categories = {};
    
    this.results.tests.forEach(test => {
      const category = test.name.split('-')[0];
      
      if (!categories[category]) {
        categories[category] = [];
      }
      
      categories[category].push(test);
    });
    
    // Add tests by category
    Object.entries(categories).forEach(([category, tests]) => {
      text += `\n${this.formatCategoryName(category)}\n${'-'.repeat(this.formatCategoryName(category).length)}\n`;
      
      tests.forEach(test => {
        const statusIcon = test.status === 'passed' ? '✓' : (test.status === 'failed' ? '✗' : '○');
        
        text += `${statusIcon} ${this.formatTestName(test.name)}${test.message ? `: ${test.message}` : ''}\n`;
      });
    });
    
    return text;
  }
  
  /**
   * Format a test name for display
   * @param {string} name - Test name
   * @returns {string} Formatted test name
   */
  formatTestName(name) {
    return name
      .split('-')
      .slice(1)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }
  
  /**
   * Format a category name for display
   * @param {string} category - Category name
   * @returns {string} Formatted category name
   */
  formatCategoryName(category) {
    return category.charAt(0).toUpperCase() + category.slice(1);
  }
  
  /**
   * Log a message
   * @param {string} level - Log level
   * @param {string} message - Log message
   * @param {*} data - Additional data
   */
  log(level, message, data) {
    const logLevels = {
      debug: 0,
      info: 1,
      warn: 2,
      error: 3
    };
    
    if (logLevels[level] >= logLevels[this.config.logLevel]) {
      if (data) {
        console[level](message, data);
      } else {
        console[level](message);
      }
    }
  }
}

// Export the PWATestFramework class
export default PWATestFramework;
