/**
 * Care Mate - Enhanced PWA Features
 * 
 * This module extends the existing PWA capabilities with improved offline support,
 * more robust background sync, and enhanced push notifications.
 */

import pwaIntegration from './index.js';

/**
 * Enhanced offline experience with intelligent content caching
 */
class EnhancedOfflineExperience {
  constructor() {
    this.cacheName = 'care-mate-dynamic-v1';
    this.urlsToCache = [
      '/',
      '/index.html',
      '/chat.html',
      '/documents.html',
      '/offline.html',
      '/css/styles.css',
      '/css/accessibility.css',
      '/js/main.js',
      '/js/accessibility.js',
      '/assets/placeholder-hero.png'
    ];
    
    // Bind methods
    this.init = this.init.bind(this);
    this.precacheEssentialResources = this.precacheEssentialResources.bind(this);
    this.setupDynamicCaching = this.setupDynamicCaching.bind(this);
    this.setupPeriodicSync = this.setupPeriodicSync.bind(this);
  }
  
  /**
   * Initialize enhanced offline experience
   */
  async init() {
    if ('serviceWorker' in navigator) {
      try {
        // Register the service worker
        const registration = await navigator.serviceWorker.register('/service-worker.js');
        console.log('[PWA Enhanced] ServiceWorker registered with scope:', registration.scope);
        
        // Precache essential resources
        await this.precacheEssentialResources();
        
        // Setup dynamic caching
        this.setupDynamicCaching();
        
        // Setup periodic sync if supported
        this.setupPeriodicSync(registration);
        
        return true;
      } catch (error) {
        console.error('[PWA Enhanced] ServiceWorker registration failed:', error);
        return false;
      }
    } else {
      console.warn('[PWA Enhanced] ServiceWorker is not supported');
      return false;
    }
  }
  
  /**
   * Precache essential resources for offline use
   */
  async precacheEssentialResources() {
    try {
      const cache = await caches.open(this.cacheName);
      console.log('[PWA Enhanced] Precaching essential resources');
      await cache.addAll(this.urlsToCache);
    } catch (error) {
      console.error('[PWA Enhanced] Precaching failed:', error);
    }
  }
  
  /**
   * Setup dynamic caching for API responses and user-specific content
   */
  setupDynamicCaching() {
    // This will be handled by the service worker
    // We're just setting up the configuration here
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'CONFIGURE_DYNAMIC_CACHING',
        config: {
          cacheName: this.cacheName,
          apiCacheDuration: 60 * 60 * 1000, // 1 hour
          staticCacheDuration: 7 * 24 * 60 * 60 * 1000, // 1 week
          maxEntries: 100
        }
      });
    }
  }
  
  /**
   * Setup periodic sync for background data updates
   * @param {ServiceWorkerRegistration} registration - Service worker registration
   */
  async setupPeriodicSync(registration) {
    if ('periodicSync' in registration) {
      try {
        // Check permission
        const status = await navigator.permissions.query({
          name: 'periodic-background-sync'
        });
        
        if (status.state === 'granted') {
          // Register periodic sync
          await registration.periodicSync.register('ndis-updates', {
            minInterval: 24 * 60 * 60 * 1000 // 24 hours
          });
          
          console.log('[PWA Enhanced] Periodic sync registered');
        } else {
          console.log('[PWA Enhanced] Periodic sync permission not granted');
        }
      } catch (error) {
        console.error('[PWA Enhanced] Periodic sync registration failed:', error);
      }
    } else {
      console.log('[PWA Enhanced] Periodic sync not supported');
    }
  }
  
  /**
   * Manually trigger a content update
   */
  async updateContent() {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'UPDATE_CONTENT'
      });
      
      return true;
    }
    
    return false;
  }
  
  /**
   * Check if content is available offline
   * @param {string} url - URL to check
   * @returns {Promise<boolean>} Whether the content is available offline
   */
  async isContentAvailableOffline(url) {
    try {
      const cache = await caches.open(this.cacheName);
      const response = await cache.match(url);
      return !!response;
    } catch (error) {
      console.error('[PWA Enhanced] Cache check failed:', error);
      return false;
    }
  }
}

/**
 * Enhanced background sync with retry strategies and conflict resolution
 */
class EnhancedBackgroundSync {
  constructor() {
    this.syncTag = 'care-mate-sync';
    this.maxRetries = 5;
    this.retryDelays = [
      1000,  // 1 second
      5000,  // 5 seconds
      30000, // 30 seconds
      300000 // 5 minutes
    ];
    
    // Bind methods
    this.init = this.init.bind(this);
    this.registerSyncEvent = this.registerSyncEvent.bind(this);
    this.queueAction = this.queueAction.bind(this);
  }
  
  /**
   * Initialize enhanced background sync
   */
  async init() {
    if ('serviceWorker' in navigator && 'SyncManager' in window) {
      try {
        const registration = await navigator.serviceWorker.ready;
        console.log('[PWA Enhanced] Background sync ready');
        return true;
      } catch (error) {
        console.error('[PWA Enhanced] Background sync initialization failed:', error);
        return false;
      }
    } else {
      console.warn('[PWA Enhanced] Background sync is not supported');
      return false;
    }
  }
  
  /**
   * Register a sync event
   * @returns {Promise<boolean>} Whether registration was successful
   */
  async registerSyncEvent() {
    if ('serviceWorker' in navigator && 'SyncManager' in window) {
      try {
        const registration = await navigator.serviceWorker.ready;
        await registration.sync.register(this.syncTag);
        console.log('[PWA Enhanced] Sync event registered');
        return true;
      } catch (error) {
        console.error('[PWA Enhanced] Sync registration failed:', error);
        return false;
      }
    }
    
    return false;
  }
  
  /**
   * Queue an action for background sync
   * @param {string} action - Action type
   * @param {Object} data - Action data
   * @returns {Promise<string|null>} ID of the queued action or null if not queued
   */
  async queueAction(action, data) {
    if (!('serviceWorker' in navigator) || !('SyncManager' in window)) {
      console.warn('[PWA Enhanced] Background sync not supported, executing immediately');
      
      // Try to execute immediately
      try {
        // This would normally be handled by the service worker
        // For now, we'll just log it
        console.log('[PWA Enhanced] Executing action immediately:', action, data);
        return 'immediate-execution';
      } catch (error) {
        console.error('[PWA Enhanced] Immediate execution failed:', error);
        return null;
      }
    }
    
    try {
      // Generate a unique ID for this action
      const actionId = `${action}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      // Store the action in IndexedDB for the service worker to process
      const db = await this.openDatabase();
      const tx = db.transaction('sync-store', 'readwrite');
      const store = tx.objectStore('sync-store');
      
      await store.put({
        id: actionId,
        action,
        data,
        timestamp: Date.now(),
        retries: 0,
        status: 'pending'
      });
      
      // Register sync event
      await this.registerSyncEvent();
      
      console.log('[PWA Enhanced] Action queued for background sync:', actionId);
      return actionId;
    } catch (error) {
      console.error('[PWA Enhanced] Failed to queue action:', error);
      return null;
    }
  }
  
  /**
   * Open the IndexedDB database
   * @returns {Promise<IDBDatabase>} IndexedDB database
   */
  openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('care-mate-sync-db', 1);
      
      request.onerror = event => {
        reject(new Error('Failed to open database'));
      };
      
      request.onsuccess = event => {
        resolve(event.target.result);
      };
      
      request.onupgradeneeded = event => {
        const db = event.target.result;
        
        // Create object store for sync actions
        if (!db.objectStoreNames.contains('sync-store')) {
          const store = db.createObjectStore('sync-store', { keyPath: 'id' });
          store.createIndex('status', 'status', { unique: false });
          store.createIndex('timestamp', 'timestamp', { unique: false });
        }
      };
    });
  }
  
  /**
   * Check the status of a queued action
   * @param {string} actionId - ID of the queued action
   * @returns {Promise<Object|null>} Action status or null if not found
   */
  async checkActionStatus(actionId) {
    try {
      const db = await this.openDatabase();
      const tx = db.transaction('sync-store', 'readonly');
      const store = tx.objectStore('sync-store');
      
      return new Promise((resolve, reject) => {
        const request = store.get(actionId);
        
        request.onerror = event => {
          reject(new Error('Failed to get action status'));
        };
        
        request.onsuccess = event => {
          resolve(request.result || null);
        };
      });
    } catch (error) {
      console.error('[PWA Enhanced] Failed to check action status:', error);
      return null;
    }
  }
}

/**
 * Enhanced push notifications with rich content and user preferences
 */
class EnhancedPushNotifications {
  constructor() {
    this.vapidPublicKey = 'BLBx-hf5h3ZgFpQFq7n7xHOQQN_-Xn3tnFQBx9PrLVr4Iy7pwmLbQwQQHXjHQlH7gxHPnOBuIWbNXEQTmC-SZF4';
    this.notificationPermission = null;
    
    // User preferences
    this.preferences = {
      enabled: true,
      planUpdates: true,
      appointmentReminders: true,
      budgetAlerts: true,
      quietHours: {
        enabled: false,
        start: '22:00',
        end: '08:00'
      }
    };
    
    // Bind methods
    this.init = this.init.bind(this);
    this.checkPermission = this.checkPermission.bind(this);
    this.requestPermission = this.requestPermission.bind(this);
    this.subscribe = this.subscribe.bind(this);
    this.unsubscribe = this.unsubscribe.bind(this);
    this.updatePreferences = this.updatePreferences.bind(this);
    this.showNotification = this.showNotification.bind(this);
  }
  
  /**
   * Initialize enhanced push notifications
   */
  async init() {
    // Load preferences from localStorage
    this.loadPreferences();
    
    // Check permission
    this.notificationPermission = await this.checkPermission();
    
    if ('serviceWorker' in navigator && 'PushManager' in window) {
      try {
        const registration = await navigator.serviceWorker.ready;
        console.log('[PWA Enhanced] Push notifications ready');
        
        // Check if already subscribed
        const subscription = await registration.pushManager.getSubscription();
        
        if (subscription) {
          console.log('[PWA Enhanced] Already subscribed to push notifications');
        }
        
        return true;
      } catch (error) {
        console.error('[PWA Enhanced] Push notifications initialization failed:', error);
        return false;
      }
    } else {
      console.warn('[PWA Enhanced] Push notifications are not supported');
      return false;
    }
  }
  
  /**
   * Load notification preferences from localStorage
   */
  loadPreferences() {
    try {
      const savedPreferences = localStorage.getItem('care-mate-notification-preferences');
      
      if (savedPreferences) {
        this.preferences = {
          ...this.preferences,
          ...JSON.parse(savedPreferences)
        };
      }
    } catch (error) {
      console.error('[PWA Enhanced] Failed to load notification preferences:', error);
    }
  }
  
  /**
   * Save notification preferences to localStorage
   */
  savePreferences() {
    try {
      localStorage.setItem('care-mate-notification-preferences', JSON.stringify(this.preferences));
    } catch (error) {
      console.error('[PWA Enhanced] Failed to save notification preferences:', error);
    }
  }
  
  /**
   * Check notification permission
   * @returns {Promise<string>} Permission status
   */
  async checkPermission() {
    if (!('Notification' in window)) {
      return 'unsupported';
    }
    
    return Notification.permission;
  }
  
  /**
   * Request notification permission
   * @returns {Promise<boolean>} Whether permission was granted
   */
  async requestPermission() {
    if (!('Notification' in window)) {
      return false;
    }
    
    try {
      const permission = await Notification.requestPermission();
      this.notificationPermission = permission;
      return permission === 'granted';
    } catch (error) {
      console.error('[PWA Enhanced] Failed to request notification permission:', error);
      return false;
    }
  }
  
  /**
   * Subscribe to push notifications
   * @returns {Promise<boolean>} Whether subscription was successful
   */
  async subscribe() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      return false;
    }
    
    // Check permission
    if (this.notificationPermission !== 'granted') {
      const granted = await this.requestPermission();
      
      if (!granted) {
        return false;
      }
    }
    
    try {
      const registration = await navigator.serviceWorker.ready;
      
      // Convert VAPID key to Uint8Array
      const applicationServerKey = this.urlBase64ToUint8Array(this.vapidPublicKey);
      
      // Subscribe
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey
      });
      
      // Send subscription to server
      // This would normally be sent to your backend
      console.log('[PWA Enhanced] Push subscription:', subscription);
      
      // Update preferences
      this.preferences.enabled = true;
      this.savePreferences();
      
      return true;
    } catch (error) {
      console.error('[PWA Enhanced] Push subscription failed:', error);
      return false;
    }
  }
  
  /**
   * Unsubscribe from push notifications
   * @returns {Promise<boolean>} Whether unsubscription was successful
   */
  async unsubscribe() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      return false;
    }
    
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      
      if (subscription) {
        await subscription.unsubscribe();
        
        // Update preferences
        this.preferences.enabled = false;
        this.savePreferences();
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('[PWA Enhanced] Push unsubscription failed:', error);
      return false;
    }
  }
  
  /**
   * Update notification preferences
   * @param {Object} preferences - New preferences
   * @returns {boolean} Whether update was successful
   */
  updatePreferences(preferences) {
    try {
      this.preferences = {
        ...this.preferences,
        ...preferences
      };
      
      this.savePreferences();
      return true;
    } catch (error) {
      console.error('[PWA Enhanced] Failed to update notification preferences:', error);
      return false;
    }
  }
  
  /**
   * Show a notification
   * @param {string} title - Notification title
   * @param {Object} options - Notification options
   * @returns {Promise<boolean>} Whether notification was shown
   */
  async showNotification(title, options = {}) {
    if (!('Notification' in window)) {
      return false;
    }
    
    // Check if notifications are enabled in user preferences
    if (!this.preferences.enabled) {
      console.log('[PWA Enhanced] Notifications are disabled in user preferences');
      return false;
    }
    
    // Check if in quiet hours
    if (this.isInQuietHours()) {
      console.log('[PWA Enhanced] In quiet hours, notification suppressed');
      return false;
    }
    
    // Check permission
    if (this.notificationPermission !== 'granted') {
      const granted = await this.requestPermission();
      
      if (!granted) {
        return false;
      }
    }
    
    try {
      // If we have a service worker, use it to show the notification
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        await registration.showNotification(title, options);
      } else {
        // Fallback to regular Notification API
        new Notification(title, options);
      }
      
      return true;
    } catch (error) {
      console.error('[PWA Enhanced] Failed to show notification:', error);
      return false;
    }
  }
  
  /**
   * Check if current time is within quiet hours
   * @returns {boolean} Whether current time is within quiet hours
   */
  isInQuietHours() {
    if (!this.preferences.quietHours.enabled) {
      return false;
    }
    
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    const [startHour, startMinute] = this.preferences.quietHours.start.split(':').map(Number);
    const [endHour, endMinute] = this.preferences.quietHours.end.split(':').map(Number);
    
    const currentTime = currentHour * 60 + currentMinute;
    const startTime = startHour * 60 + startMinute;
    const endTime = endHour * 60 + endMinute;
    
    // Handle case where quiet hours span midnight
    if (startTime > endTime) {
      return currentTime >= startTime || currentTime < endTime;
    } else {
      return currentTime >= startTime && currentTime < endTime;
    }
  }
  
  /**
   * Convert URL-safe base64 to Uint8Array
   * @param {string} base64String - Base64 string
   * @returns {Uint8Array} Uint8Array
   */
  urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');
    
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    
    return outputArray;
  }
}

// Create and export enhanced PWA features
const enhancedOfflineExperience = new EnhancedOfflineExperience();
const enhancedBackgroundSync = new EnhancedBackgroundSync();
const enhancedPushNotifications = new EnhancedPushNotifications();

// Export enhanced PWA features
export {
  enhancedOfflineExperience,
  enhancedBackgroundSync,
  enhancedPushNotifications
};

// Initialize enhanced PWA features
export const initEnhancedPwaFeatures = async () => {
  const results = await Promise.all([
    enhancedOfflineExperience.init(),
    enhancedBackgroundSync.init(),
    enhancedPushNotifications.init()
  ]);
  
  return results.every(result => result);
};

// Default export for easy importing
export default {
  offlineExperience: enhancedOfflineExperience,
  backgroundSync: enhancedBackgroundSync,
  pushNotifications: enhancedPushNotifications,
  init: initEnhancedPwaFeatures
};
