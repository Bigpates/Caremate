/**
 * Care Mate - Enhanced Push Notification Manager
 * 
 * This module extends the existing push notification functionality with
 * rich notifications, user preference management, and intelligent delivery timing.
 */

class EnhancedPushNotificationManager {
  constructor(options = {}) {
    // Default configuration
    this.config = {
      vapidPublicKey: 'BLGrxQGXHCPBX9Lv4K0wsA8ySuRTBRYJkMZQBp9KQPjnIm9vJQJiTsLKj_SYB_K1vqNzYk7pG6Dz7ozX3iG0XDk',
      apiEndpoint: '/api/notifications',
      defaultIcon: '/assets/icons/icon-192x192.png',
      defaultBadge: '/assets/icons/badge-96x96.png',
      notificationCategories: [
        'plan_updates',
        'appointments',
        'messages',
        'budget_alerts',
        'system'
      ],
      ...options
    };

    // State
    this.subscription = null;
    this.permissionStatus = null;
    this.isSubscribed = false;
    this.initialized = false;
    
    // User preferences
    this.userPreferences = {
      enabled: true,
      categories: {
        plan_updates: true,
        appointments: true,
        messages: true,
        budget_alerts: true,
        system: true
      },
      quietHours: {
        enabled: false,
        start: '22:00',
        end: '08:00',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
      },
      deliveryOptions: {
        groupSimilar: true,
        maxPerHour: 5,
        vibrateOnMobile: true
      }
    };

    // Bind methods
    this.init = this.init.bind(this);
    this.checkPermission = this.checkPermission.bind(this);
    this.requestPermission = this.requestPermission.bind(this);
    this.subscribe = this.subscribe.bind(this);
    this.unsubscribe = this.unsubscribe.bind(this);
    this.updateSubscriptionOnServer = this.updateSubscriptionOnServer.bind(this);
    this.showNotification = this.showNotification.bind(this);
    this.loadUserPreferences = this.loadUserPreferences.bind(this);
    this.saveUserPreferences = this.saveUserPreferences.bind(this);
    this.updateUserPreferences = this.updateUserPreferences.bind(this);
    this.setupUI = this.setupUI.bind(this);
  }

  /**
   * Initialize the enhanced push notification manager
   * @returns {Promise<boolean>} Whether initialization was successful
   */
  async init() {
    if (this.initialized) {
      return true;
    }

    try {
      // Check if push notifications are supported
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
        console.warn('[EnhancedPush] Push notifications not supported');
        return false;
      }

      // Load user preferences
      this.loadUserPreferences();

      // Check permission status
      this.permissionStatus = await this.checkPermission();
      
      // Register service worker if not already registered
      const registration = await this.registerServiceWorker();
      
      // Check subscription status
      await this.checkSubscription(registration);
      
      // Set up UI
      this.setupUI();
      
      // Set up event listeners
      this.setupEventListeners();
      
      this.initialized = true;
      console.log('[EnhancedPush] Initialized successfully');
      return true;
    } catch (error) {
      console.error('[EnhancedPush] Initialization failed:', error);
      return false;
    }
  }

  /**
   * Register the service worker
   * @returns {Promise<ServiceWorkerRegistration>} Service worker registration
   */
  async registerServiceWorker() {
    try {
      return await navigator.serviceWorker.register('/enhanced-service-worker.js');
    } catch (error) {
      console.error('[EnhancedPush] Service Worker registration failed:', error);
      throw error;
    }
  }

  /**
   * Check notification permission
   * @returns {Promise<string>} Permission status ('granted', 'denied', or 'default')
   */
  async checkPermission() {
    if (!('Notification' in window)) {
      return 'unsupported';
    }
    
    return Notification.permission;
  }

  /**
   * Request notification permission
   * @returns {Promise<boolean>} Whether permission was granted
   */
  async requestPermission() {
    if (!('Notification' in window)) {
      return false;
    }
    
    try {
      const permission = await Notification.requestPermission();
      this.permissionStatus = permission;
      
      // Update UI based on permission
      this.updateUI();
      
      return permission === 'granted';
    } catch (error) {
      console.error('[EnhancedPush] Failed to request permission:', error);
      return false;
    }
  }

  /**
   * Check if the user is already subscribed to push notifications
   * @param {ServiceWorkerRegistration} registration - Service worker registration
   * @returns {Promise<boolean>} Whether the user is subscribed
   */
  async checkSubscription(registration) {
    try {
      const subscription = await registration.pushManager.getSubscription();
      this.isSubscribed = subscription !== null;
      this.subscription = subscription;
      
      console.log('[EnhancedPush] User is' + (this.isSubscribed ? '' : ' not') + ' subscribed');
      
      // Update UI based on subscription status
      this.updateUI();
      
      return this.isSubscribed;
    } catch (error) {
      console.error('[EnhancedPush] Error checking subscription:', error);
      return false;
    }
  }

  /**
   * Subscribe to push notifications
   * @returns {Promise<boolean>} Whether subscription was successful
   */
  async subscribe() {
    try {
      // Request notification permission if not already granted
      if (this.permissionStatus !== 'granted') {
        const granted = await this.requestPermission();
        
        if (!granted) {
          console.warn('[EnhancedPush] Permission not granted');
          return false;
        }
      }
      
      // Get service worker registration
      const registration = await navigator.serviceWorker.ready;
      
      // Convert the public key to Uint8Array
      const applicationServerKey = this.urlB64ToUint8Array(this.config.vapidPublicKey);
      
      // Subscribe to push notifications
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey
      });
      
      console.log('[EnhancedPush] User subscribed:', subscription);
      
      // Update subscription on server
      await this.updateSubscriptionOnServer(subscription);
      
      this.isSubscribed = true;
      this.subscription = subscription;
      
      // Update user preferences
      this.userPreferences.enabled = true;
      this.saveUserPreferences();
      
      // Update UI
      this.updateUI();
      
      // Show confirmation notification
      this.showNotification('Notifications Enabled', {
        body: 'You will now receive important updates about your NDIS plan and services.',
        icon: this.config.defaultIcon,
        badge: this.config.defaultBadge,
        tag: 'notification-confirmation',
        data: {
          category: 'system'
        }
      });
      
      return true;
    } catch (error) {
      console.error('[EnhancedPush] Failed to subscribe:', error);
      return false;
    }
  }

  /**
   * Unsubscribe from push notifications
   * @returns {Promise<boolean>} Whether unsubscription was successful
   */
  async unsubscribe() {
    try {
      // Get current subscription
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      
      if (!subscription) {
        console.warn('[EnhancedPush] No subscription to unsubscribe from');
        return false;
      }
      
      // Unsubscribe
      await subscription.unsubscribe();
      
      console.log('[EnhancedPush] User unsubscribed');
      
      // Update subscription on server
      await this.updateSubscriptionOnServer(null);
      
      this.isSubscribed = false;
      this.subscription = null;
      
      // Update user preferences
      this.userPreferences.enabled = false;
      this.saveUserPreferences();
      
      // Update UI
      this.updateUI();
      
      return true;
    } catch (error) {
      console.error('[EnhancedPush] Error unsubscribing:', error);
      return false;
    }
  }

  /**
   * Update subscription on server
   * @param {PushSubscription|null} subscription - Push subscription or null if unsubscribed
   * @returns {Promise<boolean>} Whether update was successful
   */
  async updateSubscriptionOnServer(subscription) {
    try {
      if (subscription) {
        // Send subscription to server
        await fetch(this.config.apiEndpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            subscription,
            preferences: this.userPreferences
          })
        });
      } else {
        // Remove subscription from server
        await fetch(this.config.apiEndpoint, {
          method: 'DELETE'
        });
      }
      
      console.log('[EnhancedPush] Subscription updated on server');
      return true;
    } catch (error) {
      console.error('[EnhancedPush] Failed to update subscription on server:', error);
      return false;
    }
  }

  /**
   * Show a notification
   * @param {string} title - Notification title
   * @param {Object} options - Notification options
   * @returns {Promise<boolean>} Whether notification was shown
   */
  async showNotification(title, options = {}) {
    try {
      // Check if notifications are enabled
      if (!this.userPreferences.enabled) {
        console.log('[EnhancedPush] Notifications are disabled by user preferences');
        return false;
      }
      
      // Check if this category is enabled
      const category = options.data?.category || 'system';
      if (!this.userPreferences.categories[category]) {
        console.log(`[EnhancedPush] Notifications for category '${category}' are disabled`);
        return false;
      }
      
      // Check if in quiet hours
      if (this.isInQuietHours()) {
        console.log('[EnhancedPush] In quiet hours, notification suppressed');
        return false;
      }
      
      // Set default options
      const notificationOptions = {
        icon: this.config.defaultIcon,
        badge: this.config.defaultBadge,
        vibrate: this.userPreferences.deliveryOptions.vibrateOnMobile ? [100, 50, 100] : undefined,
        ...options
      };
      
      // Show notification
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        await registration.showNotification(title, notificationOptions);
      } else {
        // Fallback to regular Notification API
        new Notification(title, notificationOptions);
      }
      
      console.log('[EnhancedPush] Notification shown:', title);
      return true;
    } catch (error) {
      console.error('[EnhancedPush] Failed to show notification:', error);
      return false;
    }
  }

  /**
   * Check if current time is within quiet hours
   * @returns {boolean} Whether current time is within quiet hours
   */
  isInQuietHours() {
    if (!this.userPreferences.quietHours.enabled) {
      return false;
    }
    
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    // Parse quiet hours
    const startParts = this.userPreferences.quietHours.start.split(':');
    const endParts = this.userPreferences.quietHours.end.split(':');
    
    const startHour = parseInt(startParts[0], 10);
    const startMinute = parseInt(startParts[1], 10);
    const endHour = parseInt(endParts[0], 10);
    const endMinute = parseInt(endParts[1], 10);
    
    // Convert to minutes for easier comparison
    const currentTimeInMinutes = (currentHour * 60) + currentMinute;
    const startTimeInMinutes = (startHour * 60) + startMinute;
    const endTimeInMinutes = (endHour * 60) + endMinute;
    
    // Check if current time is within quiet hours
    if (startTimeInMinutes < endTimeInMinutes) {
      // Simple case: start time is before end time (e.g., 22:00 to 08:00)
      return currentTimeInMinutes >= startTimeInMinutes && currentTimeInMinutes < endTimeInMinutes;
    } else {
      // Complex case: start time is after end time (e.g., 22:00 to 08:00 next day)
      return currentTimeInMinutes >= startTimeInMinutes || currentTimeInMinutes < endTimeInMinutes;
    }
  }

  /**
   * Load user preferences from localStorage
   */
  loadUserPreferences() {
    try {
      const prefsJson = localStorage.getItem('care-mate-notification-prefs');
      
      if (prefsJson) {
        const prefs = JSON.parse(prefsJson);
        this.userPreferences = {
          ...this.userPreferences,
          ...prefs
        };
        
        console.log('[EnhancedPush] Loaded user preferences');
      }
    } catch (error) {
      console.error('[EnhancedPush] Failed to load user preferences:', error);
    }
  }

  /**
   * Save user preferences to localStorage
   */
  saveUserPreferences() {
    try {
      localStorage.setItem('care-mate-notification-prefs', JSON.stringify(this.userPreferences));
      
      // Also update on server if subscribed
      if (this.isSubscribed && this.subscription) {
        this.updateSubscriptionOnServer(this.subscription);
      }
    } catch (error) {
      console.error('[EnhancedPush] Failed to save user preferences:', error);
    }
  }

  /**
   * Update user preferences
   * @param {Object} preferences - New preferences
   */
  updateUserPreferences(preferences) {
    this.userPreferences = {
      ...this.userPreferences,
      ...preferences
    };
    
    this.saveUserPreferences();
    console.log('[EnhancedPush] Updated user preferences');
    
    // Update UI
    this.updateUI();
  }

  /**
   * Set up UI elements for push notifications
   */
  setupUI() {
    // Create notification settings container if it doesn't exist
    let notificationSettings = document.getElementById('notification-settings');
    
    if (!notificationSettings) {
      notificationSettings = document.createElement('div');
      notificationSettings.id = 'notification-settings';
      notificationSettings.className = 'settings-section';
      
      const heading = document.createElement('h3');
      heading.textContent = 'Notification Settings';
      notificationSettings.appendChild(heading);
      
      // Add to settings container or create one
      let settingsContainer = document.querySelector('.settings-container');
      
      if (!settingsContainer) {
        settingsContainer = document.createElement('div');
        settingsContainer.className = 'settings-container';
        document.body.appendChild(settingsContainer);
      }
      
      settingsContainer.appendChild(notificationSettings);
    }
    
    // Clear existing content
    notificationSettings.innerHTML = '';
    
    // Add heading
    const heading = document.createElement('h3');
    heading.textContent = 'Notification Settings';
    notificationSettings.appendChild(heading);
    
    // Add main toggle
    const mainToggleContainer = document.createElement('div');
    mainToggleContainer.className = 'setting-item';
    
    const mainToggleLabel = document.createElement('label');
    mainToggleLabel.textContent = 'Enable Notifications';
    mainToggleLabel.setAttribute('for', 'notification-main-toggle');
    
    const mainToggle = document.createElement('input');
    mainToggle.type = 'checkbox';
    mainToggle.id = 'notification-main-toggle';
    mainToggle.checked = this.userPreferences.enabled;
    mainToggle.addEventListener('change', () => {
      if (mainToggle.checked) {
        this.subscribe();
      } else {
        this.unsubscribe();
      }
    });
    
    mainToggleContainer.appendChild(mainToggleLabel);
    mainToggleContainer.appendChild(mainToggle);
    notificationSettings.appendChild(mainToggleContainer);
    
    // Add category toggles
    const categoriesContainer = document.createElement('div');
    categoriesContainer.className = 'setting-group';
    categoriesContainer.style.display = this.userPreferences.enabled ? 'block' : 'none';
    
    const categoriesHeading = document.createElement('h4');
    categoriesHeading.textContent = 'Notification Categories';
    categoriesContainer.appendChild(categoriesHeading);
    
    // Add each category toggle
    for (const category of this.config.notificationCategories) {
      const categoryContainer = document.createElement('div');
      categoryContainer.className = 'setting-item';
      
      const categoryLabel = document.createElement('label');
      categoryLabel.textContent = this.getCategoryDisplayName(category);
      categoryLabel.setAttribute('for', `notification-category-${category}`);
      
      const categoryToggle = document.createElement('input');
      categoryToggle.type = 'checkbox';
      categoryToggle.id = `notification-category-${category}`;
      categoryToggle.checked = this.userPreferences.categories[category] !== false;
      categoryToggle.addEventListener('change', () => {
        this.userPreferences.categories[category] = categoryToggle.checked;
        this.saveUserPreferences();
      });
      
      categoryContainer.appendChild(categoryLabel);
      categoryContainer.appendChild(categoryToggle);
      categoriesContainer.appendChild(categoryContainer);
    }
    
    notificationSettings.appendChild(categoriesContainer);
    
    // Add quiet hours settings
    const quietHoursContainer = document.createElement('div');
    quietHoursContainer.className = 'setting-group';
    quietHoursContainer.style.display = this.userPreferences.enabled ? 'block' : 'none';
    
    const quietHoursHeading = document.createElement('h4');
    quietHoursHeading.textContent = 'Quiet Hours';
    quietHoursContainer.appendChild(quietHoursHeading);
    
    // Quiet hours toggle
    const quietHoursToggleContainer = document.createElement('div');
    quietHoursToggleContainer.className = 'setting-item';
    
    const quietHoursToggleLabel = document.createElement('label');
    quietHoursToggleLabel.textContent = 'Enable Quiet Hours';
    quietHoursToggleLabel.setAttribute('for', 'notification-quiet-hours-toggle');
    
    const quietHoursToggle = document.createElement('input');
    quietHoursToggle.type = 'checkbox';
    quietHoursToggle.id = 'notification-quiet-hours-toggle';
    quietHoursToggle.checked = this.userPreferences.quietHours.enabled;
    quietHoursToggle.addEventListener('change', () => {
      this.userPreferences.quietHours.enabled = quietHoursToggle.checked;
      this.saveUserPreferences();
      
      // Show/hide time settings
      quietHoursTimeContainer.style.display = quietHoursToggle.checked ? 'block' : 'none';
    });
    
    quietHoursToggleContainer.appendChild(quietHoursToggleLabel);
    quietHoursToggleContainer.appendChild(quietHoursToggle);
    quietHoursContainer.appendChild(quietHoursToggleContainer);
    
    // Quiet hours time settings
    const quietHoursTimeContainer = document.createElement('div');
    quietHoursTimeContainer.className = 'setting-group';
    quietHoursTimeContainer.style.display = this.userPreferences.quietHours.enabled ? 'block' : 'none';
    
    // Start time
    const startTimeContainer = document.createElement('div');
    startTimeContainer.className = 'setting-item';
    
    const startTimeLabel = document.createElement('label');
    startTimeLabel.textContent = 'Start Time';
    startTimeLabel.setAttribute('for', 'notification-quiet-hours-start');
    
    const startTimeInput = document.createElement('input');
    startTimeInput.type = 'time';
    startTimeInput.id = 'notification-quiet-hours-start';
    startTimeInput.value = this.userPreferences.quietHours.start;
    startTimeInput.addEventListener('change', () => {
      this.userPreferences.quietHours.start = startTimeInput.value;
      this.saveUserPreferences();
    });
    
    startTimeContainer.appendChild(startTimeLabel);
    startTimeContainer.appendChild(startTimeInput);
    quietHoursTimeContainer.appendChild(startTimeContainer);
    
    // End time
    const endTimeContainer = document.createElement('div');
    endTimeContainer.className = 'setting-item';
    
    const endTimeLabel = document.createElement('label');
    endTimeLabel.textContent = 'End Time';
    endTimeLabel.setAttribute('for', 'notification-quiet-hours-end');
    
    const endTimeInput = document.createElement('input');
    endTimeInput.type = 'time';
    endTimeInput.id = 'notification-quiet-hours-end';
    endTimeInput.value = this.userPreferences.quietHours.end;
    endTimeInput.addEventListener('change', () => {
      this.userPreferences.quietHours.end = endTimeInput.value;
      this.saveUserPreferences();
    });
    
    endTimeContainer.appendChild(endTimeLabel);
    endTimeContainer.appendChild(endTimeInput);
    quietHoursTimeContainer.appendChild(endTimeContainer);
    
    quietHoursContainer.appendChild(quietHoursTimeContainer);
    notificationSettings.appendChild(quietHoursContainer);
    
    // Add delivery options
    const deliveryContainer = document.createElement('div');
    deliveryContainer.className = 'setting-group';
    deliveryContainer.style.display = this.userPreferences.enabled ? 'block' : 'none';
    
    const deliveryHeading = document.createElement('h4');
    deliveryHeading.textContent = 'Delivery Options';
    deliveryContainer.appendChild(deliveryHeading);
    
    // Vibration toggle
    const vibrateContainer = document.createElement('div');
    vibrateContainer.className = 'setting-item';
    
    const vibrateLabel = document.createElement('label');
    vibrateLabel.textContent = 'Vibrate on Mobile';
    vibrateLabel.setAttribute('for', 'notification-vibrate-toggle');
    
    const vibrateToggle = document.createElement('input');
    vibrateToggle.type = 'checkbox';
    vibrateToggle.id = 'notification-vibrate-toggle';
    vibrateToggle.checked = this.userPreferences.deliveryOptions.vibrateOnMobile;
    vibrateToggle.addEventListener('change', () => {
      this.userPreferences.deliveryOptions.vibrateOnMobile = vibrateToggle.checked;
      this.saveUserPreferences();
    });
    
    vibrateContainer.appendChild(vibrateLabel);
    vibrateContainer.appendChild(vibrateToggle);
    deliveryContainer.appendChild(vibrateContainer);
    
    // Group similar toggle
    const groupContainer = document.createElement('div');
    groupContainer.className = 'setting-item';
    
    const groupLabel = document.createElement('label');
    groupLabel.textContent = 'Group Similar Notifications';
    groupLabel.setAttribute('for', 'notification-group-toggle');
    
    const groupToggle = document.createElement('input');
    groupToggle.type = 'checkbox';
    groupToggle.id = 'notification-group-toggle';
    groupToggle.checked = this.userPreferences.deliveryOptions.groupSimilar;
    groupToggle.addEventListener('change', () => {
      this.userPreferences.deliveryOptions.groupSimilar = groupToggle.checked;
      this.saveUserPreferences();
    });
    
    groupContainer.appendChild(groupLabel);
    groupContainer.appendChild(groupToggle);
    deliveryContainer.appendChild(groupContainer);
    
    // Max per hour
    const maxPerHourContainer = document.createElement('div');
    maxPerHourContainer.className = 'setting-item';
    
    const maxPerHourLabel = document.createElement('label');
    maxPerHourLabel.textContent = 'Maximum Notifications Per Hour';
    maxPerHourLabel.setAttribute('for', 'notification-max-per-hour');
    
    const maxPerHourInput = document.createElement('input');
    maxPerHourInput.type = 'number';
    maxPerHourInput.id = 'notification-max-per-hour';
    maxPerHourInput.min = '1';
    maxPerHourInput.max = '20';
    maxPerHourInput.value = this.userPreferences.deliveryOptions.maxPerHour;
    maxPerHourInput.addEventListener('change', () => {
      this.userPreferences.deliveryOptions.maxPerHour = parseInt(maxPerHourInput.value, 10);
      this.saveUserPreferences();
    });
    
    maxPerHourContainer.appendChild(maxPerHourLabel);
    maxPerHourContainer.appendChild(maxPerHourInput);
    deliveryContainer.appendChild(maxPerHourContainer);
    
    notificationSettings.appendChild(deliveryContainer);
    
    // Add test notification button
    const testButtonContainer = document.createElement('div');
    testButtonContainer.className = 'setting-item';
    testButtonContainer.style.display = this.userPreferences.enabled ? 'block' : 'none';
    
    const testButton = document.createElement('button');
    testButton.textContent = 'Send Test Notification';
    testButton.className = 'btn btn-secondary';
    testButton.addEventListener('click', () => {
      this.showNotification('Test Notification', {
        body: 'This is a test notification from Care Mate.',
        icon: this.config.defaultIcon,
        badge: this.config.defaultBadge,
        tag: 'test-notification',
        data: {
          category: 'system'
        }
      });
    });
    
    testButtonContainer.appendChild(testButton);
    notificationSettings.appendChild(testButtonContainer);
    
    // Update main toggle based on permission status
    if (this.permissionStatus === 'denied') {
      mainToggle.disabled = true;
      mainToggle.checked = false;
      
      const permissionWarning = document.createElement('div');
      permissionWarning.className = 'notification-permission-warning';
      permissionWarning.textContent = 'Notifications are blocked in your browser settings. Please update your browser settings to enable notifications.';
      notificationSettings.insertBefore(permissionWarning, categoriesContainer);
    }
  }

  /**
   * Update UI based on subscription status
   */
  updateUI() {
    const mainToggle = document.getElementById('notification-main-toggle');
    if (mainToggle) {
      mainToggle.checked = this.isSubscribed && this.userPreferences.enabled;
    }
    
    // Show/hide category settings based on main toggle
    const categoriesContainer = document.querySelector('#notification-settings .setting-group');
    if (categoriesContainer) {
      categoriesContainer.style.display = this.isSubscribed && this.userPreferences.enabled ? 'block' : 'none';
    }
    
    // Show/hide quiet hours settings based on main toggle
    const quietHoursContainer = document.querySelectorAll('#notification-settings .setting-group')[1];
    if (quietHoursContainer) {
      quietHoursContainer.style.display = this.isSubscribed && this.userPreferences.enabled ? 'block' : 'none';
    }
    
    // Show/hide delivery options based on main toggle
    const deliveryContainer = document.querySelectorAll('#notification-settings .setting-group')[2];
    if (deliveryContainer) {
      deliveryContainer.style.display = this.isSubscribed && this.userPreferences.enabled ? 'block' : 'none';
    }
    
    // Show/hide test button based on main toggle
    const testButtonContainer = document.querySelector('#notification-settings .setting-item:last-child');
    if (testButtonContainer) {
      testButtonContainer.style.display = this.isSubscribed && this.userPreferences.enabled ? 'block' : 'none';
    }
  }

  /**
   * Set up event listeners
   */
  setupEventListeners() {
    // Listen for messages from service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', event => {
        if (event.data && event.data.type === 'NOTIFICATION_CLICKED') {
          console.log('[EnhancedPush] Notification clicked:', event.data);
          
          // Handle notification click
          this.handleNotificationClick(event.data);
        }
      });
    }
  }

  /**
   * Handle notification click
   * @param {Object} data - Notification data
   */
  handleNotificationClick(data) {
    // Track notification interaction
    console.log('[EnhancedPush] Handling notification click:', data);
    
    // Navigate to appropriate page based on notification type
    if (data.url) {
      window.location.href = data.url;
    }
  }

  /**
   * Get display name for notification category
   * @param {string} category - Category ID
   * @returns {string} Display name
   */
  getCategoryDisplayName(category) {
    const displayNames = {
      plan_updates: 'Plan Updates',
      appointments: 'Appointments',
      messages: 'Messages',
      budget_alerts: 'Budget Alerts',
      system: 'System Notifications'
    };
    
    return displayNames[category] || category;
  }

  /**
   * Convert base64 string to Uint8Array for applicationServerKey
   * @param {string} base64String - Base64 encoded string
   * @returns {Uint8Array} Converted array
   */
  urlB64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/\-/g, '+')
      .replace(/_/g, '/');
    
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    
    return outputArray;
  }

  /**
   * Check if push notifications are supported
   * @returns {boolean} Whether push notifications are supported
   */
  isSupported() {
    return 'serviceWorker' in navigator && 'PushManager' in window;
  }

  /**
   * Get the current permission status
   * @returns {string} Permission status ('granted', 'denied', or 'default')
   */
  getPermissionStatus() {
    return this.permissionStatus;
  }

  /**
   * Get user preferences
   * @returns {Object} User preferences
   */
  getUserPreferences() {
    return { ...this.userPreferences };
  }
}

export default EnhancedPushNotificationManager;
