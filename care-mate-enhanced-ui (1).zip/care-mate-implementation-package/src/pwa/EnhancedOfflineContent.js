/**
 * Care Mate - Enhanced Offline Content Manager
 * 
 * This module provides advanced offline content management capabilities,
 * including predictive caching, content prioritization, and intelligent
 * cache invalidation strategies.
 */

class EnhancedOfflineContent {
  constructor(options = {}) {
    // Default configuration
    this.config = {
      cacheName: 'care-mate-enhanced-content-v1',
      maxCacheSize: 50 * 1024 * 1024, // 50MB max cache size
      contentPriorities: {
        critical: 30 * 24 * 60 * 60 * 1000, // 30 days
        high: 7 * 24 * 60 * 60 * 1000,      // 7 days
        medium: 3 * 24 * 60 * 60 * 1000,    // 3 days
        low: 24 * 60 * 60 * 1000            // 1 day
      },
      prefetchThreshold: 0.7, // Prefetch if probability > 70%
      ...options
    };

    // State
    this.cacheStats = {
      size: 0,
      items: 0,
      lastCleanup: Date.now()
    };
    
    this.userPreferences = {
      enablePredictiveCaching: true,
      maxCacheSize: this.config.maxCacheSize,
      prefetchOnWifi: true
    };

    this.contentUsageStats = new Map();
    this.initialized = false;

    // Bind methods
    this.init = this.init.bind(this);
    this.cacheContent = this.cacheContent.bind(this);
    this.getCachedContent = this.getCachedContent.bind(this);
    this.removeCachedContent = this.removeCachedContent.bind(this);
    this.prefetchContent = this.prefetchContent.bind(this);
    this.cleanupCache = this.cleanupCache.bind(this);
    this.trackContentUsage = this.trackContentUsage.bind(this);
    this.predictContentNeeds = this.predictContentNeeds.bind(this);
    this.updateCacheStats = this.updateCacheStats.bind(this);
    this.loadUserPreferences = this.loadUserPreferences.bind(this);
    this.saveUserPreferences = this.saveUserPreferences.bind(this);
  }

  /**
   * Initialize the enhanced offline content manager
   * @returns {Promise<boolean>} Whether initialization was successful
   */
  async init() {
    if (this.initialized) {
      return true;
    }

    try {
      // Load user preferences
      await this.loadUserPreferences();
      
      // Update cache statistics
      await this.updateCacheStats();
      
      // Set up event listeners
      this.setupEventListeners();
      
      // Set up periodic cache maintenance
      this.setupPeriodicMaintenance();
      
      this.initialized = true;
      console.log('[EnhancedOfflineContent] Initialized successfully');
      return true;
    } catch (error) {
      console.error('[EnhancedOfflineContent] Initialization failed:', error);
      return false;
    }
  }

  /**
   * Set up event listeners
   */
  setupEventListeners() {
    // Listen for network status changes
    window.addEventListener('online', () => {
      console.log('[EnhancedOfflineContent] Device is online, checking for content to prefetch');
      this.checkForContentToPrefetch();
    });

    // Listen for service worker messages
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data && event.data.type === 'CACHE_UPDATED') {
          this.updateCacheStats();
        }
      });
    }

    // Listen for visibility changes to optimize prefetching
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        // User is actively using the app, defer heavy prefetching
        this.deferHeavyPrefetching = false;
      } else {
        // App is in background, can do heavier prefetching
        this.deferHeavyPrefetching = true;
        this.checkForContentToPrefetch();
      }
    });
  }

  /**
   * Set up periodic cache maintenance
   */
  setupPeriodicMaintenance() {
    // Clean up cache every 24 hours
    setInterval(() => {
      this.cleanupCache();
    }, 24 * 60 * 60 * 1000);

    // Update cache stats every hour
    setInterval(() => {
      this.updateCacheStats();
    }, 60 * 60 * 1000);

    // Check for content to prefetch every 30 minutes when online
    setInterval(() => {
      if (navigator.onLine) {
        this.checkForContentToPrefetch();
      }
    }, 30 * 60 * 1000);
  }

  /**
   * Cache content with priority level
   * @param {string} url - URL of the content to cache
   * @param {string} priority - Priority level ('critical', 'high', 'medium', 'low')
   * @param {Object} metadata - Additional metadata about the content
   * @returns {Promise<boolean>} Whether caching was successful
   */
  async cacheContent(url, priority = 'medium', metadata = {}) {
    if (!url) {
      console.error('[EnhancedOfflineContent] No URL provided for caching');
      return false;
    }

    try {
      const cache = await caches.open(this.config.cacheName);
      
      // Fetch the content
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch content: ${response.status} ${response.statusText}`);
      }
      
      // Clone the response before caching
      const responseToCache = response.clone();
      
      // Create a Response with custom headers for metadata
      const headers = new Headers(responseToCache.headers);
      headers.append('X-Cache-Priority', priority);
      headers.append('X-Cache-Timestamp', Date.now().toString());
      
      // Add custom metadata
      Object.entries(metadata).forEach(([key, value]) => {
        headers.append(`X-Cache-Metadata-${key}`, JSON.stringify(value));
      });
      
      // Create a new response with the updated headers
      const enhancedResponse = new Response(await responseToCache.blob(), {
        status: responseToCache.status,
        statusText: responseToCache.statusText,
        headers
      });
      
      // Cache the enhanced response
      await cache.put(url, enhancedResponse);
      
      // Update cache stats
      await this.updateCacheStats();
      
      console.log(`[EnhancedOfflineContent] Cached content: ${url} (${priority})`);
      return true;
    } catch (error) {
      console.error(`[EnhancedOfflineContent] Failed to cache content: ${url}`, error);
      return false;
    }
  }

  /**
   * Get cached content
   * @param {string} url - URL of the content to retrieve
   * @returns {Promise<Response|null>} Cached response or null if not found
   */
  async getCachedContent(url) {
    try {
      const cache = await caches.open(this.config.cacheName);
      const response = await cache.match(url);
      
      if (response) {
        // Track content usage
        this.trackContentUsage(url);
        return response;
      }
      
      return null;
    } catch (error) {
      console.error(`[EnhancedOfflineContent] Failed to get cached content: ${url}`, error);
      return null;
    }
  }

  /**
   * Remove cached content
   * @param {string} url - URL of the content to remove
   * @returns {Promise<boolean>} Whether removal was successful
   */
  async removeCachedContent(url) {
    try {
      const cache = await caches.open(this.config.cacheName);
      const result = await cache.delete(url);
      
      // Update cache stats
      await this.updateCacheStats();
      
      console.log(`[EnhancedOfflineContent] Removed cached content: ${url} (${result ? 'success' : 'not found'})`);
      return result;
    } catch (error) {
      console.error(`[EnhancedOfflineContent] Failed to remove cached content: ${url}`, error);
      return false;
    }
  }

  /**
   * Prefetch content based on URL and priority
   * @param {string} url - URL of the content to prefetch
   * @param {string} priority - Priority level ('critical', 'high', 'medium', 'low')
   * @param {Object} metadata - Additional metadata about the content
   * @returns {Promise<boolean>} Whether prefetching was successful
   */
  async prefetchContent(url, priority = 'medium', metadata = {}) {
    // Check if we should prefetch based on network conditions
    if (this.userPreferences.prefetchOnWifi && this.isMeteredConnection()) {
      console.log(`[EnhancedOfflineContent] Skipping prefetch on metered connection: ${url}`);
      return false;
    }
    
    // Check if content is already cached
    const cachedContent = await this.getCachedContent(url);
    if (cachedContent) {
      console.log(`[EnhancedOfflineContent] Content already cached: ${url}`);
      return true;
    }
    
    // Check if we have enough cache space
    if (this.cacheStats.size >= this.userPreferences.maxCacheSize) {
      // Try to clean up first
      await this.cleanupCache();
      
      // If still not enough space, skip prefetching
      if (this.cacheStats.size >= this.userPreferences.maxCacheSize) {
        console.warn(`[EnhancedOfflineContent] Not enough cache space for prefetching: ${url}`);
        return false;
      }
    }
    
    // Prefetch the content
    return await this.cacheContent(url, priority, {
      ...metadata,
      prefetched: true,
      prefetchTime: Date.now()
    });
  }

  /**
   * Clean up the cache based on priority and usage
   * @returns {Promise<number>} Number of items removed
   */
  async cleanupCache() {
    try {
      const cache = await caches.open(this.config.cacheName);
      const requests = await cache.keys();
      const now = Date.now();
      let removedCount = 0;
      
      // Sort items by priority and last access
      const itemsToEvaluate = await Promise.all(requests.map(async (request) => {
        const response = await cache.match(request);
        const priority = response.headers.get('X-Cache-Priority') || 'medium';
        const timestamp = parseInt(response.headers.get('X-Cache-Timestamp') || '0');
        const lastAccess = this.contentUsageStats.get(request.url)?.lastAccess || timestamp;
        
        // Calculate expiration based on priority
        const ttl = this.config.contentPriorities[priority] || this.config.contentPriorities.medium;
        const expiresAt = timestamp + ttl;
        
        return {
          request,
          priority,
          timestamp,
          lastAccess,
          expiresAt,
          expired: now > expiresAt
        };
      }));
      
      // First remove expired items
      const expiredItems = itemsToEvaluate.filter(item => item.expired);
      
      for (const item of expiredItems) {
        await cache.delete(item.request);
        removedCount++;
      }
      
      // If we still need to free up space, remove low priority items
      if (this.cacheStats.size > this.userPreferences.maxCacheSize * 0.9) {
        // Sort remaining items by priority (low first) and then by last access (oldest first)
        const priorityOrder = { low: 0, medium: 1, high: 2, critical: 3 };
        
        const remainingItems = itemsToEvaluate
          .filter(item => !item.expired)
          .sort((a, b) => {
            // First compare by priority
            const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
            if (priorityDiff !== 0) return priorityDiff;
            
            // Then by last access time
            return a.lastAccess - b.lastAccess;
          });
        
        // Remove items until we're under 80% capacity
        let currentIndex = 0;
        while (this.cacheStats.size > this.userPreferences.maxCacheSize * 0.8 && currentIndex < remainingItems.length) {
          const item = remainingItems[currentIndex];
          
          // Don't remove critical items
          if (item.priority !== 'critical') {
            await cache.delete(item.request);
            removedCount++;
          }
          
          currentIndex++;
        }
      }
      
      // Update cache stats
      await this.updateCacheStats();
      
      this.cacheStats.lastCleanup = now;
      console.log(`[EnhancedOfflineContent] Cache cleanup complete, removed ${removedCount} items`);
      
      return removedCount;
    } catch (error) {
      console.error('[EnhancedOfflineContent] Cache cleanup failed:', error);
      return 0;
    }
  }

  /**
   * Track content usage for better prefetching decisions
   * @param {string} url - URL of the content being used
   */
  trackContentUsage(url) {
    const now = Date.now();
    const stats = this.contentUsageStats.get(url) || {
      url,
      accessCount: 0,
      firstAccess: now,
      lastAccess: now,
      accessTimes: []
    };
    
    // Update stats
    stats.accessCount++;
    stats.lastAccess = now;
    stats.accessTimes.push(now);
    
    // Keep only the last 10 access times
    if (stats.accessTimes.length > 10) {
      stats.accessTimes.shift();
    }
    
    // Store updated stats
    this.contentUsageStats.set(url, stats);
    
    // Persist usage stats periodically
    this.debounceSaveUsageStats();
  }

  /**
   * Debounce saving usage stats to avoid excessive storage operations
   */
  debounceSaveUsageStats() {
    if (this.saveStatsTimeout) {
      clearTimeout(this.saveStatsTimeout);
    }
    
    this.saveStatsTimeout = setTimeout(() => {
      this.saveUsageStats();
    }, 5000);
  }

  /**
   * Save content usage stats to localStorage
   */
  saveUsageStats() {
    try {
      const statsArray = Array.from(this.contentUsageStats.values());
      localStorage.setItem('care-mate-content-usage-stats', JSON.stringify(statsArray));
    } catch (error) {
      console.error('[EnhancedOfflineContent] Failed to save usage stats:', error);
    }
  }

  /**
   * Load content usage stats from localStorage
   */
  loadUsageStats() {
    try {
      const statsJson = localStorage.getItem('care-mate-content-usage-stats');
      
      if (statsJson) {
        const statsArray = JSON.parse(statsJson);
        
        this.contentUsageStats.clear();
        statsArray.forEach(stats => {
          this.contentUsageStats.set(stats.url, stats);
        });
        
        console.log(`[EnhancedOfflineContent] Loaded usage stats for ${statsArray.length} items`);
      }
    } catch (error) {
      console.error('[EnhancedOfflineContent] Failed to load usage stats:', error);
    }
  }

  /**
   * Predict content that the user might need based on usage patterns
   * @returns {Array<Object>} Array of predicted content items with URLs and probabilities
   */
  predictContentNeeds() {
    const predictions = [];
    const now = Date.now();
    const dayOfWeek = new Date().getDay();
    const hourOfDay = new Date().getHours();
    
    // Analyze each content item's usage pattern
    this.contentUsageStats.forEach((stats, url) => {
      // Skip if accessed less than 3 times
      if (stats.accessCount < 3) {
        return;
      }
      
      // Calculate time since last access
      const timeSinceLastAccess = now - stats.lastAccess;
      
      // Skip if accessed very recently (last 10 minutes)
      if (timeSinceLastAccess < 10 * 60 * 1000) {
        return;
      }
      
      // Skip if not accessed in a very long time (more than 30 days)
      if (timeSinceLastAccess > 30 * 24 * 60 * 60 * 1000) {
        return;
      }
      
      // Calculate access frequency (accesses per day)
      const totalDays = Math.max(1, (stats.lastAccess - stats.firstAccess) / (24 * 60 * 60 * 1000));
      const frequency = stats.accessCount / totalDays;
      
      // Calculate time patterns
      let dayMatch = 0;
      let hourMatch = 0;
      let totalPatterns = 0;
      
      stats.accessTimes.forEach(time => {
        const date = new Date(time);
        if (date.getDay() === dayOfWeek) {
          dayMatch++;
        }
        if (Math.abs(date.getHours() - hourOfDay) <= 1) {
          hourMatch++;
        }
        totalPatterns++;
      });
      
      // Calculate probability based on frequency and patterns
      const frequencyScore = Math.min(1, frequency / 2); // Cap at 1 for items accessed more than twice per day
      const patternScore = totalPatterns > 0 ? (dayMatch + hourMatch) / (totalPatterns * 2) : 0;
      const recencyScore = Math.max(0, 1 - (timeSinceLastAccess / (7 * 24 * 60 * 60 * 1000))); // Higher for more recent access
      
      // Combine scores with weights
      const probability = (frequencyScore * 0.4) + (patternScore * 0.4) + (recencyScore * 0.2);
      
      predictions.push({
        url,
        probability,
        stats: {
          frequency,
          dayMatch: totalPatterns > 0 ? dayMatch / totalPatterns : 0,
          hourMatch: totalPatterns > 0 ? hourMatch / totalPatterns : 0,
          recency: recencyScore
        }
      });
    });
    
    // Sort by probability (highest first)
    return predictions.sort((a, b) => b.probability - a.probability);
  }

  /**
   * Check for content to prefetch based on predictions
   */
  async checkForContentToPrefetch() {
    // Skip if predictive caching is disabled
    if (!this.userPreferences.enablePredictiveCaching) {
      return;
    }
    
    // Skip if offline
    if (!navigator.onLine) {
      return;
    }
    
    // Skip if on metered connection and user preference is to avoid it
    if (this.userPreferences.prefetchOnWifi && this.isMeteredConnection()) {
      return;
    }
    
    // Get content predictions
    const predictions = this.predictContentNeeds();
    
    // Prefetch high-probability content
    let prefetchCount = 0;
    for (const prediction of predictions) {
      if (prediction.probability >= this.config.prefetchThreshold) {
        const priority = this.getPriorityFromProbability(prediction.probability);
        
        const success = await this.prefetchContent(prediction.url, priority, {
          predictedProbability: prediction.probability,
          predictionStats: prediction.stats
        });
        
        if (success) {
          prefetchCount++;
        }
        
        // Limit the number of prefetches to avoid excessive network usage
        if (prefetchCount >= 5) {
          break;
        }
      }
    }
    
    if (prefetchCount > 0) {
      console.log(`[EnhancedOfflineContent] Prefetched ${prefetchCount} predicted content items`);
    }
  }

  /**
   * Get priority level based on probability
   * @param {number} probability - Probability score (0-1)
   * @returns {string} Priority level
   */
  getPriorityFromProbability(probability) {
    if (probability >= 0.9) return 'critical';
    if (probability >= 0.8) return 'high';
    if (probability >= 0.7) return 'medium';
    return 'low';
  }

  /**
   * Check if the current connection is metered
   * @returns {boolean} Whether the connection is metered
   */
  isMeteredConnection() {
    if ('connection' in navigator) {
      // @ts-ignore - Navigator connection is not in all type definitions
      const connection = navigator.connection;
      if (connection && 'saveData' in connection) {
        return connection.saveData;
      }
    }
    
    // Default to false if we can't determine
    return false;
  }

  /**
   * Update cache statistics
   * @returns {Promise<void>}
   */
  async updateCacheStats() {
    try {
      const cache = await caches.open(this.config.cacheName);
      const requests = await cache.keys();
      
      let totalSize = 0;
      
      // Calculate total size
      for (const request of requests) {
        const response = await cache.match(request);
        const blob = await response.blob();
        totalSize += blob.size;
      }
      
      this.cacheStats = {
        size: totalSize,
        items: requests.length,
        lastUpdated: Date.now(),
        lastCleanup: this.cacheStats.lastCleanup
      };
      
      console.log(`[EnhancedOfflineContent] Cache stats: ${requests.length} items, ${(totalSize / 1024 / 1024).toFixed(2)}MB`);
    } catch (error) {
      console.error('[EnhancedOfflineContent] Failed to update cache stats:', error);
    }
  }

  /**
   * Load user preferences from localStorage
   */
  loadUserPreferences() {
    try {
      const prefsJson = localStorage.getItem('care-mate-offline-content-prefs');
      
      if (prefsJson) {
        const prefs = JSON.parse(prefsJson);
        this.userPreferences = {
          ...this.userPreferences,
          ...prefs
        };
        
        console.log('[EnhancedOfflineContent] Loaded user preferences');
      }
      
      // Also load usage stats
      this.loadUsageStats();
    } catch (error) {
      console.error('[EnhancedOfflineContent] Failed to load user preferences:', error);
    }
  }

  /**
   * Save user preferences to localStorage
   */
  saveUserPreferences() {
    try {
      localStorage.setItem('care-mate-offline-content-prefs', JSON.stringify(this.userPreferences));
    } catch (error) {
      console.error('[EnhancedOfflineContent] Failed to save user preferences:', error);
    }
  }

  /**
   * Update user preferences
   * @param {Object} preferences - New preferences
   */
  updateUserPreferences(preferences) {
    this.userPreferences = {
      ...this.userPreferences,
      ...preferences
    };
    
    this.saveUserPreferences();
    console.log('[EnhancedOfflineContent] Updated user preferences');
  }

  /**
   * Get cache statistics
   * @returns {Object} Cache statistics
   */
  getCacheStats() {
    return {
      ...this.cacheStats,
      sizeInMB: (this.cacheStats.size / 1024 / 1024).toFixed(2),
      percentUsed: ((this.cacheStats.size / this.userPreferences.maxCacheSize) * 100).toFixed(1)
    };
  }

  /**
   * Get user preferences
   * @returns {Object} User preferences
   */
  getUserPreferences() {
    return { ...this.userPreferences };
  }
}

export default EnhancedOfflineContent;
