/**
 * Care Mate - Audio Recorder Module
 * 
 * This module provides functionality for recording audio messages to send to the AI assistant.
 * It handles recording, playback, and conversion to formats suitable for transcription.
 */

class AudioRecorder {
  constructor(options = {}) {
    // Default configuration
    this.config = {
      maxDuration: 60, // Maximum recording duration in seconds
      mimeType: 'audio/webm', // Preferred MIME type
      audioBitsPerSecond: 128000,
      enableVisualFeedback: true,
      ...options
    };

    // State variables
    this.mediaRecorder = null;
    this.audioChunks = [];
    this.audioBlob = null;
    this.audioUrl = null;
    this.stream = null;
    this.isRecording = false;
    this.isPaused = false;
    this.duration = 0;
    this.timerInterval = null;
    this.visualizer = null;
    this.analyser = null;
    
    // Event callbacks
    this.onStart = null;
    this.onStop = null;
    this.onPause = null;
    this.onResume = null;
    this.onDataAvailable = null;
    this.onError = null;
    this.onTimerUpdate = null;

    // Bind methods
    this.start = this.start.bind(this);
    this.stop = this.stop.bind(this);
    this.pause = this.pause.bind(this);
    this.resume = this.resume.bind(this);
    this.cancel = this.cancel.bind(this);
    this.getAudioBlob = this.getAudioBlob.bind(this);
    this.getAudioUrl = this.getAudioUrl.bind(this);
    this.setupVisualFeedback = this.setupVisualFeedback.bind(this);
    this.updateVisualFeedback = this.updateVisualFeedback.bind(this);
    this.checkBrowserSupport = this.checkBrowserSupport.bind(this);
  }

  /**
   * Check if the browser supports audio recording
   * @returns {Object} Object containing support status and details
   */
  checkBrowserSupport() {
    const support = {
      supported: false,
      mediaDevices: false,
      mediaRecorder: false,
      audioContext: false,
      details: []
    };

    // Check for mediaDevices API
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      support.mediaDevices = true;
      support.details.push('MediaDevices API is supported');
    } else {
      support.details.push('MediaDevices API is not supported');
    }

    // Check for MediaRecorder API
    if (typeof MediaRecorder !== 'undefined') {
      support.mediaRecorder = true;
      support.details.push('MediaRecorder API is supported');
    } else {
      support.details.push('MediaRecorder API is not supported');
    }

    // Check for AudioContext API
    if (window.AudioContext || window.webkitAudioContext) {
      support.audioContext = true;
      support.details.push('AudioContext API is supported');
    } else {
      support.details.push('AudioContext API is not supported');
    }

    // Check for overall support
    support.supported = support.mediaDevices && support.mediaRecorder;

    return support;
  }

  /**
   * Start audio recording
   * @param {HTMLElement} visualizerElement - Optional canvas element for visualization
   * @returns {Promise} Promise that resolves when recording starts
   */
  async start(visualizerElement = null) {
    if (this.isRecording) {
      throw new Error('Recording is already in progress');
    }

    try {
      // Request microphone access
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Determine supported MIME type
      const mimeType = this.getSupportedMimeType();
      
      // Create MediaRecorder instance
      this.mediaRecorder = new MediaRecorder(this.stream, {
        mimeType,
        audioBitsPerSecond: this.config.audioBitsPerSecond
      });
      
      // Set up event handlers
      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.audioChunks.push(event.data);
          
          if (this.onDataAvailable) {
            this.onDataAvailable(event.data);
          }
        }
      };
      
      this.mediaRecorder.onstart = () => {
        this.isRecording = true;
        this.isPaused = false;
        this.duration = 0;
        this.startTimer();
        
        if (this.onStart) {
          this.onStart();
        }
      };
      
      this.mediaRecorder.onstop = () => {
        this.isRecording = false;
        this.stopTimer();
        this.releaseMediaResources();
        
        // Create audio blob and URL
        this.audioBlob = new Blob(this.audioChunks, { type: mimeType });
        this.audioUrl = URL.createObjectURL(this.audioBlob);
        
        if (this.onStop) {
          this.onStop({
            blob: this.audioBlob,
            url: this.audioUrl,
            duration: this.duration
          });
        }
      };
      
      this.mediaRecorder.onpause = () => {
        this.isPaused = true;
        this.pauseTimer();
        
        if (this.onPause) {
          this.onPause();
        }
      };
      
      this.mediaRecorder.onresume = () => {
        this.isPaused = false;
        this.resumeTimer();
        
        if (this.onResume) {
          this.onResume();
        }
      };
      
      this.mediaRecorder.onerror = (event) => {
        if (this.onError) {
          this.onError(event.error);
        }
      };
      
      // Set up visual feedback if enabled and element provided
      if (this.config.enableVisualFeedback && visualizerElement) {
        this.setupVisualFeedback(visualizerElement);
      }
      
      // Start recording
      this.audioChunks = [];
      this.mediaRecorder.start(100); // Collect data every 100ms
      
      return true;
    } catch (error) {
      if (this.onError) {
        this.onError(error);
      }
      throw error;
    }
  }

  /**
   * Stop audio recording
   * @returns {Promise} Promise that resolves with the recorded audio data
   */
  stop() {
    return new Promise((resolve, reject) => {
      if (!this.isRecording) {
        reject(new Error('No recording in progress'));
        return;
      }
      
      const onStopCallback = this.onStop;
      
      // Override onStop temporarily to resolve the promise
      this.onStop = (data) => {
        if (onStopCallback) {
          onStopCallback(data);
        }
        resolve(data);
      };
      
      this.mediaRecorder.stop();
    });
  }

  /**
   * Pause audio recording
   */
  pause() {
    if (this.isRecording && !this.isPaused && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.pause();
    }
  }

  /**
   * Resume audio recording
   */
  resume() {
    if (this.isRecording && this.isPaused && this.mediaRecorder.state === 'paused') {
      this.mediaRecorder.resume();
    }
  }

  /**
   * Cancel audio recording
   */
  cancel() {
    if (this.isRecording) {
      this.stopTimer();
      this.releaseMediaResources();
      this.isRecording = false;
      this.isPaused = false;
      this.audioChunks = [];
      this.audioBlob = null;
      this.audioUrl = null;
    }
  }

  /**
   * Get the recorded audio as a Blob
   * @returns {Blob|null} Audio blob or null if no recording
   */
  getAudioBlob() {
    return this.audioBlob;
  }

  /**
   * Get the URL for the recorded audio
   * @returns {string|null} Audio URL or null if no recording
   */
  getAudioUrl() {
    return this.audioUrl;
  }

  /**
   * Convert audio to base64 format
   * @returns {Promise<string>} Promise that resolves with base64 audio data
   */
  async toBase64() {
    return new Promise((resolve, reject) => {
      if (!this.audioBlob) {
        reject(new Error('No audio recording available'));
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64Audio = reader.result.split(',')[1];
        resolve(base64Audio);
      };
      reader.onerror = reject;
      reader.readAsDataURL(this.audioBlob);
    });
  }

  /**
   * Get supported MIME type for audio recording
   * @returns {string} Supported MIME type
   */
  getSupportedMimeType() {
    const preferredTypes = [
      this.config.mimeType,
      'audio/webm',
      'audio/webm;codecs=opus',
      'audio/mp4',
      'audio/ogg;codecs=opus',
      'audio/wav'
    ];
    
    for (const type of preferredTypes) {
      if (MediaRecorder.isTypeSupported(type)) {
        return type;
      }
    }
    
    // Fallback to browser default
    return '';
  }

  /**
   * Set up visual feedback for audio recording
   * @param {HTMLElement} canvas - Canvas element for visualization
   */
  setupVisualFeedback(canvas) {
    if (!canvas || !(canvas instanceof HTMLCanvasElement)) {
      return;
    }
    
    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioContext.createMediaStreamSource(this.stream);
      this.analyser = audioContext.createAnalyser();
      
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.8;
      source.connect(this.analyser);
      
      const canvasCtx = canvas.getContext('2d');
      const bufferLength = this.analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      
      this.visualizer = {
        canvas,
        canvasCtx,
        bufferLength,
        dataArray,
        animationFrame: null
      };
      
      const draw = () => {
        this.visualizer.animationFrame = requestAnimationFrame(draw);
        this.updateVisualFeedback();
      };
      
      draw();
    } catch (error) {
      console.error('Error setting up audio visualization:', error);
    }
  }

  /**
   * Update visual feedback for audio recording
   */
  updateVisualFeedback() {
    if (!this.visualizer || !this.analyser) {
      return;
    }
    
    const { canvas, canvasCtx, bufferLength, dataArray } = this.visualizer;
    const width = canvas.width;
    const height = canvas.height;
    
    // Get frequency data
    this.analyser.getByteFrequencyData(dataArray);
    
    // Clear canvas
    canvasCtx.clearRect(0, 0, width, height);
    
    // Draw visualization
    const barWidth = (width / bufferLength) * 2.5;
    let x = 0;
    
    for (let i = 0; i < bufferLength; i++) {
      const barHeight = (dataArray[i] / 255) * height;
      
      // Use gradient color based on frequency
      const hue = (i / bufferLength) * 120 + 240; // Blue to purple gradient
      canvasCtx.fillStyle = `hsl(${hue}, 100%, 50%)`;
      
      canvasCtx.fillRect(x, height - barHeight, barWidth, barHeight);
      x += barWidth + 1;
    }
  }

  /**
   * Start the recording timer
   */
  startTimer() {
    this.duration = 0;
    this.timerInterval = setInterval(() => {
      this.duration += 0.1;
      
      if (this.onTimerUpdate) {
        this.onTimerUpdate(this.duration);
      }
      
      // Check if max duration reached
      if (this.config.maxDuration > 0 && this.duration >= this.config.maxDuration) {
        this.stop();
      }
    }, 100);
  }

  /**
   * Pause the recording timer
   */
  pauseTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  /**
   * Resume the recording timer
   */
  resumeTimer() {
    if (!this.timerInterval) {
      this.timerInterval = setInterval(() => {
        this.duration += 0.1;
        
        if (this.onTimerUpdate) {
          this.onTimerUpdate(this.duration);
        }
        
        // Check if max duration reached
        if (this.config.maxDuration > 0 && this.duration >= this.config.maxDuration) {
          this.stop();
        }
      }, 100);
    }
  }

  /**
   * Stop the recording timer
   */
  stopTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
    
    if (this.visualizer && this.visualizer.animationFrame) {
      cancelAnimationFrame(this.visualizer.animationFrame);
      this.visualizer.animationFrame = null;
    }
  }

  /**
   * Release media resources
   */
  releaseMediaResources() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
  }

  /**
   * Format seconds to MM:SS display
   * @param {number} seconds - Time in seconds
   * @returns {string} Formatted time string
   */
  static formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
}

export default AudioRecorder;
