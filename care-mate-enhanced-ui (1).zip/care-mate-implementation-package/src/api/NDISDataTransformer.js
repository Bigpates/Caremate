/**
 * Care Mate - NDIS Data Transformation Utilities
 * 
 * This module provides utilities for transforming NDIS data formats,
 * normalizing data structures, and preparing data for display or storage.
 */

/**
 * Transform a raw NDIS plan into a normalized format
 * @param {Object} rawPlan - Raw plan data from the API
 * @returns {Object} Normalized plan data
 */
export function normalizePlanData(rawPlan) {
  if (!rawPlan) return null;
  
  return {
    id: rawPlan.plan_id || rawPlan.id,
    participantId: rawPlan.participant_id || rawPlan.participantId,
    startDate: new Date(rawPlan.start_date || rawPlan.startDate),
    endDate: new Date(rawPlan.end_date || rawPlan.endDate),
    status: rawPlan.status,
    goals: normalizeGoals(rawPlan.goals || []),
    budgets: normalizeBudgets(rawPlan.budgets || rawPlan.budget_categories || []),
    supportCoordination: extractSupportCoordination(rawPlan),
    totalFunding: calculateTotalFunding(rawPlan.budgets || rawPlan.budget_categories || []),
    createdAt: rawPlan.created_at ? new Date(rawPlan.created_at) : new Date(),
    updatedAt: rawPlan.updated_at ? new Date(rawPlan.updated_at) : new Date()
  };
}

/**
 * Normalize NDIS goals
 * @param {Array} goals - Raw goals data
 * @returns {Array} Normalized goals
 */
export function normalizeGoals(goals) {
  if (!Array.isArray(goals)) return [];
  
  return goals.map(goal => ({
    id: goal.goal_id || goal.id,
    category: goal.category || 'Uncategorized',
    description: goal.description || goal.goal_description || '',
    status: goal.status || 'active',
    targetDate: goal.target_date ? new Date(goal.target_date) : null,
    achievementCriteria: goal.achievement_criteria || goal.achievementCriteria || '',
    supports: Array.isArray(goal.supports) ? goal.supports.map(normalizeSupport) : []
  }));
}

/**
 * Normalize a support item
 * @param {Object} support - Raw support data
 * @returns {Object} Normalized support
 */
export function normalizeSupport(support) {
  return {
    id: support.support_id || support.id,
    name: support.name || support.support_name || '',
    category: support.category || support.support_category || '',
    registrationGroup: support.registration_group || support.registrationGroup || '',
    price: parseFloat(support.price || 0),
    quantity: parseFloat(support.quantity || 0),
    unit: support.unit || 'each',
    totalAmount: parseFloat(support.total_amount || support.totalAmount || 0)
  };
}

/**
 * Normalize NDIS budgets
 * @param {Array} budgets - Raw budget data
 * @returns {Array} Normalized budgets
 */
export function normalizeBudgets(budgets) {
  if (!Array.isArray(budgets)) return [];
  
  return budgets.map(budget => ({
    id: budget.budget_id || budget.id,
    category: budget.category || budget.budget_category || '',
    subcategory: budget.subcategory || budget.budget_subcategory || '',
    allocated: parseFloat(budget.allocated || budget.allocated_amount || 0),
    spent: parseFloat(budget.spent || budget.spent_amount || 0),
    committed: parseFloat(budget.committed || budget.committed_amount || 0),
    available: parseFloat(budget.available || budget.available_amount || 0),
    managedBy: budget.managed_by || budget.managedBy || 'agency',
    supports: Array.isArray(budget.supports) ? budget.supports.map(normalizeSupport) : []
  }));
}

/**
 * Extract support coordination details from a plan
 * @param {Object} plan - Raw plan data
 * @returns {Object} Support coordination details
 */
export function extractSupportCoordination(plan) {
  const supportCoordination = {
    allocated: 0,
    spent: 0,
    available: 0,
    coordinator: null
  };
  
  // Try to find support coordination in budgets
  const budgets = plan.budgets || plan.budget_categories || [];
  const scBudget = budgets.find(b => 
    (b.category || '').toLowerCase().includes('support coordination') || 
    (b.subcategory || '').toLowerCase().includes('support coordination')
  );
  
  if (scBudget) {
    supportCoordination.allocated = parseFloat(scBudget.allocated || scBudget.allocated_amount || 0);
    supportCoordination.spent = parseFloat(scBudget.spent || scBudget.spent_amount || 0);
    supportCoordination.available = parseFloat(scBudget.available || scBudget.available_amount || 0);
  }
  
  // Try to find coordinator details
  if (plan.support_coordinator || plan.supportCoordinator) {
    const coordinator = plan.support_coordinator || plan.supportCoordinator;
    supportCoordination.coordinator = {
      name: coordinator.name || '',
      organization: coordinator.organization || '',
      phone: coordinator.phone || '',
      email: coordinator.email || ''
    };
  }
  
  return supportCoordination;
}

/**
 * Calculate total funding from budgets
 * @param {Array} budgets - Budget data
 * @returns {Object} Total funding amounts
 */
export function calculateTotalFunding(budgets) {
  if (!Array.isArray(budgets)) return { allocated: 0, spent: 0, committed: 0, available: 0 };
  
  return budgets.reduce((totals, budget) => {
    totals.allocated += parseFloat(budget.allocated || budget.allocated_amount || 0);
    totals.spent += parseFloat(budget.spent || budget.spent_amount || 0);
    totals.committed += parseFloat(budget.committed || budget.committed_amount || 0);
    totals.available += parseFloat(budget.available || budget.available_amount || 0);
    return totals;
  }, { allocated: 0, spent: 0, committed: 0, available: 0 });
}

/**
 * Transform participant data into a normalized format
 * @param {Object} rawParticipant - Raw participant data from the API
 * @returns {Object} Normalized participant data
 */
export function normalizeParticipantData(rawParticipant) {
  if (!rawParticipant) return null;
  
  return {
    id: rawParticipant.participant_id || rawParticipant.id,
    ndisNumber: rawParticipant.ndis_number || rawParticipant.ndisNumber,
    firstName: rawParticipant.first_name || rawParticipant.firstName || '',
    lastName: rawParticipant.last_name || rawParticipant.lastName || '',
    dateOfBirth: rawParticipant.date_of_birth ? new Date(rawParticipant.date_of_birth) : null,
    gender: rawParticipant.gender || '',
    contactDetails: normalizeContactDetails(rawParticipant),
    currentPlan: rawParticipant.current_plan ? normalizePlanData(rawParticipant.current_plan) : null,
    previousPlans: Array.isArray(rawParticipant.previous_plans) 
      ? rawParticipant.previous_plans.map(normalizePlanData) 
      : [],
    supportNetwork: normalizeSupports(rawParticipant.support_network || rawParticipant.supportNetwork || []),
    preferences: rawParticipant.preferences || {},
    createdAt: rawParticipant.created_at ? new Date(rawParticipant.created_at) : new Date(),
    updatedAt: rawParticipant.updated_at ? new Date(rawParticipant.updated_at) : new Date()
  };
}

/**
 * Normalize contact details
 * @param {Object} participant - Participant data
 * @returns {Object} Normalized contact details
 */
export function normalizeContactDetails(participant) {
  const contactDetails = participant.contact_details || participant.contactDetails || {};
  
  return {
    email: contactDetails.email || participant.email || '',
    phone: contactDetails.phone || participant.phone || '',
    mobile: contactDetails.mobile || participant.mobile || '',
    address: normalizeAddress(contactDetails.address || participant.address || {})
  };
}

/**
 * Normalize address data
 * @param {Object} address - Address data
 * @returns {Object} Normalized address
 */
export function normalizeAddress(address) {
  return {
    street: address.street || '',
    suburb: address.suburb || '',
    state: address.state || '',
    postcode: address.postcode || '',
    country: address.country || 'Australia'
  };
}

/**
 * Normalize support network data
 * @param {Array} supports - Support network data
 * @returns {Array} Normalized supports
 */
export function normalizeSupports(supports) {
  if (!Array.isArray(supports)) return [];
  
  return supports.map(support => ({
    id: support.id || `support-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    name: support.name || '',
    relationship: support.relationship || '',
    isPrimary: !!support.is_primary || !!support.isPrimary,
    contactDetails: {
      email: support.email || '',
      phone: support.phone || '',
      mobile: support.mobile || ''
    }
  }));
}

/**
 * Format currency amount for display
 * @param {number} amount - Amount to format
 * @param {string} currency - Currency code (default: AUD)
 * @returns {string} Formatted currency string
 */
export function formatCurrency(amount, currency = 'AUD') {
  return new Intl.NumberFormat('en-AU', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2
  }).format(amount || 0);
}

/**
 * Format date for display
 * @param {Date|string} date - Date to format
 * @param {Object} options - Intl.DateTimeFormat options
 * @returns {string} Formatted date string
 */
export function formatDate(date, options = {}) {
  if (!date) return '';
  
  const defaultOptions = {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  };
  
  const dateObj = date instanceof Date ? date : new Date(date);
  
  return new Intl.DateTimeFormat('en-AU', { ...defaultOptions, ...options }).format(dateObj);
}

/**
 * Calculate the percentage of budget spent
 * @param {number} spent - Amount spent
 * @param {number} allocated - Amount allocated
 * @returns {number} Percentage spent (0-100)
 */
export function calculateBudgetPercentage(spent, allocated) {
  if (!allocated || allocated <= 0) return 0;
  const percentage = (spent / allocated) * 100;
  return Math.min(Math.max(percentage, 0), 100);
}

/**
 * Generate a plan summary for display
 * @param {Object} plan - Normalized plan data
 * @returns {Object} Plan summary
 */
export function generatePlanSummary(plan) {
  if (!plan) return null;
  
  const totalFunding = plan.totalFunding || calculateTotalFunding(plan.budgets || []);
  const spentPercentage = calculateBudgetPercentage(totalFunding.spent, totalFunding.allocated);
  const daysRemaining = calculateDaysRemaining(plan.endDate);
  const timeElapsedPercentage = calculateTimeElapsedPercentage(plan.startDate, plan.endDate);
  
  return {
    planId: plan.id,
    participantId: plan.participantId,
    startDate: formatDate(plan.startDate),
    endDate: formatDate(plan.endDate),
    daysRemaining,
    totalAllocated: formatCurrency(totalFunding.allocated),
    totalSpent: formatCurrency(totalFunding.spent),
    totalAvailable: formatCurrency(totalFunding.available),
    spentPercentage,
    timeElapsedPercentage,
    budgetStatus: determineBudgetStatus(spentPercentage, timeElapsedPercentage),
    goalCount: (plan.goals || []).length,
    supportCategories: extractSupportCategories(plan.budgets || [])
  };
}

/**
 * Calculate days remaining in a plan
 * @param {Date|string} endDate - Plan end date
 * @returns {number} Days remaining
 */
export function calculateDaysRemaining(endDate) {
  if (!endDate) return 0;
  
  const end = endDate instanceof Date ? endDate : new Date(endDate);
  const now = new Date();
  
  const diffTime = end.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return Math.max(diffDays, 0);
}

/**
 * Calculate percentage of time elapsed in a plan
 * @param {Date|string} startDate - Plan start date
 * @param {Date|string} endDate - Plan end date
 * @returns {number} Percentage of time elapsed (0-100)
 */
export function calculateTimeElapsedPercentage(startDate, endDate) {
  if (!startDate || !endDate) return 0;
  
  const start = startDate instanceof Date ? startDate : new Date(startDate);
  const end = endDate instanceof Date ? endDate : new Date(endDate);
  const now = new Date();
  
  const totalDuration = end.getTime() - start.getTime();
  const elapsed = now.getTime() - start.getTime();
  
  if (totalDuration <= 0) return 0;
  
  const percentage = (elapsed / totalDuration) * 100;
  return Math.min(Math.max(percentage, 0), 100);
}

/**
 * Determine budget status based on spending and time elapsed
 * @param {number} spentPercentage - Percentage of budget spent
 * @param {number} timeElapsedPercentage - Percentage of time elapsed
 * @returns {string} Budget status
 */
export function determineBudgetStatus(spentPercentage, timeElapsedPercentage) {
  const difference = spentPercentage - timeElapsedPercentage;
  
  if (difference > 15) {
    return 'overspending';
  } else if (difference < -15) {
    return 'underspending';
  } else {
    return 'on-track';
  }
}

/**
 * Extract support categories from budgets
 * @param {Array} budgets - Budget data
 * @returns {Array} Support categories
 */
export function extractSupportCategories(budgets) {
  if (!Array.isArray(budgets)) return [];
  
  const categories = {};
  
  budgets.forEach(budget => {
    const category = budget.category || 'Uncategorized';
    
    if (!categories[category]) {
      categories[category] = {
        name: category,
        allocated: 0,
        spent: 0,
        available: 0
      };
    }
    
    categories[category].allocated += parseFloat(budget.allocated || 0);
    categories[category].spent += parseFloat(budget.spent || 0);
    categories[category].available += parseFloat(budget.available || 0);
  });
  
  return Object.values(categories);
}

/**
 * Convert API error responses to standardized format
 * @param {Error|Object} error - Error object or API error response
 * @returns {Object} Standardized error object
 */
export function normalizeApiError(error) {
  // Handle network or JavaScript errors
  if (error instanceof Error) {
    return {
      code: 'UNKNOWN_ERROR',
      message: error.message,
      details: error.stack,
      originalError: error
    };
  }
  
  // Handle API error responses
  if (error.status && error.data) {
    return {
      code: error.data.code || `HTTP_${error.status}`,
      message: error.data.message || 'An API error occurred',
      details: error.data.details || error.data,
      status: error.status,
      originalError: error
    };
  }
  
  // Handle other error formats
  return {
    code: error.code || 'UNKNOWN_ERROR',
    message: error.message || 'An unknown error occurred',
    details: error.details || error,
    originalError: error
  };
}
