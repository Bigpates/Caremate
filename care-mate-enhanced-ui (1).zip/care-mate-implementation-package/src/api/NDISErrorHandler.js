/**
 * Care Mate - NDIS Error Handler
 * 
 * This module provides enhanced error handling for NDIS API operations,
 * including standardized error formatting, logging, and recovery strategies.
 */

/**
 * Error codes for NDIS API operations
 */
export const ERROR_CODES = {
  // Authentication errors
  AUTH_FAILED: 'AUTH_FAILED',
  TOKEN_EXPIRED: 'TOKEN_EXPIRED',
  UNAUTHORIZED: 'UNAUTHORIZED',
  
  // Network errors
  NETWORK_ERROR: 'NETWORK_ERROR',
  TIMEOUT: 'TIMEOUT',
  SERVER_UNAVAILABLE: 'SERVER_UNAVAILABLE',
  
  // Data errors
  INVALID_REQUEST: 'INVALID_REQUEST',
  RESOURCE_NOT_FOUND: 'RESOURCE_NOT_FOUND',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  
  // Rate limiting
  RATE_LIMITED: 'RATE_LIMITED',
  
  // Unknown errors
  UNKNOWN_ERROR: 'UNKNOWN_ERROR'
};

/**
 * NDIS Error Handler class
 * Provides methods for handling and normalizing API errors
 */
class NDISErrorHandler {
  constructor(config = {}) {
    // Default configuration
    this.config = {
      logErrors: true,
      enableRetry: true,
      maxRetries: 3,
      retryDelay: 1000, // 1 second
      retryStatusCodes: [408, 429, 500, 502, 503, 504],
      ...config
    };
    
    // Error log
    this.errorLog = [];
    
    // Bind methods
    this.handleError = this.handleError.bind(this);
    this.normalizeError = this.normalizeError.bind(this);
    this.logError = this.logError.bind(this);
    this.getErrorLog = this.getErrorLog.bind(this);
    this.clearErrorLog = this.clearErrorLog.bind(this);
    this.shouldRetry = this.shouldRetry.bind(this);
    this.getRetryDelay = this.getRetryDelay.bind(this);
  }
  
  /**
   * Handle an API error
   * @param {Error|Object} error - Error object or API error response
   * @param {Object} context - Error context information
   * @returns {Object} Normalized error object
   */
  handleError(error, context = {}) {
    // Normalize the error
    const normalizedError = this.normalizeError(error, context);
    
    // Log the error if enabled
    if (this.config.logErrors) {
      this.logError(normalizedError);
    }
    
    return normalizedError;
  }
  
  /**
   * Normalize an API error to a standard format
   * @param {Error|Object} error - Error object or API error response
   * @param {Object} context - Error context information
   * @returns {Object} Normalized error object
   */
  normalizeError(error, context = {}) {
    // Default normalized error structure
    const normalizedError = {
      code: ERROR_CODES.UNKNOWN_ERROR,
      message: 'An unknown error occurred',
      details: null,
      timestamp: new Date(),
      context: {
        endpoint: context.endpoint || null,
        method: context.method || null,
        params: context.params || null,
        ...context
      },
      originalError: error,
      retryable: false
    };
    
    // Handle JavaScript Error objects
    if (error instanceof Error) {
      normalizedError.message = error.message;
      normalizedError.details = error.stack;
      
      // Check for network errors
      if (error.name === 'TypeError' && error.message.includes('network')) {
        normalizedError.code = ERROR_CODES.NETWORK_ERROR;
        normalizedError.retryable = true;
      } else if (error.name === 'TimeoutError' || error.message.includes('timeout')) {
        normalizedError.code = ERROR_CODES.TIMEOUT;
        normalizedError.retryable = true;
      }
      
      // Fix: Ensure network-related errors are properly identified
      if (error.message.toLowerCase().includes('network') || 
          error.message.toLowerCase().includes('connection')) {
        normalizedError.code = ERROR_CODES.NETWORK_ERROR;
        normalizedError.retryable = true;
      }
    }
    // Handle API error responses
    else if (error && typeof error === 'object' && (error.status || (error.response && error.response.status))) {
      const status = error.status || (error.response && error.response.status);
      const data = error.data || (error.response && error.response.data) || {};
      
      normalizedError.details = data;
      
      // Map HTTP status codes to error codes
      switch (status) {
        case 400:
          normalizedError.code = ERROR_CODES.INVALID_REQUEST;
          normalizedError.message = data.message || 'Invalid request';
          break;
        case 401:
          normalizedError.code = ERROR_CODES.UNAUTHORIZED;
          normalizedError.message = 'Authentication required';
          break;
        case 403:
          normalizedError.code = ERROR_CODES.AUTH_FAILED;
          normalizedError.message = 'Access denied';
          break;
        case 404:
          normalizedError.code = ERROR_CODES.RESOURCE_NOT_FOUND;
          normalizedError.message = `Resource not found: ${context.endpoint || ''}`;
          break;
        case 408:
          normalizedError.code = ERROR_CODES.TIMEOUT;
          normalizedError.message = 'Request timeout';
          normalizedError.retryable = true;
          break;
        case 422:
          normalizedError.code = ERROR_CODES.VALIDATION_ERROR;
          normalizedError.message = data.message || 'Validation error';
          break;
        case 429:
          normalizedError.code = ERROR_CODES.RATE_LIMITED;
          normalizedError.message = 'Rate limit exceeded';
          normalizedError.retryable = true;
          break;
        case 500:
        case 502:
        case 503:
        case 504:
          normalizedError.code = ERROR_CODES.SERVER_UNAVAILABLE;
          normalizedError.message = 'Server error';
          normalizedError.retryable = true;
          break;
        default:
          normalizedError.message = data.message || `HTTP error ${status}`;
      }
    }
    // Handle other error formats
    else if (error && typeof error === 'object') {
      if (error.code) {
        normalizedError.code = error.code;
      }
      if (error.message) {
        normalizedError.message = error.message;
      }
      if (error.details) {
        normalizedError.details = error.details;
      }
    }
    
    return normalizedError;
  }
  
  /**
   * Log an error to the error log
   * @param {Object} error - Normalized error object
   */
  logError(error) {
    // Add to in-memory log
    this.errorLog.push(error);
    
    // Trim log if it gets too large
    if (this.errorLog.length > 100) {
      this.errorLog = this.errorLog.slice(-100);
    }
    
    // Log to console
    console.error(`[NDIS API Error] ${error.code}: ${error.message}`, {
      endpoint: error.context.endpoint,
      details: error.details
    });
    
    // TODO: Add remote logging if needed
  }
  
  /**
   * Get the error log
   * @param {number} limit - Maximum number of errors to return
   * @returns {Array} Error log
   */
  getErrorLog(limit = 0) {
    if (limit > 0) {
      return this.errorLog.slice(-limit);
    }
    
    return [...this.errorLog];
  }
  
  /**
   * Clear the error log
   */
  clearErrorLog() {
    this.errorLog = [];
  }
  
  /**
   * Determine if a request should be retried based on the error
   * @param {Object} error - Normalized error object
   * @param {number} attempts - Number of attempts made so far
   * @returns {boolean} Whether the request should be retried
   */
  shouldRetry(error, attempts) {
    if (!this.config.enableRetry) {
      return false;
    }
    
    if (attempts >= this.config.maxRetries) {
      return false;
    }
    
    // Check if error is retryable
    return error.retryable;
  }
  
  /**
   * Get the delay before retrying a request
   * @param {Object} error - Normalized error object
   * @param {number} attempts - Number of attempts made so far
   * @returns {number} Delay in milliseconds
   */
  getRetryDelay(error, attempts) {
    // Use Retry-After header if available (for rate limiting)
    if (error.code === ERROR_CODES.RATE_LIMITED && 
        error.originalError && 
        error.originalError.headers && 
        error.originalError.headers.get) {
      const retryAfter = parseInt(error.originalError.headers.get('Retry-After') || '0', 10);
      
      if (retryAfter > 0) {
        return retryAfter * 1000; // Convert to milliseconds
      }
    }
    
    // Use exponential backoff
    return this.config.retryDelay * Math.pow(2, attempts - 1);
  }
  
  /**
   * Create a user-friendly error message
   * @param {Object} error - Normalized error object
   * @returns {string} User-friendly error message
   */
  getUserFriendlyMessage(error) {
    switch (error.code) {
      case ERROR_CODES.NETWORK_ERROR:
        return 'Unable to connect to the NDIS server. Please check your internet connection and try again.';
      
      case ERROR_CODES.TIMEOUT:
        return 'The request to the NDIS server timed out. Please try again later.';
      
      case ERROR_CODES.SERVER_UNAVAILABLE:
        return 'The NDIS server is currently unavailable. Please try again later.';
      
      case ERROR_CODES.RATE_LIMITED:
        return 'Too many requests have been made. Please wait a moment and try again.';
      
      case ERROR_CODES.RESOURCE_NOT_FOUND:
        return 'The requested information could not be found. Please check your details and try again.';
      
      case ERROR_CODES.VALIDATION_ERROR:
        return 'There was a problem with the information provided. Please check your details and try again.';
      
      case ERROR_CODES.AUTH_FAILED:
      case ERROR_CODES.UNAUTHORIZED:
      case ERROR_CODES.TOKEN_EXPIRED:
        return 'Your session has expired or you do not have permission to access this information. Please log in again.';
      
      default:
        return 'An unexpected error occurred. Please try again later.';
    }
  }
  
  /**
   * Get recovery suggestions for an error
   * @param {Object} error - Normalized error object
   * @returns {Array} Recovery suggestions
   */
  getRecoverySuggestions(error) {
    const suggestions = [];
    
    switch (error.code) {
      case ERROR_CODES.NETWORK_ERROR:
        suggestions.push('Check your internet connection');
        suggestions.push('Try again in a few minutes');
        break;
      
      case ERROR_CODES.TIMEOUT:
      case ERROR_CODES.SERVER_UNAVAILABLE:
        suggestions.push('Try again later');
        suggestions.push('Contact support if the problem persists');
        break;
      
      case ERROR_CODES.RATE_LIMITED:
        suggestions.push('Wait a few minutes before trying again');
        suggestions.push('Reduce the frequency of requests');
        break;
      
      case ERROR_CODES.RESOURCE_NOT_FOUND:
        suggestions.push('Check that the ID or reference is correct');
        suggestions.push('Verify that the resource exists');
        break;
      
      case ERROR_CODES.VALIDATION_ERROR:
        suggestions.push('Check the input data for errors');
        suggestions.push('Ensure all required fields are provided');
        break;
      
      case ERROR_CODES.AUTH_FAILED:
      case ERROR_CODES.UNAUTHORIZED:
      case ERROR_CODES.TOKEN_EXPIRED:
        suggestions.push('Log in again');
        suggestions.push('Check your permissions');
        break;
      
      default:
        suggestions.push('Try again later');
        suggestions.push('Contact support if the problem persists');
    }
    
    return suggestions;
  }
}

// Export the error handler
export default NDISErrorHandler;
