/**
 * Care Mate - API Integration Module
 * 
 * This module integrates all API-related components and provides a unified
 * interface for interacting with NDIS APIs throughout the application.
 */

import NDISApiClient from './NDISApiClient.js';
import NDISApiCacheManager from './NDISApiCacheManager.js';
import * as NDISDataTransformer from './NDISDataTransformer.js';

/**
 * NDIS API Integration class
 * Provides a unified interface for API operations with caching and data transformation
 */
class NDISApiIntegration {
  constructor(config = {}) {
    // Create API client
    this.client = new NDISApiClient(config.apiClient);
    
    // Create cache manager
    this.cacheManager = new NDISApiCacheManager(config.cacheManager);
    
    // Store config
    this.config = {
      enableCache: true,
      defaultCacheTTL: 5 * 60 * 1000, // 5 minutes
      ...config
    };
    
    // Bind methods
    this.getParticipantDetails = this.getParticipantDetails.bind(this);
    this.getParticipantPlan = this.getParticipantPlan.bind(this);
    this.getParticipantPlans = this.getParticipantPlans.bind(this);
    this.getPlanBudget = this.getPlanBudget.bind(this);
    this.getPlanServices = this.getPlanServices.bind(this);
    this.getServiceProviders = this.getServiceProviders.bind(this);
    this.clearCache = this.clearCache.bind(this);
  }
  
  /**
   * Get participant details with caching and data transformation
   * @param {string} participantId - NDIS participant ID
   * @returns {Promise<Object>} Normalized participant details
   */
  async getParticipantDetails(participantId) {
    const cacheKey = `participant_${participantId}`;
    
    // Check cache first
    if (this.config.enableCache) {
      const cachedData = this.cacheManager.get(cacheKey);
      if (cachedData) {
        return cachedData;
      }
    }
    
    try {
      // Fetch from API
      const response = await this.client.getParticipantDetails(participantId);
      
      // Transform data
      const normalizedData = NDISDataTransformer.normalizeParticipantData(response.data);
      
      // Cache result
      if (this.config.enableCache) {
        this.cacheManager.set(cacheKey, normalizedData, this.config.defaultCacheTTL);
      }
      
      return normalizedData;
    } catch (error) {
      // Normalize error
      const normalizedError = NDISDataTransformer.normalizeApiError(error);
      throw normalizedError;
    }
  }
  
  /**
   * Get participant plan with caching and data transformation
   * @param {string} participantId - NDIS participant ID
   * @param {string} planId - NDIS plan ID
   * @returns {Promise<Object>} Normalized plan details
   */
  async getParticipantPlan(participantId, planId) {
    const cacheKey = `plan_${participantId}_${planId}`;
    
    // Check cache first
    if (this.config.enableCache) {
      const cachedData = this.cacheManager.get(cacheKey);
      if (cachedData) {
        return cachedData;
      }
    }
    
    try {
      // Fetch from API
      const response = await this.client.getParticipantPlan(participantId, planId);
      
      // Transform data
      const normalizedData = NDISDataTransformer.normalizePlanData(response.data);
      
      // Cache result
      if (this.config.enableCache) {
        this.cacheManager.set(cacheKey, normalizedData, this.config.defaultCacheTTL);
      }
      
      return normalizedData;
    } catch (error) {
      // Normalize error
      const normalizedError = NDISDataTransformer.normalizeApiError(error);
      throw normalizedError;
    }
  }
  
  /**
   * Get participant plans with caching and data transformation
   * @param {string} participantId - NDIS participant ID
   * @returns {Promise<Array>} Normalized list of plans
   */
  async getParticipantPlans(participantId) {
    const cacheKey = `plans_${participantId}`;
    
    // Check cache first
    if (this.config.enableCache) {
      const cachedData = this.cacheManager.get(cacheKey);
      if (cachedData) {
        return cachedData;
      }
    }
    
    try {
      // Fetch from API
      const response = await this.client.getParticipantPlans(participantId);
      
      // Transform data
      const normalizedData = Array.isArray(response.data) 
        ? response.data.map(NDISDataTransformer.normalizePlanData)
        : [];
      
      // Cache result
      if (this.config.enableCache) {
        this.cacheManager.set(cacheKey, normalizedData, this.config.defaultCacheTTL);
      }
      
      return normalizedData;
    } catch (error) {
      // Normalize error
      const normalizedError = NDISDataTransformer.normalizeApiError(error);
      throw normalizedError;
    }
  }
  
  /**
   * Get plan budget with caching and data transformation
   * @param {string} participantId - NDIS participant ID
   * @param {string} planId - NDIS plan ID
   * @returns {Promise<Object>} Normalized budget details
   */
  async getPlanBudget(participantId, planId) {
    const cacheKey = `budget_${participantId}_${planId}`;
    
    // Check cache first
    if (this.config.enableCache) {
      const cachedData = this.cacheManager.get(cacheKey);
      if (cachedData) {
        return cachedData;
      }
    }
    
    try {
      // Fetch from API
      const response = await this.client.getPlanBudget(participantId, planId);
      
      // Transform data
      const normalizedData = NDISDataTransformer.normalizeBudgets(response.data);
      
      // Cache result
      if (this.config.enableCache) {
        this.cacheManager.set(cacheKey, normalizedData, this.config.defaultCacheTTL);
      }
      
      return normalizedData;
    } catch (error) {
      // Normalize error
      const normalizedError = NDISDataTransformer.normalizeApiError(error);
      throw normalizedError;
    }
  }
  
  /**
   * Get plan services with caching and data transformation
   * @param {string} participantId - NDIS participant ID
   * @param {string} planId - NDIS plan ID
   * @returns {Promise<Array>} Normalized services details
   */
  async getPlanServices(participantId, planId) {
    const cacheKey = `services_${participantId}_${planId}`;
    
    // Check cache first
    if (this.config.enableCache) {
      const cachedData = this.cacheManager.get(cacheKey);
      if (cachedData) {
        return cachedData;
      }
    }
    
    try {
      // Fetch from API
      const response = await this.client.getPlanServices(participantId, planId);
      
      // Transform data
      const normalizedData = Array.isArray(response.data)
        ? response.data.map(NDISDataTransformer.normalizeSupport)
        : [];
      
      // Cache result
      if (this.config.enableCache) {
        this.cacheManager.set(cacheKey, normalizedData, this.config.defaultCacheTTL);
      }
      
      return normalizedData;
    } catch (error) {
      // Normalize error
      const normalizedError = NDISDataTransformer.normalizeApiError(error);
      throw normalizedError;
    }
  }
  
  /**
   * Get service providers with caching and data transformation
   * @param {Object} filters - Search filters
   * @returns {Promise<Array>} Normalized list of service providers
   */
  async getServiceProviders(filters = {}) {
    // Create cache key based on filters
    const filterString = Object.entries(filters)
      .sort(([keyA], [keyB]) => keyA.localeCompare(keyB))
      .map(([key, value]) => `${key}=${value}`)
      .join('&');
    
    const cacheKey = `providers_${filterString || 'all'}`;
    
    // Check cache first
    if (this.config.enableCache) {
      const cachedData = this.cacheManager.get(cacheKey);
      if (cachedData) {
        return cachedData;
      }
    }
    
    try {
      // Fetch from API
      const response = await this.client.getServiceProviders(filters);
      
      // Transform data (assuming a simple structure for providers)
      const normalizedData = Array.isArray(response.data)
        ? response.data.map(provider => ({
            id: provider.provider_id || provider.id,
            name: provider.name || '',
            registrationGroups: provider.registration_groups || provider.registrationGroups || [],
            contactDetails: {
              email: provider.email || '',
              phone: provider.phone || '',
              website: provider.website || ''
            },
            address: NDISDataTransformer.normalizeAddress(provider.address || {})
          }))
        : [];
      
      // Cache result
      if (this.config.enableCache) {
        this.cacheManager.set(cacheKey, normalizedData, this.config.defaultCacheTTL);
      }
      
      return normalizedData;
    } catch (error) {
      // Normalize error
      const normalizedError = NDISDataTransformer.normalizeApiError(error);
      throw normalizedError;
    }
  }
  
  /**
   * Clear all cached data
   */
  clearCache() {
    this.cacheManager.clear();
  }
  
  /**
   * Dispose of resources
   */
  dispose() {
    this.cacheManager.dispose();
  }
}

// Create and export a singleton instance
const apiIntegration = new NDISApiIntegration();

export default apiIntegration;

// Also export individual components for direct use if needed
export {
  NDISApiClient,
  NDISApiCacheManager,
  NDISDataTransformer
};
