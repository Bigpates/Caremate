/**
 * Care Mate - NDIS Participant Profile Manager
 * 
 * This module provides functionality for managing NDIS participant profiles,
 * including storage, retrieval, and synchronization of participant data.
 * Updated to use the storage adapter for cross-environment compatibility.
 */

import NDISStorageAdapter from './NDISStorageAdapter.js';

/**
 * Participant Profile Manager for NDIS participants
 */
class NDISParticipantProfileManager {
  constructor(config = {}) {
    // Default configuration
    this.config = {
      storageKey: 'ndis_participant_profiles',
      maxProfiles: 100,
      syncEnabled: true,
      syncInterval: 3600000, // 1 hour in milliseconds
      ...config
    };
    
    // Initialize profiles storage
    this.profiles = new Map();
    this.metaData = new Map();
    
    // Initialize storage adapter
    this.storage = new NDISStorageAdapter({
      storageKey: this.config.storageKey
    });
    
    // Bind methods
    this.getProfile = this.getProfile.bind(this);
    this.saveProfile = this.saveProfile.bind(this);
    this.updateProfile = this.updateProfile.bind(this);
    this.deleteProfile = this.deleteProfile.bind(this);
    this.getAllProfiles = this.getAllProfiles.bind(this);
    this.searchProfiles = this.searchProfiles.bind(this);
    this.loadFromStorage = this.loadFromStorage.bind(this);
    this.saveToStorage = this.saveToStorage.bind(this);
    this.syncWithServer = this.syncWithServer.bind(this);
    
    // Load profiles from storage
    this.loadFromStorage();
    
    // Set up periodic sync if enabled
    if (this.config.syncEnabled) {
      this.syncInterval = setInterval(() => {
        this.syncWithServer();
      }, this.config.syncInterval);
    }
  }
  
  /**
   * Get a participant profile
   * @param {string} participantId - NDIS participant ID
   * @returns {Object|null} Participant profile or null if not found
   */
  getProfile(participantId) {
    if (!participantId) {
      return null;
    }
    
    // Check if profile exists
    if (this.profiles.has(participantId)) {
      const profile = this.profiles.get(participantId);
      
      // Update last accessed time
      this.updateMetaData(participantId, { lastAccessed: Date.now() });
      
      return profile;
    }
    
    return null;
  }
  
  /**
   * Save a new participant profile
   * @param {Object} profile - Participant profile data
   * @returns {boolean} Success status
   */
  saveProfile(profile) {
    if (!profile || !profile.id) {
      console.error('Cannot save profile: Missing profile ID');
      return false;
    }
    
    // Ensure we don't exceed max profiles
    if (this.profiles.size >= this.config.maxProfiles && !this.profiles.has(profile.id)) {
      this.evictLeastRecentlyUsed();
    }
    
    // Add created timestamp if not present
    if (!profile.createdAt) {
      profile.createdAt = new Date();
    }
    
    // Add updated timestamp
    profile.updatedAt = new Date();
    
    // Store profile
    this.profiles.set(profile.id, profile);
    
    // Initialize or update metadata
    this.updateMetaData(profile.id, {
      createdAt: Date.now(),
      lastAccessed: Date.now(),
      lastUpdated: Date.now(),
      syncStatus: 'pending'
    });
    
    // Save to storage
    this.saveToStorage();
    
    // Trigger sync if enabled
    if (this.config.syncEnabled) {
      this.syncWithServer();
    }
    
    return true;
  }
  
  /**
   * Update an existing participant profile
   * @param {string} participantId - NDIS participant ID
   * @param {Object} updates - Profile updates
   * @returns {Object|null} Updated profile or null if not found
   */
  updateProfile(participantId, updates) {
    if (!participantId || !updates) {
      return null;
    }
    
    // Check if profile exists
    if (!this.profiles.has(participantId)) {
      console.error(`Cannot update profile: Profile with ID ${participantId} not found`);
      return null;
    }
    
    // Get existing profile
    const profile = this.profiles.get(participantId);
    
    // Apply updates
    const updatedProfile = {
      ...profile,
      ...updates,
      updatedAt: new Date()
    };
    
    // Store updated profile
    this.profiles.set(participantId, updatedProfile);
    
    // Update metadata
    this.updateMetaData(participantId, {
      lastAccessed: Date.now(),
      lastUpdated: Date.now(),
      syncStatus: 'pending'
    });
    
    // Save to storage
    this.saveToStorage();
    
    // Trigger sync if enabled
    if (this.config.syncEnabled) {
      this.syncWithServer();
    }
    
    return updatedProfile;
  }
  
  /**
   * Delete a participant profile
   * @param {string} participantId - NDIS participant ID
   * @returns {boolean} Success status
   */
  deleteProfile(participantId) {
    if (!participantId) {
      return false;
    }
    
    // Check if profile exists
    if (!this.profiles.has(participantId)) {
      console.error(`Cannot delete profile: Profile with ID ${participantId} not found`);
      return false;
    }
    
    // Delete profile and metadata
    this.profiles.delete(participantId);
    this.metaData.delete(participantId);
    
    // Save to storage
    this.saveToStorage();
    
    return true;
  }
  
  /**
   * Get all participant profiles
   * @param {Object} options - Options for sorting and filtering
   * @returns {Array} Array of participant profiles
   */
  getAllProfiles(options = {}) {
    const profiles = Array.from(this.profiles.values());
    
    // Apply sorting if specified
    if (options.sortBy) {
      const direction = options.sortOrder === 'desc' ? -1 : 1;
      
      profiles.sort((a, b) => {
        const valueA = this.getNestedProperty(a, options.sortBy);
        const valueB = this.getNestedProperty(b, options.sortBy);
        
        if (valueA === undefined && valueB === undefined) {
          return 0;
        } else if (valueA === undefined) {
          return direction;
        } else if (valueB === undefined) {
          return -direction;
        } else if (valueA instanceof Date && valueB instanceof Date) {
          return direction * (valueA.getTime() - valueB.getTime());
        } else if (typeof valueA === 'string' && typeof valueB === 'string') {
          return direction * valueA.localeCompare(valueB);
        } else {
          return direction * (valueA - valueB);
        }
      });
    }
    
    return profiles;
  }
  
  /**
   * Search participant profiles
   * @param {Object} criteria - Search criteria
   * @returns {Array} Matching profiles
   */
  searchProfiles(criteria = {}) {
    if (!criteria || Object.keys(criteria).length === 0) {
      return this.getAllProfiles();
    }
    
    const profiles = this.getAllProfiles();
    
    return profiles.filter(profile => {
      // Check each criterion
      return Object.entries(criteria).every(([key, value]) => {
        const profileValue = this.getNestedProperty(profile, key);
        
        if (profileValue === undefined) {
          return false;
        }
        
        // Handle different value types
        if (typeof value === 'string') {
          return String(profileValue).toLowerCase().includes(value.toLowerCase());
        } else if (value instanceof Date) {
          return profileValue instanceof Date && profileValue.getTime() === value.getTime();
        } else if (Array.isArray(value)) {
          return Array.isArray(profileValue) && value.some(v => profileValue.includes(v));
        } else {
          return profileValue === value;
        }
      });
    });
  }
  
  /**
   * Update metadata for a profile
   * @param {string} participantId - NDIS participant ID
   * @param {Object} updates - Metadata updates
   */
  updateMetaData(participantId, updates) {
    const currentMeta = this.metaData.get(participantId) || {};
    
    this.metaData.set(participantId, {
      ...currentMeta,
      ...updates
    });
  }
  
  /**
   * Evict the least recently used profile
   */
  evictLeastRecentlyUsed() {
    let oldestId = null;
    let oldestAccess = Infinity;
    
    // Find the least recently accessed profile
    this.metaData.forEach((meta, id) => {
      if (meta.lastAccessed < oldestAccess) {
        oldestAccess = meta.lastAccessed;
        oldestId = id;
      }
    });
    
    // Delete the oldest profile
    if (oldestId) {
      this.profiles.delete(oldestId);
      this.metaData.delete(oldestId);
    }
  }
  
  /**
   * Get a nested property from an object using dot notation
   * @param {Object} obj - Object to get property from
   * @param {string} path - Property path in dot notation
   * @returns {any} Property value or undefined if not found
   */
  getNestedProperty(obj, path) {
    return path.split('.').reduce((current, key) => {
      return current && current[key] !== undefined ? current[key] : undefined;
    }, obj);
  }
  
  /**
   * Load profiles from storage
   */
  loadFromStorage() {
    try {
      const storedData = this.storage.getItem('profiles_data');
      
      if (storedData) {
        const { profiles, metaData } = storedData;
        
        // Restore profiles and metadata
        Object.entries(profiles).forEach(([id, profile]) => {
          // Convert date strings back to Date objects
          if (profile.createdAt) profile.createdAt = new Date(profile.createdAt);
          if (profile.updatedAt) profile.updatedAt = new Date(profile.updatedAt);
          if (profile.dateOfBirth) profile.dateOfBirth = new Date(profile.dateOfBirth);
          
          // Convert plan dates
          if (profile.currentPlan) {
            if (profile.currentPlan.startDate) profile.currentPlan.startDate = new Date(profile.currentPlan.startDate);
            if (profile.currentPlan.endDate) profile.currentPlan.endDate = new Date(profile.currentPlan.endDate);
          }
          
          this.profiles.set(id, profile);
        });
        
        Object.entries(metaData).forEach(([id, meta]) => {
          this.metaData.set(id, meta);
        });
      }
    } catch (error) {
      console.error('Failed to load profiles from storage:', error);
      // Reset profiles if loading fails
      this.profiles.clear();
      this.metaData.clear();
    }
  }
  
  /**
   * Save profiles to storage
   */
  saveToStorage() {
    try {
      // Convert Maps to objects for JSON serialization
      const profilesObj = {};
      this.profiles.forEach((profile, id) => {
        profilesObj[id] = profile;
      });
      
      const metaDataObj = {};
      this.metaData.forEach((meta, id) => {
        metaDataObj[id] = meta;
      });
      
      // Store in storage adapter
      this.storage.setItem('profiles_data', {
        profiles: profilesObj,
        metaData: metaDataObj
      });
    } catch (error) {
      console.error('Failed to save profiles to storage:', error);
    }
  }
  
  /**
   * Synchronize profiles with server
   * @returns {Promise<Object>} Sync result
   */
  async syncWithServer() {
    if (!this.config.syncEnabled) {
      return { success: false, message: 'Sync is disabled' };
    }
    
    try {
      // Find profiles that need syncing
      const pendingProfiles = [];
      
      this.metaData.forEach((meta, id) => {
        if (meta.syncStatus === 'pending') {
          pendingProfiles.push({
            id,
            profile: this.profiles.get(id),
            meta
          });
        }
      });
      
      if (pendingProfiles.length === 0) {
        return { success: true, message: 'No profiles need syncing' };
      }
      
      // TODO: Implement actual server sync
      // This would typically involve API calls to sync data with the server
      
      // For now, just mark all as synced
      pendingProfiles.forEach(({ id }) => {
        this.updateMetaData(id, {
          syncStatus: 'synced',
          lastSynced: Date.now()
        });
      });
      
      // Save updated metadata
      this.saveToStorage();
      
      return {
        success: true,
        message: `Synced ${pendingProfiles.length} profiles`,
        syncedProfiles: pendingProfiles.map(p => p.id)
      };
    } catch (error) {
      console.error('Profile sync failed:', error);
      return {
        success: false,
        message: 'Sync failed',
        error: error.message
      };
    }
  }
  
  /**
   * Dispose of resources
   */
  dispose() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
    }
  }
  
  /**
   * Create a new participant profile
   * @param {Object} participantData - Basic participant data
   * @returns {Object} Created profile
   */
  createProfile(participantData) {
    if (!participantData || !participantData.id) {
      throw new Error('Cannot create profile: Missing participant ID');
    }
    
    // Create a new profile with required fields
    const profile = {
      id: participantData.id,
      ndisNumber: participantData.ndisNumber || '',
      firstName: participantData.firstName || '',
      lastName: participantData.lastName || '',
      dateOfBirth: participantData.dateOfBirth ? new Date(participantData.dateOfBirth) : null,
      gender: participantData.gender || '',
      contactDetails: participantData.contactDetails || {
        email: '',
        phone: '',
        mobile: '',
        address: {
          street: '',
          suburb: '',
          state: '',
          postcode: '',
          country: 'Australia'
        }
      },
      currentPlan: null,
      previousPlans: [],
      supportNetwork: [],
      preferences: {},
      notes: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    // Save the profile
    this.saveProfile(profile);
    
    return profile;
  }
  
  /**
   * Add a note to a participant profile
   * @param {string} participantId - NDIS participant ID
   * @param {string} note - Note content
   * @param {string} category - Note category
   * @returns {Object|null} Updated profile or null if not found
   */
  addNote(participantId, note, category = 'general') {
    if (!participantId || !note) {
      return null;
    }
    
    const profile = this.getProfile(participantId);
    
    if (!profile) {
      return null;
    }
    
    // Ensure notes array exists
    if (!profile.notes) {
      profile.notes = [];
    }
    
    // Add new note
    const newNote = {
      id: `note-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      content: note,
      category,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    profile.notes.push(newNote);
    
    // Update profile
    return this.updateProfile(participantId, { notes: profile.notes });
  }
  
  /**
   * Add or update a plan in a participant profile
   * @param {string} participantId - NDIS participant ID
   * @param {Object} planData - Plan data
   * @param {boolean} isCurrent - Whether this is the current plan
   * @returns {Object|null} Updated profile or null if not found
   */
  updatePlan(participantId, planData, isCurrent = true) {
    if (!participantId || !planData || !planData.id) {
      return null;
    }
    
    const profile = this.getProfile(participantId);
    
    if (!profile) {
      return null;
    }
    
    // Normalize dates
    if (planData.startDate) planData.startDate = new Date(planData.startDate);
    if (planData.endDate) planData.endDate = new Date(planData.endDate);
    
    // If this is the current plan, update it
    if (isCurrent) {
      // If there's an existing current plan, move it to previous plans
      if (profile.currentPlan && profile.currentPlan.id !== planData.id) {
        if (!profile.previousPlans) {
          profile.previousPlans = [];
        }
        
        // Only add to previous plans if not already there
        const existingIndex = profile.previousPlans.findIndex(p => p.id === profile.currentPlan.id);
        if (existingIndex === -1) {
          profile.previousPlans.push(profile.currentPlan);
        }
      }
      
      // Update current plan
      return this.updateProfile(participantId, { currentPlan: planData });
    } else {
      // This is a previous plan, update it in the previous plans array
      if (!profile.previousPlans) {
        profile.previousPlans = [];
      }
      
      const existingIndex = profile.previousPlans.findIndex(p => p.id === planData.id);
      
      if (existingIndex !== -1) {
        // Update existing plan
        profile.previousPlans[existingIndex] = planData;
      } else {
        // Add new previous plan
        profile.previousPlans.push(planData);
      }
      
      // Sort previous plans by start date (newest first)
      profile.previousPlans.sort((a, b) => {
        const dateA = a.startDate instanceof Date ? a.startDate : new Date(a.startDate);
        const dateB = b.startDate instanceof Date ? b.startDate : new Date(b.startDate);
        return dateB.getTime() - dateA.getTime();
      });
      
      // Update profile
      return this.updateProfile(participantId, { previousPlans: profile.previousPlans });
    }
  }
  
  /**
   * Update support network for a participant
   * @param {string} participantId - NDIS participant ID
   * @param {Array} supportNetwork - Support network data
   * @returns {Object|null} Updated profile or null if not found
   */
  updateSupportNetwork(participantId, supportNetwork) {
    if (!participantId || !Array.isArray(supportNetwork)) {
      return null;
    }
    
    return this.updateProfile(participantId, { supportNetwork });
  }
  
  /**
   * Update preferences for a participant
   * @param {string} participantId - NDIS participant ID
   * @param {Object} preferences - Participant preferences
   * @returns {Object|null} Updated profile or null if not found
   */
  updatePreferences(participantId, preferences) {
    if (!participantId || !preferences) {
      return null;
    }
    
    const profile = this.getProfile(participantId);
    
    if (!profile) {
      return null;
    }
    
    // Merge with existing preferences
    const updatedPreferences = {
      ...(profile.preferences || {}),
      ...preferences
    };
    
    return this.updateProfile(participantId, { preferences: updatedPreferences });
  }
}

// Export the participant profile manager
export default NDISParticipantProfileManager;
