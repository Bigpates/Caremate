/**
 * Care Mate - NDIS API Client
 * 
 * This module provides a centralized client for interacting with NDIS APIs,
 * handling authentication, request formatting, and response parsing.
 */

// API configuration
const API_CONFIG = {
  baseUrl: 'https://api.ndis.gov.au/v1',
  timeout: 30000, // 30 seconds
  retryAttempts: 3,
  retryDelay: 1000 // 1 second
};

/**
 * NDIS API Client class
 * Provides methods for interacting with NDIS APIs
 */
class NDISApiClient {
  constructor(config = {}) {
    this.config = {
      ...API_CONFIG,
      ...config
    };
    
    this.token = null;
    this.tokenExpiry = null;
    
    // Bind methods
    this.request = this.request.bind(this);
    this.authenticate = this.authenticate.bind(this);
    this.refreshToken = this.refreshToken.bind(this);
    this.isTokenValid = this.isTokenValid.bind(this);
  }
  
  /**
   * Check if the current token is valid
   * @returns {boolean} Whether the token is valid
   */
  isTokenValid() {
    if (!this.token || !this.tokenExpiry) {
      return false;
    }
    
    // Check if token is expired (with 5 minute buffer)
    const now = new Date();
    const expiryWithBuffer = new Date(this.tokenExpiry.getTime() - 5 * 60 * 1000);
    
    return now < expiryWithBuffer;
  }
  
  /**
   * Authenticate with the NDIS API
   * @param {Object} credentials - Authentication credentials
   * @returns {Promise<Object>} Authentication result
   */
  async authenticate(credentials) {
    try {
      const response = await fetch(`${this.config.baseUrl}/auth/token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(credentials)
      });
      
      if (!response.ok) {
        throw new Error(`Authentication failed: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Store token and expiry
      this.token = data.access_token;
      this.tokenExpiry = new Date(Date.now() + data.expires_in * 1000);
      
      return {
        success: true,
        token: this.token,
        expiry: this.tokenExpiry
      };
    } catch (error) {
      console.error('Authentication error:', error);
      throw error;
    }
  }
  
  /**
   * Refresh the authentication token
   * @returns {Promise<Object>} Refresh result
   */
  async refreshToken() {
    try {
      const response = await fetch(`${this.config.baseUrl}/auth/refresh`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.token}`
        }
      });
      
      if (!response.ok) {
        throw new Error(`Token refresh failed: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Store token and expiry
      this.token = data.access_token;
      this.tokenExpiry = new Date(Date.now() + data.expires_in * 1000);
      
      return {
        success: true,
        token: this.token,
        expiry: this.tokenExpiry
      };
    } catch (error) {
      console.error('Token refresh error:', error);
      throw error;
    }
  }
  
  /**
   * Make a request to the NDIS API
   * @param {string} endpoint - API endpoint
   * @param {Object} options - Request options
   * @returns {Promise<Object>} API response
   */
  async request(endpoint, options = {}) {
    // Ensure we have a valid token
    if (!this.isTokenValid()) {
      await this.refreshToken();
    }
    
    const url = endpoint.startsWith('http') ? endpoint : `${this.config.baseUrl}${endpoint}`;
    
    const requestOptions = {
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`,
        ...options.headers
      },
      timeout: options.timeout || this.config.timeout,
      ...options
    };
    
    // Add body if provided
    if (options.body) {
      requestOptions.body = JSON.stringify(options.body);
    }
    
    // Implement retry logic
    let attempts = 0;
    let lastError = null;
    
    while (attempts < this.config.retryAttempts) {
      try {
        const response = await fetch(url, requestOptions);
        
        // Handle rate limiting
        if (response.status === 429) {
          const retryAfter = parseInt(response.headers.get('Retry-After') || '1', 10);
          await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
          attempts++;
          continue;
        }
        
        // Handle authentication errors
        if (response.status === 401) {
          await this.refreshToken();
          requestOptions.headers.Authorization = `Bearer ${this.token}`;
          attempts++;
          continue;
        }
        
        // Handle other errors
        if (!response.ok) {
          throw new Error(`API request failed: ${response.status} ${response.statusText}`);
        }
        
        // Parse response
        const contentType = response.headers.get('Content-Type') || '';
        let data;
        
        if (contentType.includes('application/json')) {
          data = await response.json();
        } else {
          data = await response.text();
        }
        
        return {
          success: true,
          data,
          status: response.status,
          headers: response.headers
        };
      } catch (error) {
        lastError = error;
        console.error(`API request attempt ${attempts + 1} failed:`, error);
        
        // Wait before retrying
        await new Promise(resolve => setTimeout(resolve, this.config.retryDelay));
        attempts++;
      }
    }
    
    // All attempts failed
    throw lastError || new Error('API request failed after multiple attempts');
  }
  
  /**
   * Get participant details
   * @param {string} participantId - NDIS participant ID
   * @returns {Promise<Object>} Participant details
   */
  async getParticipantDetails(participantId) {
    return this.request(`/participants/${participantId}`);
  }
  
  /**
   * Get participant plan
   * @param {string} participantId - NDIS participant ID
   * @param {string} planId - NDIS plan ID
   * @returns {Promise<Object>} Plan details
   */
  async getParticipantPlan(participantId, planId) {
    return this.request(`/participants/${participantId}/plans/${planId}`);
  }
  
  /**
   * Get participant plans
   * @param {string} participantId - NDIS participant ID
   * @returns {Promise<Object>} List of plans
   */
  async getParticipantPlans(participantId) {
    return this.request(`/participants/${participantId}/plans`);
  }
  
  /**
   * Get plan budget
   * @param {string} participantId - NDIS participant ID
   * @param {string} planId - NDIS plan ID
   * @returns {Promise<Object>} Budget details
   */
  async getPlanBudget(participantId, planId) {
    return this.request(`/participants/${participantId}/plans/${planId}/budget`);
  }
  
  /**
   * Get plan services
   * @param {string} participantId - NDIS participant ID
   * @param {string} planId - NDIS plan ID
   * @returns {Promise<Object>} Services details
   */
  async getPlanServices(participantId, planId) {
    return this.request(`/participants/${participantId}/plans/${planId}/services`);
  }
  
  /**
   * Get service providers
   * @param {Object} filters - Search filters
   * @returns {Promise<Object>} List of service providers
   */
  async getServiceProviders(filters = {}) {
    const queryParams = new URLSearchParams();
    
    // Add filters to query params
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        queryParams.append(key, value);
      }
    });
    
    const queryString = queryParams.toString();
    const endpoint = `/providers${queryString ? `?${queryString}` : ''}`;
    
    return this.request(endpoint);
  }
  
  /**
   * Get service provider details
   * @param {string} providerId - Service provider ID
   * @returns {Promise<Object>} Provider details
   */
  async getServiceProviderDetails(providerId) {
    return this.request(`/providers/${providerId}`);
  }
  
  /**
   * Submit service booking
   * @param {Object} bookingData - Service booking data
   * @returns {Promise<Object>} Booking result
   */
  async submitServiceBooking(bookingData) {
    return this.request('/bookings', {
      method: 'POST',
      body: bookingData
    });
  }
  
  /**
   * Get service bookings
   * @param {string} participantId - NDIS participant ID
   * @returns {Promise<Object>} List of service bookings
   */
  async getServiceBookings(participantId) {
    return this.request(`/participants/${participantId}/bookings`);
  }
  
  /**
   * Submit payment request
   * @param {Object} paymentData - Payment request data
   * @returns {Promise<Object>} Payment result
   */
  async submitPaymentRequest(paymentData) {
    return this.request('/payments', {
      method: 'POST',
      body: paymentData
    });
  }
  
  /**
   * Get payment history
   * @param {string} participantId - NDIS participant ID
   * @param {Object} filters - Search filters
   * @returns {Promise<Object>} Payment history
   */
  async getPaymentHistory(participantId, filters = {}) {
    const queryParams = new URLSearchParams();
    
    // Add filters to query params
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        queryParams.append(key, value);
      }
    });
    
    const queryString = queryParams.toString();
    const endpoint = `/participants/${participantId}/payments${queryString ? `?${queryString}` : ''}`;
    
    return this.request(endpoint);
  }
}

// Export the API client
export default NDISApiClient;
