/**
 * Care Mate - NDIS API Integration Test
 * 
 * This module provides test utilities for validating the NDIS API integration,
 * including real-time updates, advanced search, participant profiles, and error handling.
 */

import NDISApiClient from './NDISApiClient.js';
import NDISApiCacheManager from './NDISApiCacheManager.js';
import * as NDISDataTransformer from './NDISDataTransformer.js';
import NDISRealTimeUpdates from './NDISRealTimeUpdates.js';
import NDISAdvancedSearch from './NDISAdvancedSearch.js';
import NDISParticipantProfileManager from './NDISParticipantProfileManager.js';
import NDISErrorHandler, { ERROR_CODES } from './NDISErrorHandler.js';

// Test data
const TEST_PARTICIPANT = {
  id: 'test-participant-001',
  ndisNumber: 'NDIS123456789',
  firstName: 'Jane',
  lastName: 'Smith',
  dateOfBirth: new Date('1985-06-15'),
  gender: 'female',
  contactDetails: {
    email: 'jane.smith@example.com',
    phone: '0412345678',
    mobile: '0412345678',
    address: {
      street: '123 Main Street',
      suburb: 'Richmond',
      state: 'VIC',
      postcode: '3121',
      country: 'Australia'
    }
  }
};

const TEST_PLAN = {
  id: 'test-plan-001',
  participantId: 'test-participant-001',
  startDate: new Date('2023-07-01'),
  endDate: new Date('2024-06-30'),
  status: 'active',
  goals: [
    {
      id: 'goal-001',
      category: 'Social and Community Participation',
      description: 'Increase participation in community activities',
      status: 'active',
      targetDate: new Date('2024-03-31'),
      achievementCriteria: 'Attending at least one community event per month',
      supports: []
    },
    {
      id: 'goal-002',
      category: 'Independence',
      description: 'Develop skills for independent living',
      status: 'active',
      targetDate: new Date('2024-06-30'),
      achievementCriteria: 'Successfully completing daily living tasks with minimal support',
      supports: []
    }
  ],
  budgets: [
    {
      id: 'budget-001',
      category: 'Core',
      subcategory: 'Assistance with Daily Life',
      allocated: 50000,
      spent: 15000,
      committed: 5000,
      available: 30000,
      managedBy: 'agency',
      supports: []
    },
    {
      id: 'budget-002',
      category: 'Capacity Building',
      subcategory: 'Improved Daily Living',
      allocated: 20000,
      spent: 5000,
      committed: 2000,
      available: 13000,
      managedBy: 'plan_managed',
      supports: []
    }
  ],
  supportCoordination: {
    allocated: 10000,
    spent: 3000,
    available: 7000,
    coordinator: {
      name: 'Sarah Johnson',
      organization: 'Support Coordination Services',
      phone: '0398765432',
      email: 'sarah.johnson@scs.example.com'
    }
  },
  totalFunding: {
    allocated: 80000,
    spent: 23000,
    committed: 7000,
    available: 50000
  }
};

const TEST_PROVIDERS = [
  {
    id: 'provider-001',
    name: 'Supportive Care Services',
    registrationGroups: ['Daily Personal Activities', 'Participation in Community'],
    serviceTypes: ['Personal Care', 'Community Access'],
    rating: 4.8,
    location: {
      latitude: -37.8136,
      longitude: 144.9631
    },
    contactDetails: {
      email: 'info@supportivecare.example.com',
      phone: '0399887766',
      website: 'https://supportivecare.example.com'
    },
    address: {
      street: '456 High Street',
      suburb: 'Northcote',
      state: 'VIC',
      postcode: '3070',
      country: 'Australia'
    },
    availability: {
      daysOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
      startTime: '08:00',
      endTime: '18:00'
    }
  },
  {
    id: 'provider-002',
    name: 'Inclusive Living Supports',
    registrationGroups: ['Daily Personal Activities', 'Household Tasks'],
    serviceTypes: ['Personal Care', 'Domestic Assistance'],
    rating: 4.5,
    location: {
      latitude: -37.7964,
      longitude: 144.9612
    },
    contactDetails: {
      email: 'contact@inclusivesupports.example.com',
      phone: '0388776655',
      website: 'https://inclusivesupports.example.com'
    },
    address: {
      street: '789 Sydney Road',
      suburb: 'Brunswick',
      state: 'VIC',
      postcode: '3056',
      country: 'Australia'
    },
    availability: {
      daysOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
      startTime: '07:00',
      endTime: '20:00'
    }
  }
];

/**
 * Run validation tests for the NDIS API integration
 * @returns {Object} Test results
 */
export async function validateApiIntegration() {
  const results = {
    success: true,
    tests: {},
    errors: []
  };
  
  try {
    // Test data transformation
    results.tests.dataTransformation = await testDataTransformation();
    
    // Test caching
    results.tests.caching = await testCaching();
    
    // Test advanced search
    results.tests.advancedSearch = await testAdvancedSearch();
    
    // Test participant profile management
    results.tests.participantProfiles = await testParticipantProfiles();
    
    // Test error handling
    results.tests.errorHandling = await testErrorHandling();
    
    // Test real-time updates (mock implementation)
    results.tests.realTimeUpdates = await testRealTimeUpdates();
    
    // Check for any failed tests
    for (const [testName, testResult] of Object.entries(results.tests)) {
      if (!testResult.success) {
        results.success = false;
        results.errors.push(`Test '${testName}' failed: ${testResult.message}`);
      }
    }
  } catch (error) {
    results.success = false;
    results.errors.push(`Validation failed with error: ${error.message}`);
    console.error('API integration validation error:', error);
  }
  
  return results;
}

/**
 * Test data transformation functionality
 * @returns {Object} Test result
 */
async function testDataTransformation() {
  try {
    console.log('Testing data transformation...');
    
    // Test plan normalization
    const normalizedPlan = NDISDataTransformer.normalizePlanData(TEST_PLAN);
    
    if (!normalizedPlan || normalizedPlan.id !== TEST_PLAN.id) {
      return {
        success: false,
        message: 'Plan normalization failed'
      };
    }
    
    // Test participant normalization
    const normalizedParticipant = NDISDataTransformer.normalizeParticipantData(TEST_PARTICIPANT);
    
    if (!normalizedParticipant || normalizedParticipant.id !== TEST_PARTICIPANT.id) {
      return {
        success: false,
        message: 'Participant normalization failed'
      };
    }
    
    // Test plan summary generation
    const planSummary = NDISDataTransformer.generatePlanSummary(normalizedPlan);
    
    if (!planSummary || planSummary.planId !== TEST_PLAN.id) {
      return {
        success: false,
        message: 'Plan summary generation failed'
      };
    }
    
    // Test budget percentage calculation
    const spentPercentage = NDISDataTransformer.calculateBudgetPercentage(
      TEST_PLAN.totalFunding.spent,
      TEST_PLAN.totalFunding.allocated
    );
    
    if (spentPercentage !== (TEST_PLAN.totalFunding.spent / TEST_PLAN.totalFunding.allocated * 100)) {
      return {
        success: false,
        message: 'Budget percentage calculation failed'
      };
    }
    
    // Test date formatting
    const formattedDate = NDISDataTransformer.formatDate(TEST_PLAN.startDate);
    
    if (!formattedDate) {
      return {
        success: false,
        message: 'Date formatting failed'
      };
    }
    
    return {
      success: true,
      message: 'Data transformation tests passed'
    };
  } catch (error) {
    console.error('Data transformation test error:', error);
    return {
      success: false,
      message: `Data transformation test error: ${error.message}`
    };
  }
}

/**
 * Test caching functionality
 * @returns {Object} Test result
 */
async function testCaching() {
  try {
    console.log('Testing caching...');
    
    // Create cache manager
    const cacheManager = new NDISApiCacheManager({
      defaultTTL: 60000, // 1 minute
      maxEntries: 10
    });
    
    // Test setting and getting cache entries
    const testKey = 'test-key';
    const testValue = { data: 'test-data' };
    
    cacheManager.set(testKey, testValue);
    const cachedValue = cacheManager.get(testKey);
    
    if (!cachedValue || cachedValue.data !== testValue.data) {
      return {
        success: false,
        message: 'Cache set/get failed'
      };
    }
    
    // Test cache expiration
    const expiredKey = 'expired-key';
    cacheManager.set(expiredKey, testValue, 1); // 1ms TTL
    
    // Wait for expiration
    await new Promise(resolve => setTimeout(resolve, 10));
    
    const expiredValue = cacheManager.get(expiredKey);
    
    if (expiredValue !== null) {
      return {
        success: false,
        message: 'Cache expiration failed'
      };
    }
    
    // Test cache eviction
    for (let i = 0; i < 15; i++) {
      cacheManager.set(`key-${i}`, { data: `value-${i}` });
    }
    
    // The cache should have evicted some entries
    if (cacheManager.cache.size > 10) {
      return {
        success: false,
        message: 'Cache eviction failed'
      };
    }
    
    // Test cache clearing
    cacheManager.clear();
    
    if (cacheManager.cache.size !== 0) {
      return {
        success: false,
        message: 'Cache clearing failed'
      };
    }
    
    return {
      success: true,
      message: 'Caching tests passed'
    };
  } catch (error) {
    console.error('Caching test error:', error);
    return {
      success: false,
      message: `Caching test error: ${error.message}`
    };
  }
}

/**
 * Test advanced search functionality
 * @returns {Object} Test result
 */
async function testAdvancedSearch() {
  try {
    console.log('Testing advanced search...');
    
    // Create advanced search instance
    const advancedSearch = new NDISAdvancedSearch({
      fuzzyMatchThreshold: 0.7,
      maxResults: 10
    });
    
    // Test provider search
    const providerResults = advancedSearch.searchProviders(TEST_PROVIDERS, {
      query: 'supportive',
      registrationGroups: ['Daily Personal Activities']
    });
    
    if (!providerResults || providerResults.length !== 1 || providerResults[0].id !== 'provider-001') {
      return {
        success: false,
        message: 'Provider search failed'
      };
    }
    
    // Test location-based search
    const locationResults = advancedSearch.searchProviders(TEST_PROVIDERS, {
      location: {
        latitude: -37.8136,
        longitude: 144.9631
      },
      radius: 10
    });
    
    if (!locationResults || locationResults.length !== 2) {
      return {
        success: false,
        message: 'Location-based search failed'
      };
    }
    
    // Test availability filtering
    const availabilityResults = advancedSearch.searchProviders(TEST_PROVIDERS, {
      availability: {
        daysOfWeek: ['Saturday'],
        startTime: '08:00',
        endTime: '18:00'
      }
    });
    
    if (!availabilityResults || availabilityResults.length !== 1 || availabilityResults[0].id !== 'provider-002') {
      return {
        success: false,
        message: 'Availability filtering failed'
      };
    }
    
    // Test fuzzy matching
    const fuzzyResults = advancedSearch.searchProviders(TEST_PROVIDERS, {
      query: 'inclusive'
    });
    
    if (!fuzzyResults || fuzzyResults.length !== 1 || fuzzyResults[0].id !== 'provider-002') {
      return {
        success: false,
        message: 'Fuzzy matching failed'
      };
    }
    
    return {
      success: true,
      message: 'Advanced search tests passed'
    };
  } catch (error) {
    console.error('Advanced search test error:', error);
    return {
      success: false,
      message: `Advanced search test error: ${error.message}`
    };
  }
}

/**
 * Test participant profile management functionality
 * @returns {Object} Test result
 */
async function testParticipantProfiles() {
  try {
    console.log('Testing participant profile management...');
    
    // Create profile manager
    const profileManager = new NDISParticipantProfileManager({
      syncEnabled: false
    });
    
    // Test profile creation
    const createdProfile = profileManager.createProfile(TEST_PARTICIPANT);
    
    if (!createdProfile || createdProfile.id !== TEST_PARTICIPANT.id) {
      return {
        success: false,
        message: 'Profile creation failed'
      };
    }
    
    // Test profile retrieval
    const retrievedProfile = profileManager.getProfile(TEST_PARTICIPANT.id);
    
    if (!retrievedProfile || retrievedProfile.id !== TEST_PARTICIPANT.id) {
      return {
        success: false,
        message: 'Profile retrieval failed'
      };
    }
    
    // Test plan update
    const updatedProfile = profileManager.updatePlan(TEST_PARTICIPANT.id, TEST_PLAN, true);
    
    if (!updatedProfile || !updatedProfile.currentPlan || updatedProfile.currentPlan.id !== TEST_PLAN.id) {
      return {
        success: false,
        message: 'Plan update failed'
      };
    }
    
    // Test note addition
    const noteText = 'Test note for participant';
    const profileWithNote = profileManager.addNote(TEST_PARTICIPANT.id, noteText, 'general');
    
    if (!profileWithNote || !profileWithNote.notes || profileWithNote.notes.length !== 1 || 
        profileWithNote.notes[0].content !== noteText) {
      return {
        success: false,
        message: 'Note addition failed'
      };
    }
    
    // Test preference update
    const preferences = {
      communicationPreference: 'email',
      notificationEnabled: true
    };
    
    const profileWithPreferences = profileManager.updatePreferences(TEST_PARTICIPANT.id, preferences);
    
    if (!profileWithPreferences || !profileWithPreferences.preferences || 
        profileWithPreferences.preferences.communicationPreference !== preferences.communicationPreference) {
      return {
        success: false,
        message: 'Preference update failed'
      };
    }
    
    // Test profile search
    const searchResults = profileManager.searchProfiles({
      firstName: 'Jane'
    });
    
    if (!searchResults || searchResults.length !== 1 || searchResults[0].id !== TEST_PARTICIPANT.id) {
      return {
        success: false,
        message: 'Profile search failed'
      };
    }
    
    // Test profile deletion
    const deleteResult = profileManager.deleteProfile(TEST_PARTICIPANT.id);
    
    if (!deleteResult) {
      return {
        success: false,
        message: 'Profile deletion failed'
      };
    }
    
    // Verify deletion
    const deletedProfile = profileManager.getProfile(TEST_PARTICIPANT.id);
    
    if (deletedProfile !== null) {
      return {
        success: false,
        message: 'Profile was not properly deleted'
      };
    }
    
    return {
      success: true,
      message: 'Participant profile management tests passed'
    };
  } catch (error) {
    console.error('Participant profile test error:', error);
    return {
      success: false,
      message: `Participant profile test error: ${error.message}`
    };
  }
}

/**
 * Test error handling functionality
 * @returns {Object} Test result
 */
async function testErrorHandling() {
  try {
    console.log('Testing error handling...');
    
    // Create error handler
    const errorHandler = new NDISErrorHandler({
      logErrors: true,
      enableRetry: true,
      maxRetries: 3
    });
    
    // Test JavaScript error handling
    const jsError = new Error('Network connection failed');
    jsError.name = 'TypeError';
    
    const normalizedJsError = errorHandler.handleError(jsError, {
      endpoint: '/participants/123',
      method: 'GET'
    });
    
    if (normalizedJsError.code !== ERROR_CODES.NETWORK_ERROR || !normalizedJsError.retryable) {
      return {
        success: false,
        message: 'JavaScript error normalization failed'
      };
    }
    
    // Test API error handling
    const apiError = {
      status: 404,
      data: {
        message: 'Participant not found'
      }
    };
    
    const normalizedApiError = errorHandler.handleError(apiError, {
      endpoint: '/participants/123',
      method: 'GET'
    });
    
    if (normalizedApiError.code !== ERROR_CODES.RESOURCE_NOT_FOUND || normalizedApiError.retryable) {
      return {
        success: false,
        message: 'API error normalization failed'
      };
    }
    
    // Test retry decision
    const retryableError = {
      code: ERROR_CODES.TIMEOUT,
      retryable: true
    };
    
    const shouldRetry1 = errorHandler.shouldRetry(retryableError, 1);
    const shouldRetry4 = errorHandler.shouldRetry(retryableError, 4);
    
    if (!shouldRetry1 || shouldRetry4) {
      return {
        success: false,
        message: 'Retry decision logic failed'
      };
    }
    
    // Test user-friendly messages
    const userMessage = errorHandler.getUserFriendlyMessage(normalizedApiError);
    
    if (!userMessage || userMessage.length === 0) {
      return {
        success: false,
        message: 'User-friendly message generation failed'
      };
    }
    
    // Test recovery suggestions
    const suggestions = errorHandler.getRecoverySuggestions(normalizedApiError);
    
    if (!suggestions || !Array.isArray(suggestions) || suggestions.length === 0) {
      return {
        success: false,
        message: 'Recovery suggestions generation failed'
      };
    }
    
    return {
      success: true,
      message: 'Error handling tests passed'
    };
  } catch (error) {
    console.error('Error handling test error:', error);
    return {
      success: false,
      message: `Error handling test error: ${error.message}`
    };
  }
}

/**
 * Test real-time updates functionality (mock implementation)
 * @returns {Object} Test result
 */
async function testRealTimeUpdates() {
  try {
    console.log('Testing real-time updates (mock implementation)...');
    
    // Create a mock WebSocket for testing
    class MockWebSocket {
      constructor(url) {
        this.url = url;
        this.readyState = 0; // CONNECTING
        
        // Auto-connect after a short delay
        setTimeout(() => {
          this.readyState = 1; // OPEN
          if (this.onopen) {
            this.onopen();
          }
        }, 10);
      }
      
      send(data) {
        // Echo back the message after a short delay
        setTimeout(() => {
          if (this.onmessage) {
            this.onmessage({ data });
          }
        }, 10);
      }
      
      close() {
        this.readyState = 3; // CLOSED
        if (this.onclose) {
          this.onclose({ code: 1000, reason: 'Normal closure' });
        }
      }
    }
    
    // Store original WebSocket
    const originalWebSocket = global.WebSocket;
    
    // Replace with mock
    global.WebSocket = MockWebSocket;
    
    // Create real-time updates instance
    const realTimeUpdates = new NDISRealTimeUpdates({
      websocketUrl: 'wss://test.example.com/ws',
      reconnectInterval: 100,
      maxReconnectAttempts: 3
    });
    
    // Test connection
    let connected = false;
    await realTimeUpdates.connect().then(result => {
      connected = result;
    });
    
    if (!connected) {
      // Restore original WebSocket
      global.WebSocket = originalWebSocket;
      
      return {
        success: false,
        message: 'WebSocket connection failed'
      };
    }
    
    // Test message handling
    let messageReceived = false;
    
    realTimeUpdates.registerMessageHandler('test', message => {
      messageReceived = true;
    });
    
    // Send a test message
    realTimeUpdates.sendMessage({
      type: 'test',
      data: 'test-data'
    });
    
    // Wait for message processing
    await new Promise(resolve => setTimeout(resolve, 50));
    
    if (!messageReceived) {
      // Restore original WebSocket
      global.WebSocket = originalWebSocket;
      
      return {
        success: false,
        message: 'Message handling failed'
      };
    }
    
    // Test subscription
    let subscriptionMessageReceived = false;
    
    realTimeUpdates.subscribe('test-topic', message => {
      subscriptionMessageReceived = true;
    });
    
    // Wait for subscription processing
    await new Promise(resolve => setTimeout(resolve, 50));
    
    // Test disconnection
    realTimeUpdates.disconnect();
    
    // Verify disconnection
    if (realTimeUpdates.connected) {
      // Restore original WebSocket
      global.WebSocket = originalWebSocket;
      
      return {
        success: false,
        message: 'Disconnection failed'
      };
    }
    
    // Restore original WebSocket
    global.WebSocket = originalWebSocket;
    
    return {
      success: true,
      message: 'Real-time updates tests passed'
    };
  } catch (error) {
    console.error('Real-time updates test error:', error);
    
    // Ensure WebSocket is restored
    if (global.WebSocket.name === 'MockWebSocket') {
      global.WebSocket = originalWebSocket;
    }
    
    return {
      success: false,
      message: `Real-time updates test error: ${error.message}`
    };
  }
}

// Export test data for use in other tests
export {
  TEST_PARTICIPANT,
  TEST_PLAN,
  TEST_PROVIDERS
};
