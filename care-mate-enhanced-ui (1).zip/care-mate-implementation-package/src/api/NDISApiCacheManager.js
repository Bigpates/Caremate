/**
 * Care Mate - NDIS API Cache Manager (Updated)
 * 
 * This module provides caching mechanisms for API responses to improve
 * performance and reduce unnecessary network requests.
 * Updated to use the storage adapter for cross-environment compatibility.
 */

import NDISStorageAdapter from './NDISStorageAdapter.js';

/**
 * Cache Manager class for NDIS API responses
 */
class NDISApiCacheManager {
  constructor(options = {}) {
    // Default options
    this.options = {
      enabled: true,
      defaultTTL: 5 * 60 * 1000, // 5 minutes in milliseconds
      maxEntries: 100,
      storageKey: 'ndis_api_cache',
      ...options
    };
    
    // Initialize cache
    this.cache = new Map();
    this.metaData = new Map();
    
    // Initialize storage adapter
    this.storage = new NDISStorageAdapter({
      storageKey: this.options.storageKey
    });
    
    // Bind methods
    this.get = this.get.bind(this);
    this.set = this.set.bind(this);
    this.has = this.has.bind(this);
    this.delete = this.delete.bind(this);
    this.clear = this.clear.bind(this);
    this.loadFromStorage = this.loadFromStorage.bind(this);
    this.saveToStorage = this.saveToStorage.bind(this);
    
    // Load cache from storage if available
    this.loadFromStorage();
    
    // Set up periodic cleanup
    this.cleanupInterval = setInterval(() => {
      this.cleanup();
    }, 60000); // Run cleanup every minute
  }
  
  /**
   * Get a value from the cache
   * @param {string} key - Cache key
   * @returns {any|null} Cached value or null if not found or expired
   */
  get(key) {
    if (!this.options.enabled) return null;
    
    // Check if key exists and is not expired
    if (this.has(key)) {
      const value = this.cache.get(key);
      const meta = this.metaData.get(key);
      
      // Update last accessed time
      meta.lastAccessed = Date.now();
      this.metaData.set(key, meta);
      
      return value;
    }
    
    return null;
  }
  
  /**
   * Set a value in the cache
   * @param {string} key - Cache key
   * @param {any} value - Value to cache
   * @param {number} ttl - Time to live in milliseconds (optional)
   */
  set(key, value, ttl = this.options.defaultTTL) {
    if (!this.options.enabled) return;
    
    // Ensure we don't exceed max entries
    if (this.cache.size >= this.options.maxEntries && !this.cache.has(key)) {
      this.evictLeastRecentlyUsed();
    }
    
    // Store value and metadata
    this.cache.set(key, value);
    this.metaData.set(key, {
      createdAt: Date.now(),
      expiresAt: Date.now() + ttl,
      lastAccessed: Date.now()
    });
    
    // Save to storage
    this.saveToStorage();
  }
  
  /**
   * Check if a key exists in the cache and is not expired
   * @param {string} key - Cache key
   * @returns {boolean} Whether the key exists and is valid
   */
  has(key) {
    if (!this.options.enabled) return false;
    
    if (!this.cache.has(key) || !this.metaData.has(key)) {
      return false;
    }
    
    const meta = this.metaData.get(key);
    const now = Date.now();
    
    // Check if expired
    if (meta.expiresAt < now) {
      // Remove expired entry
      this.delete(key);
      return false;
    }
    
    return true;
  }
  
  /**
   * Delete a key from the cache
   * @param {string} key - Cache key
   */
  delete(key) {
    this.cache.delete(key);
    this.metaData.delete(key);
    this.saveToStorage();
  }
  
  /**
   * Clear the entire cache
   */
  clear() {
    this.cache.clear();
    this.metaData.clear();
    this.saveToStorage();
  }
  
  /**
   * Remove expired entries from the cache
   */
  cleanup() {
    const now = Date.now();
    const expiredKeys = [];
    
    // Find expired keys
    this.metaData.forEach((meta, key) => {
      if (meta.expiresAt < now) {
        expiredKeys.push(key);
      }
    });
    
    // Delete expired keys
    expiredKeys.forEach(key => {
      this.delete(key);
    });
    
    // Save changes if any keys were removed
    if (expiredKeys.length > 0) {
      this.saveToStorage();
    }
  }
  
  /**
   * Evict the least recently used cache entry
   */
  evictLeastRecentlyUsed() {
    let oldestKey = null;
    let oldestAccess = Infinity;
    
    // Find the least recently accessed key
    this.metaData.forEach((meta, key) => {
      if (meta.lastAccessed < oldestAccess) {
        oldestAccess = meta.lastAccessed;
        oldestKey = key;
      }
    });
    
    // Delete the oldest key
    if (oldestKey) {
      this.delete(oldestKey);
    }
  }
  
  /**
   * Load cache from storage
   */
  loadFromStorage() {
    try {
      const storedData = this.storage.getItem('cache_data');
      
      if (storedData) {
        const { cache, metaData } = storedData;
        
        // Restore cache and metadata
        Object.entries(cache).forEach(([key, value]) => {
          this.cache.set(key, value);
        });
        
        Object.entries(metaData).forEach(([key, value]) => {
          this.metaData.set(key, value);
        });
        
        // Run cleanup to remove any expired entries
        this.cleanup();
      }
    } catch (error) {
      console.error('Failed to load cache from storage:', error);
      // Reset cache if loading fails
      this.clear();
    }
  }
  
  /**
   * Save cache to storage
   */
  saveToStorage() {
    try {
      // Convert Maps to objects for JSON serialization
      const cacheObj = {};
      this.cache.forEach((value, key) => {
        cacheObj[key] = value;
      });
      
      const metaDataObj = {};
      this.metaData.forEach((value, key) => {
        metaDataObj[key] = value;
      });
      
      // Store in storage adapter
      this.storage.setItem('cache_data', {
        cache: cacheObj,
        metaData: metaDataObj
      });
    } catch (error) {
      console.error('Failed to save cache to storage:', error);
    }
  }
  
  /**
   * Dispose of resources
   */
  dispose() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
  }
}

// Export the cache manager
export default NDISApiCacheManager;
