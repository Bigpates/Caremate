/**
 * Care Mate - NDIS API Integration Validation Script
 * 
 * This script runs the validation tests for the NDIS API integration
 * and outputs the results to the console and a report file.
 */

// Import the validation runner
import runApiValidationTests from './NDISApiValidationRunner.js';

// Run the validation tests
console.log('=== NDIS API Integration Validation ===');
console.log('Starting validation tests...');

runApiValidationTests()
  .then(result => {
    console.log('\n=== Validation Complete ===');
    console.log(`Overall Status: ${result.success ? 'PASSED' : 'FAILED'}`);
    console.log('See api-validation-report.md for detailed results');
    
    if (!result.success) {
      process.exit(1);
    }
  })
  .catch(error => {
    console.error('\n=== Validation Failed ===');
    console.error(`Error: ${error.message}`);
    process.exit(1);
  });
