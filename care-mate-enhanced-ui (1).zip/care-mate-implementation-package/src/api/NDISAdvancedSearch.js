/**
 * Care Mate - NDIS Advanced Search Utilities
 * 
 * This module provides advanced search capabilities for NDIS data,
 * including fuzzy matching, filtering, and sorting functionality.
 */

/**
 * NDIS Advanced Search class
 * Provides methods for advanced searching of NDIS data
 */
class NDISAdvancedSearch {
  constructor(config = {}) {
    // Default configuration
    this.config = {
      fuzzyMatchThreshold: 0.7, // Threshold for fuzzy matching (0-1)
      maxResults: 50, // Maximum number of results to return
      enableHighlighting: true, // Whether to highlight matched terms
      ...config
    };
  }
  
  /**
   * Search for service providers with advanced filtering
   * @param {Array} providers - List of service providers
   * @param {Object} criteria - Search criteria
   * @returns {Array} Filtered and sorted providers
   */
  searchProviders(providers, criteria = {}) {
    if (!Array.isArray(providers)) {
      return [];
    }
    
    let results = [...providers];
    
    // Apply text search if provided
    if (criteria.query) {
      results = this.textSearch(results, criteria.query, [
        'name', 
        'description',
        'registrationGroups',
        'contactDetails.email',
        'contactDetails.phone',
        'contactDetails.website',
        'address.suburb',
        'address.state'
      ]);
    }
    
    // Apply location filtering if provided
    if (criteria.location) {
      results = this.filterByLocation(results, criteria.location, criteria.radius || 25);
    }
    
    // Apply registration group filtering if provided
    if (criteria.registrationGroups && criteria.registrationGroups.length > 0) {
      results = this.filterByRegistrationGroups(results, criteria.registrationGroups);
    }
    
    // Apply service type filtering if provided
    if (criteria.serviceTypes && criteria.serviceTypes.length > 0) {
      results = this.filterByServiceTypes(results, criteria.serviceTypes);
    }
    
    // Apply availability filtering if provided
    if (criteria.availability) {
      results = this.filterByAvailability(results, criteria.availability);
    }
    
    // Apply rating filtering if provided
    if (criteria.minRating) {
      results = this.filterByRating(results, criteria.minRating);
    }
    
    // Sort results
    results = this.sortResults(results, criteria.sortBy || 'relevance', criteria.sortOrder || 'desc');
    
    // Limit results
    const maxResults = criteria.maxResults || this.config.maxResults;
    results = results.slice(0, maxResults);
    
    // Add highlighting if enabled
    if (this.config.enableHighlighting && criteria.query) {
      results = this.addHighlighting(results, criteria.query);
    }
    
    return results;
  }
  
  /**
   * Search for participants with advanced filtering
   * @param {Array} participants - List of participants
   * @param {Object} criteria - Search criteria
   * @returns {Array} Filtered and sorted participants
   */
  searchParticipants(participants, criteria = {}) {
    if (!Array.isArray(participants)) {
      return [];
    }
    
    let results = [...participants];
    
    // Apply text search if provided
    if (criteria.query) {
      results = this.textSearch(results, criteria.query, [
        'firstName',
        'lastName',
        'ndisNumber',
        'contactDetails.email',
        'contactDetails.phone',
        'contactDetails.mobile',
        'contactDetails.address.suburb',
        'contactDetails.address.state'
      ]);
    }
    
    // Apply plan status filtering if provided
    if (criteria.planStatus) {
      results = results.filter(participant => {
        return participant.currentPlan && participant.currentPlan.status === criteria.planStatus;
      });
    }
    
    // Apply age range filtering if provided
    if (criteria.ageRange && criteria.ageRange.min !== undefined && criteria.ageRange.max !== undefined) {
      results = this.filterByAgeRange(results, criteria.ageRange);
    }
    
    // Apply support coordinator filtering if provided
    if (criteria.supportCoordinator) {
      results = results.filter(participant => {
        return participant.currentPlan && 
               participant.currentPlan.supportCoordination && 
               participant.currentPlan.supportCoordination.coordinator &&
               participant.currentPlan.supportCoordination.coordinator.name.includes(criteria.supportCoordinator);
      });
    }
    
    // Apply plan end date filtering if provided
    if (criteria.planEndDateBefore) {
      const endDateBefore = new Date(criteria.planEndDateBefore);
      results = results.filter(participant => {
        return participant.currentPlan && 
               new Date(participant.currentPlan.endDate) <= endDateBefore;
      });
    }
    
    // Sort results
    results = this.sortResults(results, criteria.sortBy || 'lastName', criteria.sortOrder || 'asc');
    
    // Limit results
    const maxResults = criteria.maxResults || this.config.maxResults;
    results = results.slice(0, maxResults);
    
    // Add highlighting if enabled
    if (this.config.enableHighlighting && criteria.query) {
      results = this.addHighlighting(results, criteria.query);
    }
    
    return results;
  }
  
  /**
   * Search for plans with advanced filtering
   * @param {Array} plans - List of plans
   * @param {Object} criteria - Search criteria
   * @returns {Array} Filtered and sorted plans
   */
  searchPlans(plans, criteria = {}) {
    if (!Array.isArray(plans)) {
      return [];
    }
    
    let results = [...plans];
    
    // Apply text search if provided
    if (criteria.query) {
      results = this.textSearch(results, criteria.query, [
        'id',
        'participantId',
        'goals.description',
        'goals.category'
      ]);
    }
    
    // Apply date range filtering if provided
    if (criteria.dateRange) {
      results = this.filterByDateRange(results, criteria.dateRange);
    }
    
    // Apply status filtering if provided
    if (criteria.status) {
      results = results.filter(plan => plan.status === criteria.status);
    }
    
    // Apply budget range filtering if provided
    if (criteria.budgetRange) {
      results = this.filterByBudgetRange(results, criteria.budgetRange);
    }
    
    // Apply goal category filtering if provided
    if (criteria.goalCategories && criteria.goalCategories.length > 0) {
      results = this.filterByGoalCategories(results, criteria.goalCategories);
    }
    
    // Sort results
    results = this.sortResults(results, criteria.sortBy || 'startDate', criteria.sortOrder || 'desc');
    
    // Limit results
    const maxResults = criteria.maxResults || this.config.maxResults;
    results = results.slice(0, maxResults);
    
    // Add highlighting if enabled
    if (this.config.enableHighlighting && criteria.query) {
      results = this.addHighlighting(results, criteria.query);
    }
    
    return results;
  }
  
  /**
   * Perform text search with fuzzy matching
   * @param {Array} items - Items to search
   * @param {string} query - Search query
   * @param {Array} fields - Fields to search in
   * @returns {Array} Matched items with relevance scores
   */
  textSearch(items, query, fields) {
    if (!query || !fields || fields.length === 0) {
      return items;
    }
    
    const searchTerms = query.toLowerCase().split(/\s+/).filter(term => term.length > 0);
    
    if (searchTerms.length === 0) {
      return items;
    }
    
    // Calculate relevance score for each item
    const scoredItems = items.map(item => {
      let totalScore = 0;
      let matchCount = 0;
      
      // Check each search term against each field
      searchTerms.forEach(term => {
        fields.forEach(field => {
          const value = this.getNestedProperty(item, field);
          
          if (value) {
            const stringValue = String(value).toLowerCase();
            
            // Exact match gets highest score
            if (stringValue === term) {
              totalScore += 2;
              matchCount++;
            }
            // Contains match gets medium score
            else if (stringValue.includes(term)) {
              totalScore += 1;
              matchCount++;
            }
            // Fuzzy match gets lowest score
            else if (this.calculateFuzzyScore(stringValue, term) >= this.config.fuzzyMatchThreshold) {
              totalScore += 0.5;
              matchCount++;
            }
          }
        });
      });
      
      // Calculate final relevance score
      const relevanceScore = matchCount > 0 ? totalScore / (searchTerms.length * fields.length) : 0;
      
      return {
        ...item,
        _relevanceScore: relevanceScore,
        _matched: matchCount > 0
      };
    });
    
    // Filter out non-matching items and sort by relevance
    return scoredItems
      .filter(item => item._matched)
      .sort((a, b) => b._relevanceScore - a._relevanceScore);
  }
  
  /**
   * Calculate fuzzy matching score between two strings
   * @param {string} str1 - First string
   * @param {string} str2 - Second string
   * @returns {number} Similarity score (0-1)
   */
  calculateFuzzyScore(str1, str2) {
    // Simple Levenshtein distance implementation
    const len1 = str1.length;
    const len2 = str2.length;
    
    // If either string is empty, the distance is the length of the other string
    if (len1 === 0) return 0;
    if (len2 === 0) return 0;
    
    // Create distance matrix
    const matrix = Array(len1 + 1).fill().map(() => Array(len2 + 1).fill(0));
    
    // Initialize first row and column
    for (let i = 0; i <= len1; i++) {
      matrix[i][0] = i;
    }
    
    for (let j = 0; j <= len2; j++) {
      matrix[0][j] = j;
    }
    
    // Fill in the rest of the matrix
    for (let i = 1; i <= len1; i++) {
      for (let j = 1; j <= len2; j++) {
        const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[i][j] = Math.min(
          matrix[i - 1][j] + 1, // deletion
          matrix[i][j - 1] + 1, // insertion
          matrix[i - 1][j - 1] + cost // substitution
        );
      }
    }
    
    // Calculate similarity score (0-1)
    const maxLen = Math.max(len1, len2);
    const distance = matrix[len1][len2];
    return 1 - (distance / maxLen);
  }
  
  /**
   * Get a nested property from an object using dot notation
   * @param {Object} obj - Object to get property from
   * @param {string} path - Property path in dot notation
   * @returns {any} Property value or undefined if not found
   */
  getNestedProperty(obj, path) {
    return path.split('.').reduce((current, key) => {
      return current && current[key] !== undefined ? current[key] : undefined;
    }, obj);
  }
  
  /**
   * Filter providers by location and radius
   * @param {Array} providers - Providers to filter
   * @param {Object} location - Location coordinates
   * @param {number} radius - Search radius in kilometers
   * @returns {Array} Filtered providers
   */
  filterByLocation(providers, location, radius) {
    if (!location || !location.latitude || !location.longitude) {
      return providers;
    }
    
    return providers.filter(provider => {
      if (!provider.location || !provider.location.latitude || !provider.location.longitude) {
        return false;
      }
      
      const distance = this.calculateDistance(
        location.latitude,
        location.longitude,
        provider.location.latitude,
        provider.location.longitude
      );
      
      // Add distance to provider object for sorting
      provider._distance = distance;
      
      return distance <= radius;
    });
  }
  
  /**
   * Calculate distance between two coordinates using Haversine formula
   * @param {number} lat1 - Latitude of first point
   * @param {number} lon1 - Longitude of first point
   * @param {number} lat2 - Latitude of second point
   * @param {number} lon2 - Longitude of second point
   * @returns {number} Distance in kilometers
   */
  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.toRadians(lat2 - lat1);
    const dLon = this.toRadians(lon2 - lon1);
    
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;
    
    return distance;
  }
  
  /**
   * Convert degrees to radians
   * @param {number} degrees - Angle in degrees
   * @returns {number} Angle in radians
   */
  toRadians(degrees) {
    return degrees * (Math.PI / 180);
  }
  
  /**
   * Filter providers by registration groups
   * @param {Array} providers - Providers to filter
   * @param {Array} registrationGroups - Registration groups to filter by
   * @returns {Array} Filtered providers
   */
  filterByRegistrationGroups(providers, registrationGroups) {
    if (!registrationGroups || registrationGroups.length === 0) {
      return providers;
    }
    
    return providers.filter(provider => {
      if (!provider.registrationGroups || !Array.isArray(provider.registrationGroups)) {
        return false;
      }
      
      // Check if provider has any of the specified registration groups
      return registrationGroups.some(group => 
        provider.registrationGroups.includes(group)
      );
    });
  }
  
  /**
   * Filter providers by service types
   * @param {Array} providers - Providers to filter
   * @param {Array} serviceTypes - Service types to filter by
   * @returns {Array} Filtered providers
   */
  filterByServiceTypes(providers, serviceTypes) {
    if (!serviceTypes || serviceTypes.length === 0) {
      return providers;
    }
    
    return providers.filter(provider => {
      if (!provider.serviceTypes || !Array.isArray(provider.serviceTypes)) {
        return false;
      }
      
      // Check if provider has any of the specified service types
      return serviceTypes.some(type => 
        provider.serviceTypes.includes(type)
      );
    });
  }
  
  /**
   * Filter providers by availability
   * @param {Array} providers - Providers to filter
   * @param {Object} availability - Availability criteria
   * @returns {Array} Filtered providers
   */
  filterByAvailability(providers, availability) {
    if (!availability) {
      return providers;
    }
    
    return providers.filter(provider => {
      if (!provider.availability) {
        return false;
      }
      
      // Check days of week
      if (availability.daysOfWeek && availability.daysOfWeek.length > 0) {
        if (!provider.availability.daysOfWeek || 
            !availability.daysOfWeek.some(day => provider.availability.daysOfWeek.includes(day))) {
          return false;
        }
      }
      
      // Check time range
      if (availability.startTime && availability.endTime) {
        if (!provider.availability.startTime || !provider.availability.endTime) {
          return false;
        }
        
        const providerStart = this.parseTimeString(provider.availability.startTime);
        const providerEnd = this.parseTimeString(provider.availability.endTime);
        const requestedStart = this.parseTimeString(availability.startTime);
        const requestedEnd = this.parseTimeString(availability.endTime);
        
        // Check if provider's time range overlaps with requested time range
        if (providerEnd <= requestedStart || providerStart >= requestedEnd) {
          return false;
        }
      }
      
      return true;
    });
  }
  
  /**
   * Parse time string to minutes since midnight
   * @param {string} timeString - Time string in HH:MM format
   * @returns {number} Minutes since midnight
   */
  parseTimeString(timeString) {
    const [hours, minutes] = timeString.split(':').map(Number);
    return hours * 60 + minutes;
  }
  
  /**
   * Filter providers by rating
   * @param {Array} providers - Providers to filter
   * @param {number} minRating - Minimum rating
   * @returns {Array} Filtered providers
   */
  filterByRating(providers, minRating) {
    if (!minRating) {
      return providers;
    }
    
    return providers.filter(provider => {
      return provider.rating && provider.rating >= minRating;
    });
  }
  
  /**
   * Filter participants by age range
   * @param {Array} participants - Participants to filter
   * @param {Object} ageRange - Age range criteria
   * @returns {Array} Filtered participants
   */
  filterByAgeRange(participants, ageRange) {
    if (!ageRange || ageRange.min === undefined || ageRange.max === undefined) {
      return participants;
    }
    
    const now = new Date();
    
    return participants.filter(participant => {
      if (!participant.dateOfBirth) {
        return false;
      }
      
      const dob = new Date(participant.dateOfBirth);
      const age = this.calculateAge(dob, now);
      
      return age >= ageRange.min && age <= ageRange.max;
    });
  }
  
  /**
   * Calculate age from date of birth
   * @param {Date} dob - Date of birth
   * @param {Date} now - Current date
   * @returns {number} Age in years
   */
  calculateAge(dob, now) {
    let age = now.getFullYear() - dob.getFullYear();
    const monthDiff = now.getMonth() - dob.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < dob.getDate())) {
      age--;
    }
    
    return age;
  }
  
  /**
   * Filter plans by date range
   * @param {Array} plans - Plans to filter
   * @param {Object} dateRange - Date range criteria
   * @returns {Array} Filtered plans
   */
  filterByDateRange(plans, dateRange) {
    if (!dateRange) {
      return plans;
    }
    
    const startDate = dateRange.startDate ? new Date(dateRange.startDate) : null;
    const endDate = dateRange.endDate ? new Date(dateRange.endDate) : null;
    
    return plans.filter(plan => {
      const planStartDate = plan.startDate ? new Date(plan.startDate) : null;
      const planEndDate = plan.endDate ? new Date(plan.endDate) : null;
      
      // Check start date
      if (startDate && planStartDate && planStartDate < startDate) {
        return false;
      }
      
      // Check end date
      if (endDate && planEndDate && planEndDate > endDate) {
        return false;
      }
      
      return true;
    });
  }
  
  /**
   * Filter plans by budget range
   * @param {Array} plans - Plans to filter
   * @param {Object} budgetRange - Budget range criteria
   * @returns {Array} Filtered plans
   */
  filterByBudgetRange(plans, budgetRange) {
    if (!budgetRange || (budgetRange.min === undefined && budgetRange.max === undefined)) {
      return plans;
    }
    
    return plans.filter(plan => {
      if (!plan.totalFunding || !plan.totalFunding.allocated) {
        return false;
      }
      
      const allocated = plan.totalFunding.allocated;
      
      // Check minimum budget
      if (budgetRange.min !== undefined && allocated < budgetRange.min) {
        return false;
      }
      
      // Check maximum budget
      if (budgetRange.max !== undefined && allocated > budgetRange.max) {
        return false;
      }
      
      return true;
    });
  }
  
  /**
   * Filter plans by goal categories
   * @param {Array} plans - Plans to filter
   * @param {Array} categories - Goal categories to filter by
   * @returns {Array} Filtered plans
   */
  filterByGoalCategories(plans, categories) {
    if (!categories || categories.length === 0) {
      return plans;
    }
    
    return plans.filter(plan => {
      if (!plan.goals || !Array.isArray(plan.goals) || plan.goals.length === 0) {
        return false;
      }
      
      // Check if plan has any goals in the specified categories
      return plan.goals.some(goal => 
        categories.includes(goal.category)
      );
    });
  }
  
  /**
   * Sort results by specified field and order
   * @param {Array} results - Results to sort
   * @param {string} sortBy - Field to sort by
   * @param {string} sortOrder - Sort order (asc or desc)
   * @returns {Array} Sorted results
   */
  sortResults(results, sortBy, sortOrder) {
    if (!sortBy) {
      return results;
    }
    
    const direction = sortOrder === 'asc' ? 1 : -1;
    
    return [...results].sort((a, b) => {
      // Special case for relevance score
      if (sortBy === 'relevance') {
        const scoreA = a._relevanceScore || 0;
        const scoreB = b._relevanceScore || 0;
        return direction * (scoreB - scoreA);
      }
      
      // Special case for distance
      if (sortBy === 'distance') {
        const distanceA = a._distance || Infinity;
        const distanceB = b._distance || Infinity;
        return direction * (distanceA - distanceB);
      }
      
      // Get values to compare
      const valueA = this.getNestedProperty(a, sortBy);
      const valueB = this.getNestedProperty(b, sortBy);
      
      // Handle different value types
      if (valueA === undefined && valueB === undefined) {
        return 0;
      } else if (valueA === undefined) {
        return direction;
      } else if (valueB === undefined) {
        return -direction;
      } else if (valueA instanceof Date && valueB instanceof Date) {
        return direction * (valueA.getTime() - valueB.getTime());
      } else if (typeof valueA === 'string' && typeof valueB === 'string') {
        return direction * valueA.localeCompare(valueB);
      } else {
        return direction * (valueA - valueB);
      }
    });
  }
  
  /**
   * Add highlighting to matched terms in results
   * @param {Array} results - Search results
   * @param {string} query - Search query
   * @returns {Array} Results with highlighting
   */
  addHighlighting(results, query) {
    if (!query) {
      return results;
    }
    
    const searchTerms = query.toLowerCase().split(/\s+/).filter(term => term.length > 0);
    
    if (searchTerms.length === 0) {
      return results;
    }
    
    return results.map(result => {
      const highlights = {};
      
      // Find matches in each field
      Object.keys(result).forEach(field => {
        if (field.startsWith('_') || typeof result[field] !== 'string') {
          return;
        }
        
        let highlightedText = result[field];
        let hasMatch = false;
        
        // Highlight each search term
        searchTerms.forEach(term => {
          const regex = new RegExp(`(${this.escapeRegExp(term)})`, 'gi');
          if (regex.test(highlightedText)) {
            hasMatch = true;
            highlightedText = highlightedText.replace(regex, '<mark>$1</mark>');
          }
        });
        
        if (hasMatch) {
          highlights[field] = highlightedText;
        }
      });
      
      return {
        ...result,
        _highlights: highlights
      };
    });
  }
  
  /**
   * Escape special characters in string for use in RegExp
   * @param {string} string - String to escape
   * @returns {string} Escaped string
   */
  escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
}

// Export the advanced search utilities
export default NDISAdvancedSearch;
