/**
 * Care Mate - NDIS Storage Adapter
 * 
 * This module provides a storage adapter that works in both browser and Node.js environments,
 * abstracting away the differences between localStorage and file system storage.
 */

/**
 * Storage Adapter class for cross-environment storage
 */
class NDISStorageAdapter {
  constructor(options = {}) {
    this.options = {
      storageKey: 'ndis_storage',
      ...options
    };
    
    // Determine environment
    this.isBrowser = typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
    this.isNode = typeof process !== 'undefined' && process.versions && process.versions.node;
    
    // Initialize storage
    this.memoryStorage = new Map();
  }
  
  /**
   * Get an item from storage
   * @param {string} key - Storage key
   * @returns {any|null} Stored value or null if not found
   */
  getItem(key) {
    const fullKey = `${this.options.storageKey}_${key}`;
    
    try {
      // Browser environment: use localStorage
      if (this.isBrowser) {
        const item = localStorage.getItem(fullKey);
        return item ? JSON.parse(item) : null;
      }
      
      // Node environment: use memory storage
      // In a real implementation, this could use the file system
      return this.memoryStorage.get(fullKey) || null;
    } catch (error) {
      console.error('Storage get error:', error);
      return null;
    }
  }
  
  /**
   * Set an item in storage
   * @param {string} key - Storage key
   * @param {any} value - Value to store
   * @returns {boolean} Success status
   */
  setItem(key, value) {
    const fullKey = `${this.options.storageKey}_${key}`;
    
    try {
      const serializedValue = JSON.stringify(value);
      
      // Browser environment: use localStorage
      if (this.isBrowser) {
        localStorage.setItem(fullKey, serializedValue);
        return true;
      }
      
      // Node environment: use memory storage
      // In a real implementation, this could use the file system
      this.memoryStorage.set(fullKey, value);
      return true;
    } catch (error) {
      console.error('Storage set error:', error);
      return false;
    }
  }
  
  /**
   * Remove an item from storage
   * @param {string} key - Storage key
   * @returns {boolean} Success status
   */
  removeItem(key) {
    const fullKey = `${this.options.storageKey}_${key}`;
    
    try {
      // Browser environment: use localStorage
      if (this.isBrowser) {
        localStorage.removeItem(fullKey);
        return true;
      }
      
      // Node environment: use memory storage
      // In a real implementation, this could use the file system
      this.memoryStorage.delete(fullKey);
      return true;
    } catch (error) {
      console.error('Storage remove error:', error);
      return false;
    }
  }
  
  /**
   * Clear all items from storage
   * @returns {boolean} Success status
   */
  clear() {
    try {
      // Browser environment: clear localStorage items with our prefix
      if (this.isBrowser) {
        const keysToRemove = [];
        const prefix = `${this.options.storageKey}_`;
        
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key.startsWith(prefix)) {
            keysToRemove.push(key);
          }
        }
        
        keysToRemove.forEach(key => localStorage.removeItem(key));
        return true;
      }
      
      // Node environment: clear memory storage
      // In a real implementation, this could delete files
      this.memoryStorage.clear();
      return true;
    } catch (error) {
      console.error('Storage clear error:', error);
      return false;
    }
  }
}

// Export the storage adapter
export default NDISStorageAdapter;
