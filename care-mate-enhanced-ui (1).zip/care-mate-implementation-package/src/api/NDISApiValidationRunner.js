/**
 * Care Mate - NDIS API Integration Test Runner
 * 
 * This module provides a runner for executing the NDIS API integration validation tests
 * and generating a detailed report of the results.
 */

import { validateApiIntegration } from './NDISApiValidation.js';

/**
 * Run all API integration validation tests and generate a report
 * @returns {Promise<Object>} Validation report
 */
async function runApiValidationTests() {
  console.log('Starting NDIS API integration validation...');
  
  const startTime = Date.now();
  const results = await validateApiIntegration();
  const endTime = Date.now();
  
  const executionTime = (endTime - startTime) / 1000; // in seconds
  
  // Generate detailed report
  const report = generateValidationReport(results, executionTime);
  
  // Save report to file
  saveReportToFile(report);
  
  console.log(`Validation completed in ${executionTime.toFixed(2)} seconds.`);
  console.log(`Overall status: ${results.success ? 'PASSED' : 'FAILED'}`);
  
  if (!results.success) {
    console.error('Errors:');
    results.errors.forEach(error => console.error(`- ${error}`));
  }
  
  return {
    success: results.success,
    report
  };
}

/**
 * Generate a detailed validation report
 * @param {Object} results - Validation results
 * @param {number} executionTime - Test execution time in seconds
 * @returns {string} Formatted report
 */
function generateValidationReport(results, executionTime) {
  const timestamp = new Date().toISOString();
  
  let report = `# NDIS API Integration Validation Report\n\n`;
  report += `**Generated:** ${new Date().toLocaleString()}\n`;
  report += `**Execution Time:** ${executionTime.toFixed(2)} seconds\n`;
  report += `**Overall Status:** ${results.success ? 'PASSED ✅' : 'FAILED ❌'}\n\n`;
  
  if (!results.success) {
    report += `## Errors\n\n`;
    results.errors.forEach(error => {
      report += `- ${error}\n`;
    });
    report += '\n';
  }
  
  report += `## Test Results\n\n`;
  
  // Add table header
  report += `| Module | Status | Message |\n`;
  report += `|--------|--------|--------|\n`;
  
  // Add test results
  for (const [testName, testResult] of Object.entries(results.tests)) {
    const status = testResult.success ? '✅ PASSED' : '❌ FAILED';
    report += `| ${formatModuleName(testName)} | ${status} | ${testResult.message} |\n`;
  }
  
  report += '\n## Module Details\n\n';
  
  // Add details for each module
  report += `### Data Transformation\n\n`;
  report += `The data transformation module provides utilities for normalizing and formatting NDIS data structures. `;
  report += `It handles plan data, participant information, budgets, and support categories.\n\n`;
  
  report += `### Caching\n\n`;
  report += `The caching system improves performance by storing frequently accessed data locally. `;
  report += `It includes automatic expiration, LRU eviction, and persistence to localStorage.\n\n`;
  
  report += `### Advanced Search\n\n`;
  report += `The advanced search module enables complex queries across NDIS data with support for `;
  report += `fuzzy matching, location-based filtering, and multi-criteria searches.\n\n`;
  
  report += `### Participant Profiles\n\n`;
  report += `The participant profile manager maintains comprehensive records of NDIS participants, `;
  report += `including personal details, plans, notes, and preferences with local storage and synchronization.\n\n`;
  
  report += `### Error Handling\n\n`;
  report += `The error handling system provides standardized error normalization, user-friendly messages, `;
  report += `recovery suggestions, and intelligent retry logic.\n\n`;
  
  report += `### Real-Time Updates\n\n`;
  report += `The real-time updates module enables live data synchronization through WebSocket connections, `;
  report += `with support for topic subscriptions, automatic reconnection, and browser notifications.\n\n`;
  
  report += `## Recommendations\n\n`;
  
  // Add recommendations based on test results
  if (results.success) {
    report += `- The API integration is functioning correctly and ready for production use.\n`;
    report += `- Consider implementing additional monitoring for real-time performance metrics.\n`;
    report += `- Regularly review and update the cache invalidation strategies as the application evolves.\n`;
  } else {
    report += `- Address the identified errors before deploying to production.\n`;
    report += `- Implement additional error logging and monitoring.\n`;
    report += `- Consider adding more comprehensive test coverage for failed modules.\n`;
  }
  
  return report;
}

/**
 * Format a module name for display in the report
 * @param {string} name - Raw module name
 * @returns {string} Formatted module name
 */
function formatModuleName(name) {
  // Convert camelCase to Title Case with spaces
  const formatted = name
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, str => str.toUpperCase());
  
  return formatted;
}

/**
 * Save the validation report to a file
 * @param {string} report - Formatted report content
 */
function saveReportToFile(report) {
  try {
    // In a browser environment, we would use the file system API
    // For now, just log that we would save the file
    console.log('Report would be saved to: /home/ubuntu/care-mate/api-validation-report.md');
    
    // In a Node.js environment, we would use fs.writeFileSync
    if (typeof process !== 'undefined' && process.versions && process.versions.node) {
      const fs = require('fs');
      fs.writeFileSync('/home/ubuntu/care-mate/api-validation-report.md', report, 'utf8');
      console.log('Report saved to: /home/ubuntu/care-mate/api-validation-report.md');
    }
  } catch (error) {
    console.error('Error saving report to file:', error);
  }
}

// Export the test runner
export default runApiValidationTests;

// If this script is run directly, execute the tests
if (typeof require !== 'undefined' && require.main === module) {
  runApiValidationTests().catch(error => {
    console.error('Test execution failed:', error);
    process.exit(1);
  });
}
