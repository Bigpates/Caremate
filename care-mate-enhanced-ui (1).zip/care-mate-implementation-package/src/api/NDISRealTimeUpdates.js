/**
 * Care Mate - NDIS Real-Time Updates Manager
 * 
 * This module provides functionality for real-time updates and notifications
 * related to NDIS participant data, plan changes, and service bookings.
 */

/**
 * Real-Time Updates Manager for NDIS data
 */
class NDISRealTimeUpdates {
  constructor(config = {}) {
    // Default configuration
    this.config = {
      websocketUrl: 'wss://api.ndis.gov.au/v1/ws',
      reconnectInterval: 3000, // 3 seconds
      maxReconnectAttempts: 5,
      enableNotifications: true,
      ...config
    };
    
    // State
    this.socket = null;
    this.reconnectAttempts = 0;
    this.connected = false;
    this.subscriptions = new Map();
    this.messageHandlers = new Map();
    this.participantSubscriptions = new Set();
    
    // Bind methods
    this.connect = this.connect.bind(this);
    this.disconnect = this.disconnect.bind(this);
    this.reconnect = this.reconnect.bind(this);
    this.subscribe = this.subscribe.bind(this);
    this.unsubscribe = this.unsubscribe.bind(this);
    this.subscribeToParticipant = this.subscribeToParticipant.bind(this);
    this.unsubscribeFromParticipant = this.unsubscribeFromParticipant.bind(this);
    this.registerMessageHandler = this.registerMessageHandler.bind(this);
    this.unregisterMessageHandler = this.unregisterMessageHandler.bind(this);
    this.handleMessage = this.handleMessage.bind(this);
    this.sendMessage = this.sendMessage.bind(this);
  }
  
  /**
   * Connect to the WebSocket server
   * @returns {Promise<boolean>} Connection success
   */
  connect() {
    return new Promise((resolve, reject) => {
      if (this.socket && this.connected) {
        resolve(true);
        return;
      }
      
      try {
        this.socket = new WebSocket(this.config.websocketUrl);
        
        // Set up event handlers
        this.socket.onopen = () => {
          console.log('WebSocket connection established');
          this.connected = true;
          this.reconnectAttempts = 0;
          
          // Resubscribe to all previous subscriptions
          this.resubscribeAll();
          
          resolve(true);
        };
        
        this.socket.onclose = (event) => {
          console.log(`WebSocket connection closed: ${event.code} ${event.reason}`);
          this.connected = false;
          
          // Attempt to reconnect
          if (this.reconnectAttempts < this.config.maxReconnectAttempts) {
            setTimeout(() => {
              this.reconnect();
            }, this.config.reconnectInterval);
          } else {
            console.error('Maximum reconnection attempts reached');
          }
        };
        
        this.socket.onerror = (error) => {
          console.error('WebSocket error:', error);
          reject(error);
        };
        
        this.socket.onmessage = (event) => {
          try {
            const message = JSON.parse(event.data);
            this.handleMessage(message);
          } catch (error) {
            console.error('Error parsing WebSocket message:', error);
          }
        };
      } catch (error) {
        console.error('Error connecting to WebSocket:', error);
        reject(error);
      }
    });
  }
  
  /**
   * Disconnect from the WebSocket server
   */
  disconnect() {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
      this.connected = false;
    }
  }
  
  /**
   * Attempt to reconnect to the WebSocket server
   */
  reconnect() {
    this.reconnectAttempts++;
    console.log(`Attempting to reconnect (${this.reconnectAttempts}/${this.config.maxReconnectAttempts})...`);
    this.connect();
  }
  
  /**
   * Resubscribe to all previous subscriptions after reconnection
   */
  resubscribeAll() {
    // Resubscribe to all topics
    this.subscriptions.forEach((callback, topic) => {
      this.sendMessage({
        type: 'subscribe',
        topic
      });
    });
    
    // Resubscribe to all participant updates
    this.participantSubscriptions.forEach(participantId => {
      this.sendMessage({
        type: 'subscribe',
        topic: `participant.${participantId}`
      });
    });
  }
  
  /**
   * Subscribe to a specific topic
   * @param {string} topic - Topic to subscribe to
   * @param {Function} callback - Callback function for messages on this topic
   */
  subscribe(topic, callback) {
    if (!this.connected) {
      this.connect().then(() => {
        this.subscribe(topic, callback);
      });
      return;
    }
    
    this.subscriptions.set(topic, callback);
    
    this.sendMessage({
      type: 'subscribe',
      topic
    });
  }
  
  /**
   * Unsubscribe from a specific topic
   * @param {string} topic - Topic to unsubscribe from
   */
  unsubscribe(topic) {
    if (!this.connected) {
      return;
    }
    
    this.subscriptions.delete(topic);
    
    this.sendMessage({
      type: 'unsubscribe',
      topic
    });
  }
  
  /**
   * Subscribe to updates for a specific participant
   * @param {string} participantId - NDIS participant ID
   * @param {Function} callback - Callback function for participant updates
   */
  subscribeToParticipant(participantId, callback) {
    const topic = `participant.${participantId}`;
    this.participantSubscriptions.add(participantId);
    this.subscribe(topic, callback);
  }
  
  /**
   * Unsubscribe from updates for a specific participant
   * @param {string} participantId - NDIS participant ID
   */
  unsubscribeFromParticipant(participantId) {
    const topic = `participant.${participantId}`;
    this.participantSubscriptions.delete(participantId);
    this.unsubscribe(topic);
  }
  
  /**
   * Register a handler for a specific message type
   * @param {string} messageType - Type of message to handle
   * @param {Function} handler - Handler function
   */
  registerMessageHandler(messageType, handler) {
    this.messageHandlers.set(messageType, handler);
  }
  
  /**
   * Unregister a handler for a specific message type
   * @param {string} messageType - Type of message to unhandle
   */
  unregisterMessageHandler(messageType) {
    this.messageHandlers.delete(messageType);
  }
  
  /**
   * Handle an incoming WebSocket message
   * @param {Object} message - Parsed message object
   */
  handleMessage(message) {
    // Check if we have a handler for this message type
    if (message.type && this.messageHandlers.has(message.type)) {
      const handler = this.messageHandlers.get(message.type);
      handler(message);
    }
    
    // Check if this is a topic message
    if (message.topic && this.subscriptions.has(message.topic)) {
      const callback = this.subscriptions.get(message.topic);
      callback(message);
    }
    
    // Dispatch notifications if enabled
    if (this.config.enableNotifications && message.notification) {
      this.dispatchNotification(message.notification);
    }
  }
  
  /**
   * Send a message to the WebSocket server
   * @param {Object} message - Message to send
   */
  sendMessage(message) {
    if (!this.connected) {
      console.error('Cannot send message: WebSocket not connected');
      return;
    }
    
    try {
      this.socket.send(JSON.stringify(message));
    } catch (error) {
      console.error('Error sending WebSocket message:', error);
    }
  }
  
  /**
   * Dispatch a browser notification
   * @param {Object} notification - Notification data
   */
  dispatchNotification(notification) {
    // Check if browser notifications are supported and permitted
    if (!('Notification' in window)) {
      console.log('Browser does not support notifications');
      return;
    }
    
    // Request permission if needed
    if (Notification.permission !== 'granted') {
      Notification.requestPermission();
      return;
    }
    
    // Create and show notification
    try {
      new Notification(notification.title, {
        body: notification.body,
        icon: notification.icon || '/images/logo.png'
      });
    } catch (error) {
      console.error('Error creating notification:', error);
    }
  }
  
  /**
   * Dispose of resources
   */
  dispose() {
    this.disconnect();
  }
}

// Export the real-time updates manager
export default NDISRealTimeUpdates;
