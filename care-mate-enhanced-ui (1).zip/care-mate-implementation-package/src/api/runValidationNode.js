/**
 * Care Mate - NDIS API Validation Test Runner (Node.js)
 * 
 * This script runs the validation tests for the NDIS API integration
 * using the Node.js compatible runner.
 */

// Import the validation runner
import runApiValidationTests from './NDISApiValidationRunnerNode.js';

// Run the validation tests
console.log('=== NDIS API Integration Validation (Node.js) ===');
console.log('Starting validation tests...');

runApiValidationTests()
  .then(result => {
    console.log('\n=== Validation Complete ===');
    console.log(`Overall Status: ${result.success ? 'PASSED' : 'FAILED'}`);
    console.log('See api-validation-report.md for detailed results');
    
    if (!result.success) {
      process.exit(1);
    }
  })
  .catch(error => {
    console.error('\n=== Validation Failed ===');
    console.error(`Error: ${error.message}`);
    process.exit(1);
  });
